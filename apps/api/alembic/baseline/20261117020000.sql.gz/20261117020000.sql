--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: approvalstepstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".approvalstepstatus AS ENUM (
    'WAITING',
    'PENDING',
    'APPROVED',
    'REJECTED',
    'SKIPPED',
    'waiting',
    'pending',
    'approved',
    'rejected',
    'skipped'
);


--
-- Name: articletype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".articletype AS ENUM (
    'volume',
    'chapter',
    'section',
    'subsection',
    'clause',
    'special_clause',
    'article',
    'paragraph',
    'subparagraph',
    'item'
);


--
-- Name: declassificationcondition; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".declassificationcondition AS ENUM (
    'none',
    'auto_at_date',
    'manual_approval'
);


--
-- Name: delegatesource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".delegatesource AS ENUM (
    'manual',
    'assignment'
);


--
-- Name: deliverymethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".deliverymethod AS ENUM (
    'none',
    'system',
    'email',
    'paper',
    'postal'
);


--
-- Name: documentcategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".documentcategory AS ENUM (
    'DECREE',
    'LETTER',
    'ANNOUNCEMENT',
    'REPORT',
    'OTHER',
    'meeting_notice',
    'decree',
    'letter',
    'announcement',
    'report',
    'other',
    'record',
    'consultation',
    'presentation',
    'inspection_notice',
    'phone_record',
    'book_letter',
    'directive',
    'signature',
    'memo',
    'appointment',
    'certificate',
    'license',
    'contract',
    'proposal',
    'summary',
    'briefing',
    'form'
);


--
-- Name: documentclassification; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".documentclassification AS ENUM (
    'NORMAL',
    'CONFIDENTIAL',
    'SECRET',
    'normal',
    'confidential',
    'secret',
    'highly_confidential',
    'absolutely_confidential'
);


--
-- Name: documentstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".documentstatus AS ENUM (
    'DRAFT',
    'PENDING',
    'APPROVED',
    'REJECTED',
    'ARCHIVED',
    'draft',
    'pending',
    'approved',
    'rejected',
    'archived'
);


--
-- Name: documenturgency; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".documenturgency AS ENUM (
    'EXPRESS',
    'PRIORITY',
    'NORMAL',
    'express',
    'priority',
    'normal'
);


--
-- Name: documentvisibility; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".documentvisibility AS ENUM (
    'subject_only',
    'org_only',
    'public',
    'publicly_open'
);


--
-- Name: examgradetrack; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".examgradetrack AS ENUM (
    'first',
    'second',
    'third'
);


--
-- Name: judicialcasestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".judicialcasestatus AS ENUM (
    'open',
    'closed'
);


--
-- Name: judicialdocumenttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".judicialdocumenttype AS ENUM (
    'decision',
    'interpretation',
    'indictment',
    'judgment',
    'order',
    'other'
);


--
-- Name: merchandisesubmissionstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".merchandisesubmissionstatus AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'REVIEWING',
    'APPROVED',
    'REVISION_REQUESTED',
    'REJECTED',
    'REVIEW_COMPLETED'
);


--
-- Name: orderstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".orderstatus AS ENUM (
    'PENDING',
    'CONFIRMED',
    'CANCELLED',
    'REFUNDED'
);


--
-- Name: petitionattachmentvisibility; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".petitionattachmentvisibility AS ENUM (
    'public',
    'internal'
);


--
-- Name: petitioneventtype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".petitioneventtype AS ENUM (
    'created',
    'assigned',
    'status_changed',
    'transferred',
    'needs_info',
    'supplemented',
    'replied',
    'closed',
    'rejected',
    'note',
    'attachment_added',
    'public_requested',
    'public_responded',
    'public_confirmed',
    'public_declined'
);


--
-- Name: petitioneventvisibility; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".petitioneventvisibility AS ENUM (
    'public',
    'internal'
);


--
-- Name: petitionpublicstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".petitionpublicstatus AS ENUM (
    'not_requested',
    'pending_user',
    'pending_handler',
    'published',
    'declined'
);


--
-- Name: petitionstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".petitionstatus AS ENUM (
    'submitted',
    'assigned',
    'in_progress',
    'needs_info',
    'transferred',
    'resolved',
    'closed',
    'rejected'
);


--
-- Name: productstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".productstatus AS ENUM (
    'DRAFT',
    'ACTIVE',
    'SOLD_OUT',
    'CANCELLED',
    'TESTING'
);


--
-- Name: questiontype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".questiontype AS ENUM (
    'text',
    'textarea',
    'single',
    'multiple',
    'rating',
    'date',
    'section_text',
    'page_break',
    'image',
    'video',
    'ranking',
    'single_grid',
    'multi_text',
    'linear_scale'
);


--
-- Name: recipienttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".recipienttype AS ENUM (
    'MAIN',
    'PRIMARY',
    'COPY',
    'main',
    'primary',
    'copy',
    'attendee',
    'observer'
);


--
-- Name: regulationamendmenttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".regulationamendmenttype AS ENUM (
    'enact',
    'amend',
    'abolish'
);


--
-- Name: regulationcategory; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".regulationcategory AS ENUM (
    'constitution',
    'ordinance',
    'procedure'
);


--
-- Name: regulationworkflowstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".regulationworkflowstatus AS ENUM (
    'draft',
    'under_review',
    'scheduled',
    'council_approved',
    'published',
    'rejected',
    'archived'
);


--
-- Name: seatassignmentstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".seatassignmentstatus AS ENUM (
    'active',
    'released'
);


--
-- Name: seatstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".seatstatus AS ENUM (
    'available',
    'disabled',
    'blocked'
);


--
-- Name: shopdiscounttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".shopdiscounttype AS ENUM (
    'PERCENTAGE',
    'FIXED',
    'PRICE_OVERRIDE',
    'BUNDLE_PRICE'
);


--
-- Name: surveystatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".surveystatus AS ENUM (
    'draft',
    'open',
    'closed',
    'archived'
);


--
-- Name: yearmode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "__HCCA_SCHEMA__".yearmode AS ENUM (
    'roc',
    'ce'
);


--
-- Name: regulations_search_vector_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "__HCCA_SCHEMA__".regulations_search_vector_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
          NEW.search_vector := to_tsvector('simple',
            coalesce(NEW.title, '') || ' ' || coalesce(NEW.preface, '')
          );
          RETURN NEW;
        END;
        $$;


SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".activities (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    org_id uuid,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone,
    status character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    order_closes_at timestamp with time zone,
    order_closed_at timestamp with time zone
);


--
-- Name: activity_conveners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".activity_conveners (
    id uuid NOT NULL,
    activity_id uuid NOT NULL,
    user_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: activity_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".activity_links (
    id uuid NOT NULL,
    activity_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid NOT NULL,
    title character varying(240) NOT NULL,
    href character varying(500) NOT NULL,
    note text,
    meta jsonb NOT NULL,
    created_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: activity_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".activity_members (
    id uuid NOT NULL,
    activity_id uuid NOT NULL,
    role_id uuid NOT NULL,
    user_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: activity_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".activity_roles (
    id uuid NOT NULL,
    activity_id uuid NOT NULL,
    key character varying(60) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    discord_role_id character varying(32),
    discord_channel_id character varying(32),
    create_private_channel boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: analytics_page_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".analytics_page_views (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    path character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: announcement_audience_orgs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".announcement_audience_orgs (
    announcement_id uuid NOT NULL,
    org_id uuid NOT NULL
);


--
-- Name: announcement_audience_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".announcement_audience_users (
    announcement_id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: announcement_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".announcement_media (
    id uuid NOT NULL,
    announcement_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    storage_key character varying(500) NOT NULL,
    mime_type character varying(100) NOT NULL,
    file_size bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: announcement_reads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".announcement_reads (
    id uuid NOT NULL,
    announcement_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".announcements (
    id uuid NOT NULL,
    title character varying(200) NOT NULL,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_urgent boolean DEFAULT false NOT NULL,
    urgent_until timestamp with time zone,
    is_published boolean DEFAULT false NOT NULL,
    published_at timestamp with time zone,
    org_id uuid,
    author_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    audience_type character varying(20) NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, (((COALESCE(title, ''::character varying))::text || ' '::text) || COALESCE((content)::text, ''::text)))) STORED,
    activity_id uuid,
    link_url character varying(500),
    link_label character varying(60),
    show_on_every_visit boolean DEFAULT false NOT NULL
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".api_keys (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    key_prefix character varying(20) NOT NULL,
    key_hash character varying(128) NOT NULL,
    encrypted_key character varying(500),
    owner_user_id uuid NOT NULL,
    scopes jsonb NOT NULL,
    rate_limit_per_minute integer NOT NULL,
    expires_at timestamp with time zone,
    last_used_at timestamp with time zone,
    last_used_ip character varying(45),
    revoked_at timestamp with time zone,
    revoked_reason character varying(500),
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_anchors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".audit_log_anchors (
    id uuid NOT NULL,
    anchor_date date NOT NULL,
    last_audit_log_id uuid,
    head_hash character varying(64) NOT NULL,
    log_count integer NOT NULL,
    s3_object_url character varying(500),
    s3_uploaded_at timestamp with time zone,
    integrity_verified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".audit_logs (
    id uuid NOT NULL,
    entity_type character varying(50) NOT NULL,
    entity_id character varying(36) NOT NULL,
    action character varying(50) NOT NULL,
    actor_id character varying(36),
    actor_email character varying(200),
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip_address character varying(45),
    created_at timestamp with time zone NOT NULL,
    summary text,
    prev_hash character varying(64),
    self_hash character varying(64)
);


--
-- Name: automation_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".automation_rules (
    id uuid NOT NULL,
    name character varying(160) NOT NULL,
    description text,
    trigger_type character varying(80) NOT NULL,
    conditions jsonb DEFAULT '{}'::jsonb NOT NULL,
    actions jsonb DEFAULT '[]'::jsonb NOT NULL,
    matter_id uuid,
    status character varying(30) NOT NULL,
    created_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_triggered_at timestamp with time zone,
    trigger_count integer DEFAULT 0 NOT NULL
);


--
-- Name: backup_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".backup_records (
    id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    source_label character varying(200),
    local_path character varying(500),
    s3_bucket character varying(200),
    s3_key character varying(500),
    s3_region character varying(50),
    size_bytes integer,
    sha256_hex character varying(64),
    encrypted boolean NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    error_message character varying(2000),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".cart_items (
    id uuid NOT NULL,
    cart_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    selected_options jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: carts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".carts (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: class_cadres; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".class_cadres (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: class_confirmations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".class_confirmations (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    class_id uuid NOT NULL,
    student_id character varying(20) NOT NULL,
    seat_number integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_confirmation_seat CHECK (((seat_number >= 1) AND (seat_number <= 999)))
);


--
-- Name: class_correction_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".class_correction_requests (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    reported_class_id uuid,
    requested_class_id uuid NOT NULL,
    resolved_class_id uuid,
    message text,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    reviewed_by_id uuid,
    reviewed_at timestamp with time zone,
    review_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_class_correction_requests_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


--
-- Name: class_manual_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".class_manual_members (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: class_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".class_memberships (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    user_id uuid NOT NULL,
    academic_year integer NOT NULL,
    source character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    start_date date NOT NULL,
    end_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: class_role_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".class_role_bindings (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    role_key character varying(50) NOT NULL,
    position_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: class_roster_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".class_roster_entries (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    seat_number integer NOT NULL,
    student_id character varying(20) NOT NULL,
    user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: class_student_ranges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".class_student_ranges (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    student_id_start character varying(20) NOT NULL,
    student_id_end character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: council_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".council_proposals (
    id uuid NOT NULL,
    serial_number character varying(20) NOT NULL,
    submitter_id uuid,
    contact_name character varying(100),
    contact_email character varying(255) NOT NULL,
    proposer_name character varying(100) NOT NULL,
    co_sponsors text,
    kind character varying(20),
    title character varying(200) NOT NULL,
    summary text NOT NULL,
    legal_basis text,
    proposal_text text NOT NULL,
    rationale text NOT NULL,
    expected_effect text,
    status character varying(30) DEFAULT 'submitted'::character varying NOT NULL,
    committee_review_note text,
    decided_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    case_type character varying(20) DEFAULT 'regulation'::character varying NOT NULL,
    regulation_id uuid
);


--
-- Name: crux_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".crux_snapshots (
    id uuid NOT NULL,
    url text NOT NULL,
    form_factor character varying(16) NOT NULL,
    collected_at timestamp with time zone NOT NULL,
    lcp_p75 double precision,
    inp_p75 double precision,
    cls_p75 double precision,
    ttfb_p75 double precision
);


--
-- Name: decisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".decisions (
    id uuid NOT NULL,
    matter_id uuid NOT NULL,
    case_id uuid,
    source_type character varying(50),
    source_id uuid,
    title character varying(240) NOT NULL,
    content text NOT NULL,
    status character varying(30) NOT NULL,
    owner_user_id uuid,
    due_at timestamp with time zone,
    completed_at timestamp with time zone,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: defense_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".defense_rules (
    id uuid NOT NULL,
    rule_type character varying(40) NOT NULL,
    target character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    expires_at timestamp with time zone,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discord_account_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".discord_account_links (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    discord_user_id character varying(32) NOT NULL,
    username character varying(100),
    global_name character varying(100),
    avatar_hash character varying(100),
    is_active boolean NOT NULL,
    linked_at timestamp with time zone NOT NULL,
    unlinked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discord_activity_workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".discord_activity_workspaces (
    id uuid NOT NULL,
    activity_id uuid NOT NULL,
    guild_id character varying(32) NOT NULL,
    category_id character varying(32),
    general_channel_id character varying(32),
    announcement_channel_id character varying(32),
    staff_channel_id character varying(32),
    convener_role_id character varying(32),
    sync_status character varying(20) NOT NULL,
    last_error text,
    last_synced_at timestamp with time zone,
    auto_sync boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discord_guild_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".discord_guild_configs (
    id uuid NOT NULL,
    guild_id character varying(32) NOT NULL,
    name character varying(120),
    office_channel_id character varying(32),
    security_alert_channel_id character varying(32),
    petition_entry_channel_id character varying(32),
    announcement_channel_id character varying(32),
    admin_role_id character varying(32),
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    moderation_log_channel_id character varying(32),
    welcome_channel_id character varying(32),
    petition_private_category_id character varying(32),
    petition_staff_role_id character varying(32),
    petition_private_channel_enabled boolean NOT NULL
);


--
-- Name: discord_member_sync_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".discord_member_sync_states (
    id uuid NOT NULL,
    guild_id character varying(32) NOT NULL,
    discord_user_id character varying(32) NOT NULL,
    user_id uuid,
    base_nickname character varying(100),
    actual_nickname character varying(100),
    expected_nickname character varying(100),
    last_applied_prefix character varying(50),
    actual_role_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    desired_role_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    has_role_drift boolean DEFAULT false NOT NULL,
    last_seen_at timestamp with time zone,
    last_synced_at timestamp with time zone,
    last_error character varying(2000),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discord_nickname_prefix_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".discord_nickname_prefix_rules (
    id uuid NOT NULL,
    guild_id character varying(32) NOT NULL,
    prefix character varying(20) NOT NULL,
    priority integer NOT NULL,
    mapping_kind character varying(20) NOT NULL,
    org_id uuid,
    position_id uuid,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discord_notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".discord_notification_preferences (
    user_id uuid NOT NULL,
    preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    quiet_hours_start time without time zone,
    quiet_hours_end time without time zone,
    digest_daily_enabled boolean DEFAULT true NOT NULL,
    digest_weekly_enabled boolean DEFAULT false NOT NULL,
    timezone character varying(64) DEFAULT 'Asia/Taipei'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discord_notification_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".discord_notification_routes (
    id uuid NOT NULL,
    guild_id character varying(32) NOT NULL,
    event_key character varying(80) NOT NULL,
    module character varying(40) NOT NULL,
    channel_id character varying(32) NOT NULL,
    role_id character varying(32),
    petition_type_id uuid,
    org_id uuid,
    priority integer DEFAULT 100 NOT NULL,
    mention_role boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discord_org_channel_mappings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".discord_org_channel_mappings (
    id uuid NOT NULL,
    guild_id character varying(32) NOT NULL,
    org_id uuid NOT NULL,
    channel_id character varying(32) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discord_role_mappings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".discord_role_mappings (
    id uuid NOT NULL,
    guild_id character varying(32) NOT NULL,
    role_id character varying(32) NOT NULL,
    mapping_kind character varying(20) NOT NULL,
    org_id uuid,
    position_id uuid,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: discord_role_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".discord_role_policies (
    id uuid NOT NULL,
    guild_id character varying(32) NOT NULL,
    role_id character varying(32) NOT NULL,
    role_name character varying(100),
    org_id uuid,
    position_id uuid,
    nickname_label character varying(20),
    priority integer NOT NULL,
    manage_role boolean DEFAULT true NOT NULL,
    use_in_nickname boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_approval_delegations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".document_approval_delegations (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    principal_user_id uuid NOT NULL,
    delegate_user_id uuid NOT NULL,
    start_at timestamp with time zone NOT NULL,
    end_at timestamp with time zone,
    reason text,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".document_approvals (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    approver_id uuid NOT NULL,
    step_order integer NOT NULL,
    status "__HCCA_SCHEMA__".approvalstepstatus NOT NULL,
    comment text,
    decided_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    delegate_id uuid,
    is_acting boolean DEFAULT false NOT NULL,
    delegate_source "__HCCA_SCHEMA__".delegatesource,
    parallel_group integer,
    approval_mode character varying(10)
);


--
-- Name: document_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".document_attachments (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    storage_key character varying(500),
    content_type character varying(100),
    file_size bigint,
    uploaded_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    link_url character varying(2048),
    display_name character varying(255),
    quantity integer DEFAULT 1 NOT NULL
);


--
-- Name: document_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".document_recipients (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    recipient_type "__HCCA_SCHEMA__".recipienttype NOT NULL,
    name character varying(200) NOT NULL,
    email character varying(200),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    target_user_id uuid,
    target_org_id uuid,
    delivery_method "__HCCA_SCHEMA__".deliverymethod DEFAULT 'none'::"__HCCA_SCHEMA__".deliverymethod NOT NULL,
    target_class_id uuid,
    email_position_ids jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: document_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".document_revisions (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    revision_number integer NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    change_note character varying(500),
    changed_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: document_serial_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "__HCCA_SCHEMA__".document_serial_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_serial_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".document_serial_templates (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    org_prefix character varying(20) NOT NULL,
    category_char character varying(10) NOT NULL,
    year_mode "__HCCA_SCHEMA__".yearmode NOT NULL,
    reset_on_new_year boolean DEFAULT true NOT NULL,
    current_year integer NOT NULL,
    counter integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    description character varying(200),
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_default boolean NOT NULL,
    is_default_president_publish boolean NOT NULL,
    inherit_parent_prefix boolean DEFAULT true NOT NULL
);


--
-- Name: document_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".document_templates (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name character varying(120) NOT NULL,
    description character varying(500),
    version integer DEFAULT 1 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    issuer_full_name character varying(200),
    urgency "__HCCA_SCHEMA__".documenturgency NOT NULL,
    classification "__HCCA_SCHEMA__".documentclassification NOT NULL,
    declassification_condition "__HCCA_SCHEMA__".declassificationcondition NOT NULL,
    category "__HCCA_SCHEMA__".documentcategory NOT NULL,
    subject character varying(500),
    doc_description text,
    action_required text,
    content text DEFAULT ''::text NOT NULL,
    meeting_purpose character varying(500),
    meeting_location character varying(200),
    meeting_chairperson character varying(100),
    handler_unit character varying(100),
    file_number character varying(100),
    retention_period character varying(100),
    visibility_level "__HCCA_SCHEMA__".documentvisibility NOT NULL,
    recipients jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_by uuid NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    issuer_postal_code character varying(20),
    issuer_address character varying(300),
    basis text,
    handler_phone character varying(50),
    classification_number character varying(100),
    confidentiality_expires_at timestamp with time zone
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".documents (
    id uuid NOT NULL,
    serial_number character varying(30) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    status "__HCCA_SCHEMA__".documentstatus NOT NULL,
    current_step integer NOT NULL,
    org_id uuid NOT NULL,
    created_by uuid NOT NULL,
    submitted_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    urgency "__HCCA_SCHEMA__".documenturgency NOT NULL,
    classification "__HCCA_SCHEMA__".documentclassification NOT NULL,
    category "__HCCA_SCHEMA__".documentcategory NOT NULL,
    subject character varying(500),
    doc_description text,
    action_required text,
    handler_name character varying(50),
    handler_unit character varying(100),
    handler_email character varying(200),
    issued_at timestamp with time zone,
    due_date timestamp with time zone,
    serial_template_id uuid,
    is_public boolean DEFAULT false NOT NULL,
    meeting_purpose character varying(500),
    meeting_time timestamp with time zone,
    meeting_location character varying(200),
    meeting_chairperson character varying(100),
    regulation_id uuid,
    visibility_level "__HCCA_SCHEMA__".documentvisibility DEFAULT 'org_only'::"__HCCA_SCHEMA__".documentvisibility NOT NULL,
    issuer_full_name character varying(200),
    declassification_condition "__HCCA_SCHEMA__".declassificationcondition DEFAULT 'none'::"__HCCA_SCHEMA__".declassificationcondition NOT NULL,
    confidentiality_expires_at timestamp with time zone,
    file_number character varying(100),
    retention_period character varying(100),
    page_info character varying(50),
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, (((COALESCE(title, ''::character varying))::text || ' '::text) || COALESCE(content, ''::text)))) STORED,
    activity_id uuid,
    reminder_count integer DEFAULT 0 NOT NULL,
    last_reminded_at timestamp with time zone,
    archive_at timestamp with time zone,
    regulation_revision_id uuid,
    issuer_postal_code character varying(20),
    issuer_address character varying(300),
    basis text,
    handler_phone character varying(50),
    classification_number character varying(100),
    source_document_date timestamp with time zone,
    source_document_number character varying(100),
    summary character varying(500),
    recipient_email_sent_at timestamp with time zone,
    petition_case_id uuid
);


--
-- Name: election_ballot_boxes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".election_ballot_boxes (
    id uuid NOT NULL,
    election_id uuid NOT NULL,
    name character varying(120) NOT NULL,
    status character varying(20) NOT NULL,
    expected_total_votes integer,
    sort_order integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: election_candidate_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".election_candidate_members (
    id uuid NOT NULL,
    candidate_id uuid NOT NULL,
    "position" character varying(100) NOT NULL,
    name character varying(100) NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    photo_url character varying(500)
);


--
-- Name: election_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".election_candidates (
    id uuid NOT NULL,
    election_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    number integer NOT NULL,
    color character varying(20) NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: elections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".elections (
    id uuid NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    status character varying(20) NOT NULL,
    is_public boolean NOT NULL,
    created_by_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug character varying(220),
    seats integer NOT NULL,
    eligible_voter_count integer,
    turnout_threshold_pct double precision,
    vote_threshold_pct double precision
);


--
-- Name: electronic_credential_authorizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".electronic_credential_authorizations (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    identity_label character varying(80) NOT NULL,
    note text,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: electronic_credential_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".electronic_credential_settings (
    id integer NOT NULL,
    student_id_prefixes jsonb DEFAULT '["310", "410", "510"]'::jsonb NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_electronic_credential_settings_singleton CHECK ((id = 1))
);


--
-- Name: electronic_credential_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "__HCCA_SCHEMA__".electronic_credential_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: electronic_credential_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "__HCCA_SCHEMA__".electronic_credential_settings_id_seq OWNED BY "__HCCA_SCHEMA__".electronic_credential_settings.id;


--
-- Name: email_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".email_attachments (
    id uuid NOT NULL,
    message_id uuid,
    template_id uuid,
    uploaded_by_id uuid,
    storage_key character varying(500) NOT NULL,
    filename character varying(255) NOT NULL,
    content_type character varying(120) NOT NULL,
    file_size integer NOT NULL,
    delivery_mode character varying(20) DEFAULT 'attachment'::character varying NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: email_campaign_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".email_campaign_recipients (
    id uuid NOT NULL,
    message_id uuid NOT NULL,
    user_id uuid,
    email character varying(255) NOT NULL,
    name character varying(100),
    variables jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(20) NOT NULL,
    celery_task_id character varying(100),
    provider_id character varying(100),
    sent_at timestamp with time zone,
    error_detail text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    next_retry_at timestamp with time zone,
    delivered_at timestamp with time zone,
    first_opened_at timestamp with time zone,
    last_opened_at timestamp with time zone,
    first_clicked_at timestamp with time zone,
    last_clicked_at timestamp with time zone,
    bounced_at timestamp with time zone,
    complained_at timestamp with time zone
);


--
-- Name: email_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".email_messages (
    id uuid NOT NULL,
    sender_id uuid,
    subject character varying(255) NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    template character varying(50) DEFAULT 'generic'::character varying NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    recipient_spec jsonb DEFAULT '{}'::jsonb NOT NULL,
    resolved_emails jsonb DEFAULT '[]'::jsonb NOT NULL,
    recipient_count integer DEFAULT 0 NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    scheduled_at timestamp with time zone,
    celery_task_id character varying(100),
    error_detail text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    variable_definitions jsonb DEFAULT '[]'::jsonb NOT NULL,
    default_variables jsonb DEFAULT '{}'::jsonb NOT NULL,
    recipient_variables jsonb DEFAULT '[]'::jsonb NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    next_retry_at timestamp with time zone,
    org_id uuid,
    template_id uuid,
    track_opens boolean DEFAULT true NOT NULL,
    track_clicks boolean DEFAULT true NOT NULL,
    idempotency_key character varying(100)
);


--
-- Name: email_recipient_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".email_recipient_events (
    id uuid NOT NULL,
    recipient_id uuid NOT NULL,
    provider_event_id character varying(150) NOT NULL,
    event_type character varying(30) NOT NULL,
    event_at timestamp with time zone NOT NULL,
    url text,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: email_recipient_list_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".email_recipient_list_members (
    id uuid NOT NULL,
    list_id uuid NOT NULL,
    user_id uuid,
    email character varying(255) NOT NULL,
    name character varying(100),
    variables jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: email_recipient_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".email_recipient_lists (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    org_id uuid,
    visibility character varying(20) DEFAULT 'private'::character varying NOT NULL,
    name character varying(120) NOT NULL,
    description character varying(500) DEFAULT ''::character varying NOT NULL,
    recipient_spec jsonb DEFAULT '{}'::jsonb NOT NULL,
    variable_definitions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: email_suppressions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".email_suppressions (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    reason character varying(30) NOT NULL,
    source character varying(50) DEFAULT 'system'::character varying NOT NULL,
    detail text,
    is_active boolean DEFAULT true NOT NULL,
    suppressed_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: email_template_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".email_template_versions (
    id uuid NOT NULL,
    template_id uuid NOT NULL,
    version integer NOT NULL,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    variable_definitions jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".email_templates (
    id uuid NOT NULL,
    owner_id uuid NOT NULL,
    org_id uuid,
    visibility character varying(20) DEFAULT 'private'::character varying NOT NULL,
    name character varying(120) NOT NULL,
    description character varying(500) DEFAULT ''::character varying NOT NULL,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    variable_definitions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_favorite boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    current_version integer DEFAULT 1 NOT NULL,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: entity_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".entity_relations (
    id uuid NOT NULL,
    matter_id uuid,
    case_id uuid,
    source_type character varying(50) NOT NULL,
    source_id uuid,
    target_type character varying(50) NOT NULL,
    target_id uuid,
    relation character varying(50) NOT NULL,
    title character varying(240) NOT NULL,
    href character varying(500),
    note text,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: exam_paper_downloads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".exam_paper_downloads (
    id uuid NOT NULL,
    paper_id uuid NOT NULL,
    user_id uuid NOT NULL,
    trace_code character varying(40) NOT NULL,
    file_sha256 character varying(64),
    ip_address character varying(45),
    user_agent text,
    downloaded_at timestamp with time zone NOT NULL
);


--
-- Name: exam_papers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".exam_papers (
    id uuid NOT NULL,
    title character varying(200) NOT NULL,
    subject character varying(80) NOT NULL,
    academic_year integer NOT NULL,
    semester integer NOT NULL,
    grade integer NOT NULL,
    grade_track "__HCCA_SCHEMA__".examgradetrack,
    exam_number integer NOT NULL,
    filename character varying(255) NOT NULL,
    storage_key character varying(500) NOT NULL,
    content_type character varying(100) NOT NULL,
    file_size bigint NOT NULL,
    is_published boolean NOT NULL,
    is_active boolean NOT NULL,
    uploaded_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: feature_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".feature_flags (
    id uuid NOT NULL,
    key character varying(100) NOT NULL,
    description text,
    is_globally_enabled boolean NOT NULL,
    percentage_rollout integer NOT NULL,
    enabled_user_ids jsonb NOT NULL,
    enabled_permission_codes jsonb NOT NULL,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_bank_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_bank_transactions (
    id uuid NOT NULL,
    fund_account_id uuid NOT NULL,
    external_id character varying(180) NOT NULL,
    occurred_on date NOT NULL,
    amount integer NOT NULL,
    description character varying(300) NOT NULL,
    journal_entry_id uuid,
    raw jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_budget_allocation_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budget_allocation_evidence (
    id uuid NOT NULL,
    allocation_id uuid NOT NULL,
    storage_key character varying(500) NOT NULL,
    filename character varying(255) NOT NULL,
    content_type character varying(120) NOT NULL,
    file_size integer NOT NULL,
    note character varying(500),
    uploaded_by_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_budget_allocation_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budget_allocation_revisions (
    id uuid NOT NULL,
    allocation_id uuid NOT NULL,
    previous_amount integer NOT NULL,
    next_amount integer NOT NULL,
    reason character varying(500) NOT NULL,
    changed_by_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    previous_details jsonb,
    next_details jsonb
);


--
-- Name: finance_budget_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budget_allocations (
    id uuid NOT NULL,
    submission_id uuid NOT NULL,
    node_id uuid NOT NULL,
    amount integer NOT NULL,
    note text,
    proposed_by_id uuid NOT NULL,
    proposing_org_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    quantity numeric(12,2),
    unit character varying(32),
    unit_price integer,
    is_new boolean DEFAULT false NOT NULL
);


--
-- Name: finance_budget_expense_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budget_expense_evidence (
    id uuid NOT NULL,
    expense_id uuid NOT NULL,
    storage_key character varying(500) NOT NULL,
    filename character varying(255) NOT NULL,
    content_type character varying(120) NOT NULL,
    file_size integer NOT NULL,
    uploaded_by_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_budget_expense_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budget_expense_items (
    id uuid NOT NULL,
    expense_id uuid NOT NULL,
    sort_order integer NOT NULL,
    name character varying(200) NOT NULL,
    unit_price integer NOT NULL,
    tax_rate integer DEFAULT 0 NOT NULL,
    quantity numeric(12,2) NOT NULL,
    unit character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_budget_expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budget_expenses (
    id uuid NOT NULL,
    budget_id uuid NOT NULL,
    allocation_id uuid NOT NULL,
    entry_date date NOT NULL,
    purpose character varying(300) NOT NULL,
    total_amount integer NOT NULL,
    note text,
    recorded_by_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    department_org_id uuid NOT NULL,
    advanced_by_name character varying(120)
);


--
-- Name: finance_budget_income_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budget_income_items (
    id uuid NOT NULL,
    submission_id uuid NOT NULL,
    category character varying(160) NOT NULL,
    name character varying(160) NOT NULL,
    amount integer NOT NULL,
    note text,
    source_row_number integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_new boolean DEFAULT false NOT NULL,
    quantity numeric(12,2),
    unit character varying(32),
    unit_price integer
);


--
-- Name: finance_budget_income_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budget_income_records (
    id uuid NOT NULL,
    budget_id uuid NOT NULL,
    income_item_id uuid NOT NULL,
    amount integer NOT NULL,
    entry_date date NOT NULL,
    note text,
    recorded_by_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_budget_nodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budget_nodes (
    id uuid NOT NULL,
    budget_id uuid NOT NULL,
    parent_id uuid,
    name character varying(160) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_budget_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budget_submissions (
    id uuid NOT NULL,
    budget_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    title character varying(160) NOT NULL,
    note text,
    created_by_id uuid NOT NULL,
    submitted_at timestamp with time zone,
    reviewed_by_id uuid,
    reviewed_at timestamp with time zone,
    review_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_council_review_public boolean DEFAULT false NOT NULL,
    council_approved_on date,
    is_full_snapshot boolean DEFAULT false NOT NULL
);


--
-- Name: finance_budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_budgets (
    id uuid NOT NULL,
    ledger_id uuid NOT NULL,
    period_id uuid NOT NULL,
    name character varying(160) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_public boolean NOT NULL
);


--
-- Name: finance_chart_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_chart_accounts (
    id uuid NOT NULL,
    ledger_id uuid NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(120) NOT NULL,
    account_type character varying(20) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_expense_claim_item_evidence; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_expense_claim_item_evidence (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    storage_key character varying(500) NOT NULL,
    filename character varying(255) NOT NULL,
    content_type character varying(120) NOT NULL,
    file_size integer NOT NULL,
    evidence_type character varying(20) NOT NULL,
    note character varying(500),
    uploaded_by_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_expense_claim_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_expense_claim_items (
    id uuid NOT NULL,
    journal_entry_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    unit_price integer NOT NULL,
    quantity numeric(12,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    tax_rate integer DEFAULT 0 NOT NULL,
    budget_node_id uuid,
    budget_exception_note character varying(500),
    unit character varying(32) NOT NULL
);


--
-- Name: finance_fiscal_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_fiscal_periods (
    id uuid NOT NULL,
    ledger_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    starts_on date NOT NULL,
    ends_on date NOT NULL,
    is_closed boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_fund_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_fund_accounts (
    id uuid NOT NULL,
    ledger_id uuid NOT NULL,
    chart_account_id uuid NOT NULL,
    name character varying(120) NOT NULL,
    storage_type character varying(20) NOT NULL,
    bank_name character varying(120),
    account_last_four character varying(4),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_journal_entries (
    id uuid NOT NULL,
    ledger_id uuid NOT NULL,
    period_id uuid NOT NULL,
    entry_date date NOT NULL,
    description character varying(300) NOT NULL,
    status character varying(24) NOT NULL,
    created_by_id uuid NOT NULL,
    reviewed_by_id uuid,
    posted_at timestamp with time zone,
    source_type character varying(50),
    source_id uuid,
    source_event character varying(60),
    source_url character varying(500),
    evidence_url character varying(500),
    note text,
    reversal_of_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    claim_status character varying(24),
    procurement_status character varying(24),
    procurement_updated_by_id uuid,
    procurement_updated_at timestamp with time zone,
    payment_status character varying(24),
    payment_by_id uuid,
    payment_at timestamp with time zone,
    budget_included boolean,
    budget_included_by_id uuid,
    budget_included_at timestamp with time zone,
    proposing_org_id uuid,
    advanced_by_id uuid,
    payment_method character varying(20) DEFAULT 'direct'::character varying NOT NULL,
    reimbursement_entry_id uuid
);


--
-- Name: finance_journal_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_journal_lines (
    id uuid NOT NULL,
    entry_id uuid NOT NULL,
    account_id uuid NOT NULL,
    debit integer DEFAULT 0 NOT NULL,
    credit integer DEFAULT 0 NOT NULL,
    memo character varying(240),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: finance_ledgers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".finance_ledgers (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name character varying(120) NOT NULL,
    currency character varying(3) DEFAULT 'TWD'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: gallery_drive_sync; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".gallery_drive_sync (
    id uuid NOT NULL,
    scope character varying(20) NOT NULL,
    created_by uuid NOT NULL,
    config jsonb NOT NULL,
    manifest jsonb NOT NULL,
    last_report jsonb NOT NULL,
    requested_at timestamp with time zone,
    next_sync_at timestamp with time zone,
    last_synced_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: governance_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".governance_cases (
    id uuid NOT NULL,
    matter_id uuid NOT NULL,
    program_id uuid,
    title character varying(240) NOT NULL,
    case_type character varying(50) NOT NULL,
    description text,
    owner_user_id uuid,
    status character varying(30) NOT NULL,
    current_step character varying(100),
    due_at timestamp with time zone,
    completed_at timestamp with time zone,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: governance_discord_event_routes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".governance_discord_event_routes (
    id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    event_type character varying(60) NOT NULL,
    channel_kind character varying(20) NOT NULL,
    channel_id character varying(32),
    create_thread boolean DEFAULT false NOT NULL,
    mention_role_id character varying(32),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: governance_discord_workspaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".governance_discord_workspaces (
    id uuid NOT NULL,
    matter_id uuid NOT NULL,
    guild_id character varying(32) NOT NULL,
    mode character varying(20) NOT NULL,
    category_id character varying(32),
    discussion_channel_id character varying(32),
    announcement_channel_id character varying(32),
    staff_channel_id character varying(32),
    mention_role_id character varying(32),
    sync_status character varying(20) NOT NULL,
    last_error text,
    last_synced_at timestamp with time zone,
    auto_sync boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: governance_workflow_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".governance_workflow_templates (
    id uuid NOT NULL,
    name character varying(160) NOT NULL,
    template_type character varying(50) NOT NULL,
    description text,
    version integer NOT NULL,
    steps jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_by_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".inventory_categories (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    color character varying(7),
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".inventory_items (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    category_id uuid,
    name character varying(200) NOT NULL,
    description text,
    unit character varying(20) DEFAULT '個'::character varying NOT NULL,
    item_type character varying(20) DEFAULT 'consumable'::character varying NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    low_stock_threshold integer DEFAULT 0 NOT NULL,
    location character varying(200),
    image_url character varying(500),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_procurement_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".inventory_procurement_items (
    id uuid NOT NULL,
    procurement_id uuid NOT NULL,
    item_id uuid,
    item_name character varying(200) NOT NULL,
    item_unit character varying(20) DEFAULT '個'::character varying NOT NULL,
    quantity_requested integer NOT NULL,
    quantity_received integer DEFAULT 0 NOT NULL,
    estimated_unit_price integer,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_procurements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".inventory_procurements (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    title character varying(200) NOT NULL,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    estimated_amount integer,
    requester_id uuid NOT NULL,
    reviewer_id uuid,
    reviewed_at timestamp with time zone,
    requester_notes text,
    reviewer_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: inventory_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".inventory_transactions (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    txn_type character varying(20) NOT NULL,
    quantity integer NOT NULL,
    quantity_before integer NOT NULL,
    quantity_after integer NOT NULL,
    notes text,
    created_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: judicial_petitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".judicial_petitions (
    id uuid NOT NULL,
    docket_number character varying(20) NOT NULL,
    submitter_id uuid,
    petitioner_name character varying(100) NOT NULL,
    petitioner_email character varying(255) NOT NULL,
    representative character varying(100),
    respondent character varying(200),
    petition_type character varying(40) NOT NULL,
    title character varying(200) NOT NULL,
    challenged_norm text NOT NULL,
    constitutional_provisions text NOT NULL,
    petition_claim text NOT NULL,
    facts_and_reasons text NOT NULL,
    evidence text,
    attachments_description text,
    status character varying(30) DEFAULT 'submitted'::character varying NOT NULL,
    docketing_note text,
    decision_summary text,
    decided_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: line_account_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".line_account_links (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    line_user_id character varying(128) NOT NULL,
    line_display_name character varying(200),
    is_active boolean NOT NULL,
    linked_at timestamp with time zone NOT NULL,
    unlinked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: matter_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".matter_resources (
    id uuid NOT NULL,
    matter_id uuid NOT NULL,
    resource_type character varying(40) NOT NULL,
    title character varying(240) NOT NULL,
    url character varying(2048) NOT NULL,
    provider character varying(50),
    external_id character varying(255),
    description text,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: matter_role_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".matter_role_assignments (
    id uuid NOT NULL,
    matter_id uuid NOT NULL,
    parent_id uuid,
    role_name character varying(120) NOT NULL,
    unit_name character varying(120),
    user_id uuid,
    start_at timestamp with time zone,
    end_at timestamp with time zone,
    note text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: matters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".matters (
    id uuid NOT NULL,
    title character varying(240) NOT NULL,
    matter_type character varying(40) NOT NULL,
    description text,
    org_id uuid,
    owner_user_id uuid,
    starts_at timestamp with time zone,
    due_at timestamp with time zone,
    priority character varying(20) NOT NULL,
    visibility character varying(20) NOT NULL,
    status character varying(30) NOT NULL,
    progress_percent integer NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by_id uuid,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    slug character varying(300)
);


--
-- Name: merchandise_submission_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".merchandise_submission_files (
    id uuid NOT NULL,
    submission_id uuid NOT NULL,
    storage_key character varying(500) NOT NULL,
    filename character varying(500) NOT NULL,
    content_type character varying(100) NOT NULL,
    file_size integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    ai_detection_status character varying(30),
    ai_detection_evidence jsonb DEFAULT '[]'::jsonb NOT NULL,
    ai_detection_sha256 character varying(64),
    ai_detection_scanned_at timestamp with time zone,
    ai_detection_metadata jsonb DEFAULT '[]'::jsonb NOT NULL,
    ai_detection_version character varying(30)
);


--
-- Name: merchandise_submission_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".merchandise_submission_items (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    specification text,
    template_images jsonb DEFAULT '[]'::jsonb NOT NULL,
    custom_fields jsonb DEFAULT '[]'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_open_override boolean,
    opens_at_override timestamp with time zone,
    closes_at_override timestamp with time zone,
    max_file_size_mb_override integer,
    created_by_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    notification_enabled boolean,
    notification_recipient_ids jsonb
);


--
-- Name: merchandise_submission_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".merchandise_submission_settings (
    id uuid NOT NULL,
    is_open boolean DEFAULT false NOT NULL,
    opens_at timestamp with time zone,
    closes_at timestamp with time zone,
    max_file_size_mb integer DEFAULT 100 NOT NULL,
    announcement text,
    updated_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    require_school_email boolean DEFAULT true NOT NULL,
    announcement_title character varying(200),
    show_announcement_popup boolean DEFAULT false NOT NULL,
    announcement_id uuid,
    submission_intro text,
    global_fields jsonb DEFAULT '[]'::jsonb NOT NULL,
    notification_enabled boolean DEFAULT true NOT NULL,
    notification_recipient_ids jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: merchandise_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".merchandise_submissions (
    id uuid NOT NULL,
    item_id uuid NOT NULL,
    user_id uuid NOT NULL,
    status "__HCCA_SCHEMA__".merchandisesubmissionstatus NOT NULL,
    account_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    field_values jsonb DEFAULT '{}'::jsonb NOT NULL,
    submitted_at timestamp with time zone,
    reviewed_at timestamp with time zone,
    reviewer_id uuid,
    review_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    voting_survey_id uuid
);


--
-- Name: navigation_profile_positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".navigation_profile_positions (
    id uuid NOT NULL,
    profile_id uuid NOT NULL,
    position_id uuid NOT NULL
);


--
-- Name: navigation_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".navigation_profiles (
    id uuid NOT NULL,
    key character varying(50) NOT NULL,
    label character varying(100) NOT NULL,
    description text,
    audience character varying(200),
    priority integer DEFAULT 100 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    match_any_permissions jsonb NOT NULL,
    match_any_prefixes jsonb NOT NULL,
    exclude_permissions jsonb NOT NULL,
    exclude_prefixes jsonb NOT NULL,
    desktop_sections jsonb NOT NULL,
    mobile_order jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    title character varying(200) NOT NULL,
    body text,
    link character varying(500),
    is_read boolean DEFAULT false NOT NULL,
    related_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_inapp_visible boolean DEFAULT true NOT NULL,
    email_queued_at timestamp with time zone
);


--
-- Name: observability_releases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".observability_releases (
    id uuid NOT NULL,
    release character varying(128) NOT NULL,
    commit_sha character varying(64) NOT NULL,
    environment character varying(32) NOT NULL,
    deployed_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".order_items (
    id uuid NOT NULL,
    order_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer NOT NULL,
    unit_price integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    selected_options jsonb DEFAULT '[]'::jsonb NOT NULL,
    ordered_by_id uuid,
    ordered_by_name character varying(200),
    delegation_link_id uuid,
    delegation_name character varying(80),
    gift_quantity integer DEFAULT 0 NOT NULL,
    gift_discount_amount integer DEFAULT 0 NOT NULL
);


--
-- Name: order_serial_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "__HCCA_SCHEMA__".order_serial_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".orders (
    id uuid NOT NULL,
    serial_number character varying(30) NOT NULL,
    user_id uuid,
    status "__HCCA_SCHEMA__".orderstatus NOT NULL,
    total_price integer NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    class_id uuid,
    is_paid boolean DEFAULT false NOT NULL,
    paid_at timestamp with time zone,
    paid_by_id uuid,
    assistance_scope character varying(30) DEFAULT 'self'::character varying NOT NULL,
    assisted_by_id uuid,
    subtotal_price integer DEFAULT 0 NOT NULL,
    discount_amount integer DEFAULT 0 NOT NULL,
    promotion_code character varying(80),
    payment_method character varying(30) DEFAULT 'cash_on_pickup'::character varying NOT NULL,
    is_class_collected boolean DEFAULT false NOT NULL,
    class_collected_at timestamp with time zone,
    class_collected_by_id uuid,
    promotion_id uuid,
    activity_id uuid,
    category_id uuid,
    test_product_id uuid,
    supplement_class_id uuid,
    buyer_name character varying(100),
    buyer_office character varying(100),
    received_amount integer DEFAULT 0 NOT NULL,
    is_class_balance boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_orders_external_buyer CHECK (((user_id IS NOT NULL) OR (((assistance_scope)::text = 'sheet_import'::text) AND (buyer_name IS NOT NULL) AND (buyer_office IS NOT NULL))))
);


--
-- Name: orgs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".orgs (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    parent_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    prefix character varying(20),
    is_active boolean NOT NULL,
    leader_user_id uuid,
    default_permission_codes jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".outbox_events (
    id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    retry_count integer DEFAULT 0 NOT NULL,
    last_error text,
    processed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    next_attempt_at timestamp with time zone,
    locked_until timestamp with time zone,
    locked_by character varying(64)
);


--
-- Name: pagespeed_audits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".pagespeed_audits (
    id uuid NOT NULL,
    run_id uuid NOT NULL,
    audit_id character varying(128) NOT NULL,
    title text NOT NULL,
    score double precision,
    numeric_value double precision,
    display_value text
);


--
-- Name: pagespeed_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".pagespeed_runs (
    id uuid NOT NULL,
    url text NOT NULL,
    strategy character varying(16) NOT NULL,
    tested_at timestamp with time zone NOT NULL,
    release_id uuid,
    performance_score double precision,
    lcp_ms double precision,
    tbt_ms double precision,
    cls double precision,
    status character varying(16) NOT NULL,
    error_message text
);


--
-- Name: partner_application_fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_application_fields (
    id uuid NOT NULL,
    settings_id uuid NOT NULL,
    key character varying(50) NOT NULL,
    label character varying(100) NOT NULL,
    field_type character varying(20) DEFAULT 'text'::character varying NOT NULL,
    required boolean DEFAULT false NOT NULL,
    placeholder character varying(200),
    help_text character varying(500),
    options jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: partner_application_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_application_settings (
    id uuid NOT NULL,
    is_open boolean DEFAULT true NOT NULL,
    title character varying(200) DEFAULT '申請成為特約商家'::character varying NOT NULL,
    intro text DEFAULT '留下合作資訊，班聯會會在收到申請後與您聯繫。'::text NOT NULL,
    privacy_notice text,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: partner_business_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_business_accounts (
    id uuid NOT NULL,
    business_id uuid NOT NULL,
    user_id uuid NOT NULL,
    granted_by uuid,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: partner_business_applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_business_applications (
    id uuid NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    field_values jsonb NOT NULL,
    submitted_by uuid,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_note text,
    business_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: partner_business_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_business_images (
    id uuid NOT NULL,
    business_id uuid NOT NULL,
    storage_key text NOT NULL,
    filename character varying(255) NOT NULL,
    content_type character varying(120) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: partner_business_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_business_tags (
    business_id uuid NOT NULL,
    tag_id uuid NOT NULL
);


--
-- Name: partner_businesses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_businesses (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    summary character varying(300),
    description text,
    website_url text,
    social_url text,
    logo_url text,
    status character varying(20) NOT NULL,
    sort_order integer NOT NULL,
    internal_note text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    cover_image_url text,
    category character varying(50),
    business_hours_text character varying(300),
    listing_type character varying(20) DEFAULT 'physical'::character varying NOT NULL,
    contact_name character varying(100),
    contact_phone character varying(50),
    contact_email character varying(255),
    instagram_handle character varying(100),
    line_id character varying(100),
    other_contact text,
    flyer_storage_key text,
    flyer_filename character varying(255),
    flyer_content_type character varying(120),
    business_hours jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: partner_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_locations (
    id uuid NOT NULL,
    business_id uuid NOT NULL,
    name character varying(200),
    address character varying(300) NOT NULL,
    latitude double precision NOT NULL,
    longitude double precision NOT NULL,
    phone character varying(50),
    business_hours jsonb NOT NULL,
    google_place_id character varying(255),
    sort_order integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    google_maps_url text
);


--
-- Name: partner_offers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_offers (
    id uuid NOT NULL,
    business_id uuid NOT NULL,
    title character varying(200) NOT NULL,
    public_summary character varying(300),
    full_description text,
    instructions text,
    member_note text,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone,
    sort_order integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    benefit_type character varying(30) NOT NULL,
    benefit_value character varying(120)
);


--
-- Name: partner_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_submissions (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    category character varying(50),
    address character varying(300),
    latitude double precision,
    longitude double precision,
    reason text,
    offer_hint character varying(300),
    contact_hint character varying(200),
    status character varying(20) NOT NULL,
    submitted_by uuid,
    reviewed_by uuid,
    reviewed_at timestamp with time zone,
    review_note text,
    business_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    google_maps_url text
);


--
-- Name: partner_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".partner_tags (
    id uuid NOT NULL,
    name character varying(80) NOT NULL,
    color character varying(20),
    sort_order integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    icon_key character varying(40)
);


--
-- Name: passkey_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".passkey_credentials (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    credential_id bytea NOT NULL,
    public_key bytea NOT NULL,
    sign_count bigint DEFAULT '0'::bigint NOT NULL,
    device_name character varying(100) DEFAULT 'Passkey'::character varying NOT NULL,
    transports jsonb DEFAULT '[]'::jsonb NOT NULL,
    backed_up boolean DEFAULT false NOT NULL,
    aaguid character varying(64),
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: people; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".people (
    id uuid NOT NULL,
    user_id uuid,
    student_id character varying(20),
    display_name character varying(100) NOT NULL,
    legal_name character varying(100),
    email character varying(255),
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".permissions (
    id uuid NOT NULL,
    position_id uuid NOT NULL,
    code character varying(100) NOT NULL
);


--
-- Name: person_affiliations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".person_affiliations (
    id uuid NOT NULL,
    person_id uuid NOT NULL,
    kind character varying(30) NOT NULL,
    academic_year integer,
    class_id uuid,
    org_id uuid,
    position_id uuid,
    role_key character varying(50),
    title character varying(100),
    start_date date NOT NULL,
    end_date date,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    source character varying(30) DEFAULT 'manual'::character varying NOT NULL,
    synced_user_position_id uuid,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: petition_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".petition_attachments (
    id uuid NOT NULL,
    case_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    display_name character varying(255),
    storage_key character varying(500) NOT NULL,
    content_type character varying(100),
    file_size bigint,
    visibility "__HCCA_SCHEMA__".petitionattachmentvisibility NOT NULL,
    uploaded_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: petition_case_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".petition_case_events (
    id uuid NOT NULL,
    case_id uuid NOT NULL,
    event_type "__HCCA_SCHEMA__".petitioneventtype NOT NULL,
    visibility "__HCCA_SCHEMA__".petitioneventvisibility NOT NULL,
    actor_id uuid,
    from_org_id uuid,
    to_org_id uuid,
    from_status character varying(30),
    to_status character varying(30),
    title character varying(200) NOT NULL,
    content text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    related_document_id uuid
);


--
-- Name: petition_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".petition_cases (
    id uuid NOT NULL,
    case_number character varying(7) NOT NULL,
    verification_code_hash character varying(128),
    type_id uuid NOT NULL,
    status "__HCCA_SCHEMA__".petitionstatus NOT NULL,
    is_named boolean NOT NULL,
    submitter_id uuid,
    contact_name character varying(100),
    contact_email character varying(255),
    title character varying(200) NOT NULL,
    content text NOT NULL,
    public_reply text,
    latest_internal_note text,
    supplement_request text,
    rejection_reason text,
    current_org_id uuid NOT NULL,
    assigned_to_id uuid,
    submitted_at timestamp with time zone NOT NULL,
    assigned_at timestamp with time zone,
    first_response_at timestamp with time zone,
    resolved_at timestamp with time zone,
    closed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    discord_guild_id character varying(32),
    discord_channel_id character varying(32),
    discord_channel_created_at timestamp with time zone,
    share_token_hash character varying(64) NOT NULL,
    public_status "__HCCA_SCHEMA__".petitionpublicstatus DEFAULT 'not_requested'::"__HCCA_SCHEMA__".petitionpublicstatus NOT NULL,
    public_title character varying(200),
    public_content text,
    public_requested_at timestamp with time zone,
    public_user_responded_at timestamp with time zone,
    public_published_at timestamp with time zone,
    is_confidential boolean DEFAULT false NOT NULL,
    confidential_reason text
);


--
-- Name: petition_notification_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".petition_notification_rules (
    id uuid NOT NULL,
    petition_type_id uuid,
    org_id uuid,
    enabled boolean DEFAULT true NOT NULL,
    recipient_user_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    updated_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_petition_notification_rule_one_scope CHECK (((petition_type_id IS NOT NULL) <> (org_id IS NOT NULL)))
);


--
-- Name: petition_notification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".petition_notification_settings (
    id uuid NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    recipient_user_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    updated_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: petition_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".petition_types (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    responsible_org_id uuid NOT NULL,
    is_active boolean NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: planning_document_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".planning_document_attachments (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    display_name character varying(255),
    storage_key character varying(500) NOT NULL,
    content_type character varying(120) NOT NULL,
    file_size integer NOT NULL,
    uploaded_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: planning_document_revision_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".planning_document_revision_attachments (
    revision_id uuid NOT NULL,
    attachment_id uuid NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    sort_order integer NOT NULL
);


--
-- Name: planning_document_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".planning_document_revisions (
    id uuid NOT NULL,
    document_id uuid NOT NULL,
    version_number integer NOT NULL,
    version_label character varying(80) NOT NULL,
    content text NOT NULL,
    change_reason text,
    created_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: planning_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".planning_documents (
    id uuid NOT NULL,
    matter_id uuid NOT NULL,
    case_id uuid,
    title character varying(240) NOT NULL,
    summary text,
    status character varying(30) NOT NULL,
    current_version integer NOT NULL,
    created_by_id uuid,
    approved_at timestamp with time zone,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: policy_consents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".policy_consents (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    policy_document_id uuid NOT NULL,
    agreed_at timestamp with time zone NOT NULL,
    ip_address character varying(45),
    user_agent character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: policy_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".policy_documents (
    id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    version character varying(20) NOT NULL,
    title character varying(200) NOT NULL,
    content_md text NOT NULL,
    summary_md text,
    effective_at timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    published_by uuid,
    requires_explicit_consent boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".positions (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    parent_id uuid,
    weight integer DEFAULT 0 NOT NULL,
    category character varying(20) DEFAULT 'council'::character varying NOT NULL
);


--
-- Name: privacy_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".privacy_requests (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    request_type character varying(24) NOT NULL,
    status character varying(24) DEFAULT 'submitted'::character varying NOT NULL,
    subject character varying(200) NOT NULL,
    description text NOT NULL,
    submitted_ip_address character varying(45),
    submitted_user_agent character varying(500),
    response_message text,
    handled_by uuid,
    handled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".product_categories (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    image_url text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    activity_id uuid
);


--
-- Name: product_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".product_media (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    image_url text NOT NULL,
    kind character varying(20) NOT NULL,
    sort_order integer NOT NULL,
    label character varying(100),
    CONSTRAINT ck_product_media_kind CHECK (((kind)::text = ANY ((ARRAY['product'::character varying, 'model'::character varying])::text[])))
);


--
-- Name: product_series; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".product_series (
    id uuid NOT NULL,
    category_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    image_url text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_variant_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".product_variant_groups (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: product_variant_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".product_variant_options (
    id uuid NOT NULL,
    group_id uuid NOT NULL,
    value character varying(100) NOT NULL,
    image_url text,
    price_delta integer DEFAULT 0 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    original_price_delta integer,
    CONSTRAINT ck_product_variant_options_original_price_delta CHECK (((original_price_delta IS NULL) OR (original_price_delta >= price_delta)))
);


--
-- Name: products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".products (
    id uuid NOT NULL,
    version integer NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    price integer NOT NULL,
    stock_quantity integer NOT NULL,
    is_unlimited boolean NOT NULL,
    status "__HCCA_SCHEMA__".productstatus NOT NULL,
    sale_start timestamp with time zone,
    sale_end timestamp with time zone,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    image_url text,
    series_id uuid,
    requires_seating boolean DEFAULT false NOT NULL,
    seating_mode character varying(20),
    max_quantity_per_user integer,
    category_id uuid,
    purchase_rules jsonb DEFAULT '{}'::jsonb NOT NULL,
    original_price integer,
    unit_cost integer,
    size_chart jsonb,
    procurement_minimum integer DEFAULT 0 NOT NULL,
    procurement_stock integer DEFAULT 0 NOT NULL,
    procurement_reserve integer DEFAULT 0 NOT NULL,
    procurement_extra_cost integer DEFAULT 0 NOT NULL,
    procurement_note text DEFAULT ''::text NOT NULL,
    procurement_option_costs jsonb DEFAULT '{}'::jsonb NOT NULL,
    procurement_supplier_gift integer DEFAULT 0 NOT NULL,
    CONSTRAINT ck_products_category_or_series CHECK (((category_id IS NOT NULL) OR (series_id IS NOT NULL))),
    CONSTRAINT ck_products_max_quantity_per_user_positive CHECK (((max_quantity_per_user IS NULL) OR (max_quantity_per_user >= 1))),
    CONSTRAINT ck_products_original_price CHECK (((original_price IS NULL) OR (original_price >= price))),
    CONSTRAINT ck_products_procurement_nonnegative CHECK (((procurement_minimum >= 0) AND (procurement_stock >= 0) AND (procurement_reserve >= 0) AND (procurement_extra_cost >= 0))),
    CONSTRAINT ck_products_supplier_gift_nonnegative CHECK ((procurement_supplier_gift >= 0)),
    CONSTRAINT ck_products_unit_cost_nonnegative CHECK (((unit_cost IS NULL) OR (unit_cost >= 0)))
);


--
-- Name: programs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".programs (
    id uuid NOT NULL,
    matter_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    owner_user_id uuid,
    starts_at timestamp with time zone,
    due_at timestamp with time zone,
    status character varying(30) NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: public_link_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".public_link_categories (
    id uuid NOT NULL,
    slug character varying(80) NOT NULL,
    title character varying(100) NOT NULL,
    description text,
    sort_order integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: public_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".public_links (
    id uuid NOT NULL,
    title character varying(100) NOT NULL,
    url text NOT NULL,
    description text,
    category_id uuid,
    icon_key character varying(40),
    sort_order integer NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone
);


--
-- Name: public_officer_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".public_officer_profiles (
    id uuid NOT NULL,
    user_position_id uuid NOT NULL,
    display_name_override character varying(100),
    title_override character varying(120),
    bio text,
    public_email character varying(255),
    external_links jsonb NOT NULL,
    sort_order integer NOT NULL,
    is_featured boolean DEFAULT false NOT NULL,
    is_visible boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: public_site_page_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".public_site_page_views (
    id uuid NOT NULL,
    page_id uuid NOT NULL,
    visitor_hash character varying(64) NOT NULL,
    device_class character varying(16) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: public_site_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".public_site_pages (
    id uuid NOT NULL,
    slug character varying(80) NOT NULL,
    title character varying(120) NOT NULL,
    summary text,
    body_md text NOT NULL,
    page_kind character varying(30) DEFAULT 'standard'::character varying NOT NULL,
    layout_config jsonb NOT NULL,
    content_blocks jsonb NOT NULL,
    cover_image_url text,
    cover_image_alt character varying(200),
    seo_title character varying(120),
    seo_description character varying(300),
    nav_label character varying(60),
    nav_order integer NOT NULL,
    sort_order integer NOT NULL,
    show_in_nav boolean DEFAULT false NOT NULL,
    is_published boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: public_site_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".public_site_settings (
    id uuid NOT NULL,
    site_title character varying(120) NOT NULL,
    site_description text,
    hero_title character varying(120) NOT NULL,
    hero_subtitle text,
    hero_image_url text,
    hero_image_alt character varying(200),
    about_title character varying(120) NOT NULL,
    about_body_md text NOT NULL,
    mission_md text,
    history_md text,
    cta_label character varying(60) NOT NULL,
    cta_href character varying(500) NOT NULL,
    public_database_label character varying(60) NOT NULL,
    public_database_description text,
    theme_config jsonb NOT NULL,
    homepage_blocks jsonb NOT NULL,
    custom_css text,
    seo_title character varying(120),
    seo_description character varying(300),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    site_logo_url text,
    site_logo_alt character varying(200),
    support_md text,
    error_report_md text,
    contact_md text,
    terms_md text,
    developer_team_md text,
    system_info_md text
);


--
-- Name: publication_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".publication_campaigns (
    id uuid NOT NULL,
    title character varying(240) NOT NULL,
    body text NOT NULL,
    source_type character varying(50),
    source_id uuid,
    activity_id uuid,
    org_id uuid,
    audience_type character varying(50) NOT NULL,
    audience_filter jsonb NOT NULL,
    channels jsonb NOT NULL,
    status character varying(20) NOT NULL,
    scheduled_at timestamp with time zone,
    sent_at timestamp with time zone,
    created_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: publication_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".publication_deliveries (
    id uuid NOT NULL,
    campaign_id uuid NOT NULL,
    channel character varying(30) NOT NULL,
    recipient_user_id uuid,
    status character varying(20) NOT NULL,
    target character varying(255),
    provider_message_id character varying(255),
    error_detail text,
    sent_at timestamp with time zone,
    read_at timestamp with time zone,
    clicked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: raffle_draws; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".raffle_draws (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    session_id uuid NOT NULL,
    prize_id uuid NOT NULL,
    draw_number integer NOT NULL,
    idempotency_key character varying(80) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: raffle_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".raffle_events (
    id uuid NOT NULL,
    event_code character varying(32) NOT NULL,
    title character varying(160) NOT NULL,
    description text,
    access_code_hash character varying(64) NOT NULL,
    access_code_hint character varying(16) NOT NULL,
    status character varying(16) NOT NULL,
    draw_count integer NOT NULL,
    reserve_released boolean NOT NULL,
    created_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: raffle_prizes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".raffle_prizes (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    tier character varying(2) NOT NULL,
    name character varying(160) NOT NULL,
    total_quantity integer,
    remaining_quantity integer,
    sort_order integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: raffle_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".raffle_sessions (
    id uuid NOT NULL,
    event_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    device_id character varying(120),
    has_drawn boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: receivables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".receivables (
    id uuid NOT NULL,
    source_type character varying(50) NOT NULL,
    source_id uuid,
    activity_id uuid,
    org_id uuid,
    user_id uuid,
    class_id uuid,
    title character varying(240) NOT NULL,
    amount integer NOT NULL,
    paid_amount integer NOT NULL,
    refunded_amount integer NOT NULL,
    status character varying(20) NOT NULL,
    collected_by_id uuid,
    paid_at timestamp with time zone,
    refunded_at timestamp with time zone,
    due_at timestamp with time zone,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: recommended_vendor_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".recommended_vendor_categories (
    id uuid NOT NULL,
    name character varying(80) NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: recommended_vendor_menus; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".recommended_vendor_menus (
    id uuid NOT NULL,
    vendor_id uuid NOT NULL,
    title character varying(200) NOT NULL,
    kind character varying(20) NOT NULL,
    url text,
    storage_key text,
    filename character varying(255),
    content_type character varying(120),
    file_size integer,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: recommended_vendor_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".recommended_vendor_products (
    id uuid NOT NULL,
    vendor_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    price_text character varying(80),
    image_url text,
    menu_url text,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: recommended_vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".recommended_vendors (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    summary character varying(300),
    description text,
    category character varying(80),
    address character varying(300),
    latitude double precision,
    longitude double precision,
    google_maps_url text,
    business_hours_text character varying(300),
    contact_name character varying(100),
    contact_phone character varying(50),
    contact_email character varying(255),
    line_id character varying(100),
    social_url text,
    website_url text,
    ordering_instructions text,
    menu_url text,
    hygiene_inspection_date date,
    hygiene_inspection_expires_at date,
    hygiene_certificate_url text,
    hygiene_note text,
    status character varying(20) DEFAULT 'draft'::character varying NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    internal_note text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    category_id uuid,
    business_hours jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: regulation_articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".regulation_articles (
    id uuid NOT NULL,
    regulation_id uuid NOT NULL,
    sort_index integer NOT NULL,
    article_type "__HCCA_SCHEMA__".articletype NOT NULL,
    title character varying(200) DEFAULT ''::character varying NOT NULL,
    subtitle character varying(200) DEFAULT ''::character varying NOT NULL,
    content text,
    is_deleted boolean DEFAULT false NOT NULL,
    frozen_by character varying(200),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    order_index integer NOT NULL,
    parent_id uuid,
    legal_number character varying(50),
    lineage_id uuid NOT NULL
);


--
-- Name: regulation_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".regulation_revisions (
    id uuid NOT NULL,
    regulation_id uuid NOT NULL,
    version integer NOT NULL,
    change_brief character varying(500) NOT NULL,
    is_total_amendment boolean DEFAULT false NOT NULL,
    content_snapshot text DEFAULT ''::text NOT NULL,
    resolution_link text,
    amended_at timestamp with time zone NOT NULL,
    amended_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    article_snapshot text NOT NULL,
    proposal_metadata_snapshot text,
    amended_at_precision character varying(10) DEFAULT 'date'::character varying NOT NULL,
    amended_year integer
);


--
-- Name: regulation_sync_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".regulation_sync_sources (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    created_by uuid NOT NULL,
    folder_id character varying(200) NOT NULL,
    frequency character varying(10) NOT NULL,
    next_sync_at timestamp with time zone,
    requested_at timestamp with time zone,
    last_synced_at timestamp with time zone,
    last_report jsonb NOT NULL,
    manifest jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    extra_folder_ids jsonb DEFAULT '[]'::jsonb NOT NULL
);


--
-- Name: regulation_workflow_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".regulation_workflow_logs (
    id uuid NOT NULL,
    regulation_id uuid NOT NULL,
    from_status character varying(50) NOT NULL,
    to_status character varying(50) NOT NULL,
    actor_id uuid NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: regulations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".regulations (
    id uuid NOT NULL,
    title character varying(200) NOT NULL,
    category "__HCCA_SCHEMA__".regulationcategory NOT NULL,
    content text NOT NULL,
    version integer NOT NULL,
    is_active boolean NOT NULL,
    org_id uuid NOT NULL,
    created_by uuid NOT NULL,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    preface text,
    workflow_status "__HCCA_SCHEMA__".regulationworkflowstatus DEFAULT 'draft'::"__HCCA_SCHEMA__".regulationworkflowstatus NOT NULL,
    workflow_note text,
    published_document_id uuid,
    freeze_reason text,
    freeze_at timestamp with time zone,
    freeze_document_id uuid,
    amendment_type "__HCCA_SCHEMA__".regulationamendmenttype DEFAULT 'enact'::"__HCCA_SCHEMA__".regulationamendmenttype NOT NULL,
    amended_articles text,
    effective_date timestamp with time zone,
    legislative_history text,
    legal_basis text,
    proposal_metadata text,
    is_repealed boolean DEFAULT false NOT NULL,
    repealed_date timestamp with time zone,
    repeal_reason text,
    repeal_replacement_id uuid,
    search_vector tsvector,
    source_regulation_id uuid
);


--
-- Name: saved_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".saved_filters (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    scope character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description character varying(200),
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    share_path text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: school_classes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".school_classes (
    id uuid NOT NULL,
    academic_year integer NOT NULL,
    class_code character varying(20) NOT NULL,
    grade integer DEFAULT 0 NOT NULL,
    label character varying(100),
    is_active boolean DEFAULT true NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    org_id uuid
);


--
-- Name: seat_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".seat_assignments (
    id uuid NOT NULL,
    seat_id uuid NOT NULL,
    zone_id uuid NOT NULL,
    order_id uuid NOT NULL,
    order_item_id uuid,
    user_id uuid NOT NULL,
    assigned_by_id uuid,
    status "__HCCA_SCHEMA__".seatassignmentstatus DEFAULT 'active'::"__HCCA_SCHEMA__".seatassignmentstatus NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: seat_holds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".seat_holds (
    id uuid NOT NULL,
    seat_id uuid NOT NULL,
    zone_id uuid NOT NULL,
    user_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: seating_waves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".seating_waves (
    id uuid NOT NULL,
    zone_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    starts_at timestamp with time zone,
    audience jsonb DEFAULT '{}'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: seating_zones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".seating_zones (
    id uuid NOT NULL,
    product_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    description text,
    starts_at timestamp with time zone,
    seating_opens_at timestamp with time zone,
    hold_minutes integer DEFAULT 10 NOT NULL,
    layout jsonb DEFAULT '{}'::jsonb NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: seats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".seats (
    id uuid NOT NULL,
    zone_id uuid NOT NULL,
    label character varying(40) NOT NULL,
    block character varying(80),
    row_label character varying(20),
    x integer DEFAULT 0 NOT NULL,
    y integer DEFAULT 0 NOT NULL,
    seat_type character varying(40) DEFAULT 'normal'::character varying NOT NULL,
    price_delta integer DEFAULT 0 NOT NULL,
    status "__HCCA_SCHEMA__".seatstatus DEFAULT 'available'::"__HCCA_SCHEMA__".seatstatus NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shop_class_collections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_class_collections (
    id uuid NOT NULL,
    order_id uuid NOT NULL,
    amount integer NOT NULL,
    collected_at timestamp with time zone NOT NULL,
    actor_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shop_class_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_class_payments (
    id uuid NOT NULL,
    class_id uuid NOT NULL,
    activity_id uuid,
    is_paid boolean DEFAULT false NOT NULL,
    confirmed_at timestamp with time zone,
    confirmed_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shop_delegation_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_delegation_links (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    category_id uuid NOT NULL,
    activity_id uuid,
    name character varying(80) NOT NULL,
    token_hash character varying(64) NOT NULL,
    bound_user_id uuid,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shop_offices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_offices (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: shop_order_closes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_order_closes (
    id uuid NOT NULL,
    category_id uuid NOT NULL,
    class_id uuid,
    closed_by_id uuid NOT NULL,
    reopened_by_id uuid,
    reopened_at timestamp with time zone,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    closes_at timestamp with time zone
);


--
-- Name: shop_order_promotions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_order_promotions (
    order_id uuid NOT NULL,
    promotion_id uuid NOT NULL,
    discount_amount integer DEFAULT 0 NOT NULL
);


--
-- Name: shop_order_receipt_prints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_order_receipt_prints (
    order_id uuid NOT NULL,
    printed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shop_promotion_product_prices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_promotion_product_prices (
    promotion_id uuid NOT NULL,
    product_id uuid NOT NULL,
    unit_price integer NOT NULL,
    CONSTRAINT ck_shop_promotion_product_prices_nonnegative CHECK ((unit_price >= 0))
);


--
-- Name: shop_promotion_products; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_promotion_products (
    promotion_id uuid NOT NULL,
    product_id uuid NOT NULL
);


--
-- Name: shop_promotion_student_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_promotion_student_targets (
    promotion_id uuid NOT NULL,
    student_id character varying(20) NOT NULL
);


--
-- Name: shop_promotion_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_promotion_users (
    promotion_id uuid NOT NULL,
    user_id uuid NOT NULL
);


--
-- Name: shop_promotions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_promotions (
    id uuid NOT NULL,
    name character varying(200) NOT NULL,
    code character varying(80),
    target_user_id uuid,
    discount_type "__HCCA_SCHEMA__".shopdiscounttype NOT NULL,
    discount_value integer NOT NULL,
    min_order_price integer DEFAULT 0 NOT NULL,
    starts_at timestamp with time zone,
    ends_at timestamp with time zone,
    max_uses integer,
    used_count integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    description text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    min_quantity integer DEFAULT 1 NOT NULL,
    activity_id uuid,
    is_public boolean NOT NULL,
    target_category_ids jsonb,
    gift_quantity integer DEFAULT 1 NOT NULL
);


--
-- Name: shop_sheet_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_sheet_rows (
    id uuid NOT NULL,
    source_id uuid NOT NULL,
    response_key character varying(64) NOT NULL,
    content_hash character varying(64) NOT NULL,
    row_number integer NOT NULL,
    status character varying(20) NOT NULL,
    error character varying(500),
    order_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shop_sheet_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_sheet_sources (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    spreadsheet_id character varying(200) NOT NULL,
    sheet_name character varying(100) NOT NULL,
    category_id uuid NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_synced_at timestamp with time zone,
    last_error character varying(500),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shop_teacher_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".shop_teacher_profiles (
    user_id uuid NOT NULL,
    name character varying(100) NOT NULL,
    office_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: short_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".short_links (
    id uuid NOT NULL,
    slug character varying(80) NOT NULL,
    title character varying(120),
    target_url text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: support_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".support_approvals (
    id uuid NOT NULL,
    approval_number character varying(32) NOT NULL,
    requested_by uuid NOT NULL,
    approved_by uuid,
    ticket_id uuid,
    target_user_id uuid,
    action character varying(128) NOT NULL,
    payload jsonb NOT NULL,
    reason text NOT NULL,
    risk_level character varying(16) DEFAULT 'high'::character varying NOT NULL,
    status character varying(16) DEFAULT 'pending'::character varying NOT NULL,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    reviewed_at timestamp with time zone,
    executed_at timestamp with time zone,
    review_note text,
    result jsonb
);


--
-- Name: support_assistance_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".support_assistance_sessions (
    id uuid NOT NULL,
    assistance_code character varying(6) NOT NULL,
    user_id uuid NOT NULL,
    support_user_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    status character varying(16) DEFAULT 'waiting'::character varying NOT NULL,
    current_route character varying(512),
    client_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    joined_at timestamp with time zone,
    closed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: support_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".support_audit_logs (
    id uuid NOT NULL,
    actor_user_id uuid NOT NULL,
    target_user_id uuid,
    ticket_id uuid,
    action character varying(128) NOT NULL,
    resource_type character varying(64) NOT NULL,
    resource_id character varying(128),
    risk_level character varying(16) NOT NULL,
    reason text NOT NULL,
    before_data jsonb,
    after_data jsonb,
    request_id character varying(128),
    ip_address character varying(45),
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: support_guide_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".support_guide_entries (
    id uuid NOT NULL,
    slug character varying(120) NOT NULL,
    title character varying(200) NOT NULL,
    summary character varying(500) NOT NULL,
    body text NOT NULL,
    category character varying(64) DEFAULT 'general'::character varying NOT NULL,
    required_permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    route character varying(512),
    is_active boolean DEFAULT true NOT NULL,
    created_by_id uuid,
    updated_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: support_impersonation_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".support_impersonation_sessions (
    id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    real_user_id uuid NOT NULL,
    impersonated_user_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    mode character varying(16) DEFAULT 'read_only'::character varying NOT NULL,
    reason text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: support_ticket_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".support_ticket_events (
    id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    actor_user_id uuid,
    event_type character varying(48) NOT NULL,
    body text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".support_tickets (
    id uuid NOT NULL,
    ticket_number character varying(32) NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    user_id uuid,
    reported_by_user_id uuid,
    assigned_to_id uuid,
    channel character varying(32) DEFAULT 'internal'::character varying NOT NULL,
    priority character varying(16) DEFAULT 'normal'::character varying NOT NULL,
    status character varying(24) DEFAULT 'new'::character varying NOT NULL,
    error_code character varying(128),
    request_id character varying(128),
    related_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    resolution text,
    closed_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: survey_answers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".survey_answers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    response_id uuid NOT NULL,
    question_id uuid NOT NULL,
    answer_text text,
    answer_json text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    other_text text
);


--
-- Name: survey_questions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".survey_questions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    survey_id uuid NOT NULL,
    order_index integer DEFAULT 0 NOT NULL,
    question_text text NOT NULL,
    question_type "__HCCA_SCHEMA__".questiontype DEFAULT 'text'::"__HCCA_SCHEMA__".questiontype NOT NULL,
    is_required boolean DEFAULT true NOT NULL,
    options_json text,
    min_value integer,
    max_value integer,
    placeholder character varying(300),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    image_url character varying(500),
    min_length integer,
    max_length integer,
    validation_rule character varying(20),
    min_label character varying(50),
    max_label character varying(50),
    condition_json text,
    option_config_json text,
    option_image_sets_json text,
    description text,
    grid_columns_json text
);


--
-- Name: survey_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".survey_responses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    survey_id uuid NOT NULL,
    respondent_id uuid,
    anon_token character varying(64),
    submitted_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    respondent_email character varying(320)
);


--
-- Name: surveys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".surveys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title character varying(300) NOT NULL,
    description text,
    status "__HCCA_SCHEMA__".surveystatus DEFAULT 'draft'::"__HCCA_SCHEMA__".surveystatus NOT NULL,
    is_anonymous boolean DEFAULT false NOT NULL,
    allow_multiple boolean DEFAULT false NOT NULL,
    opens_at timestamp with time zone,
    closes_at timestamp with time zone,
    org_id uuid NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_public boolean NOT NULL,
    allowed_org_ids_json text,
    allowed_user_ids_json text,
    allowed_domains_json text,
    activity_id uuid,
    announcement text,
    announcement_title character varying(200),
    show_announcement_popup boolean DEFAULT false NOT NULL,
    announcement_id uuid,
    is_listed boolean DEFAULT true NOT NULL,
    allowed_grades_json text
);


--
-- Name: system_incident_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".system_incident_events (
    id uuid NOT NULL,
    incident_id uuid NOT NULL,
    event_type character varying(64) NOT NULL,
    actor_type character varying(32) NOT NULL,
    actor_id uuid,
    details json DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: system_incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".system_incidents (
    id uuid NOT NULL,
    error_id character varying(64) NOT NULL,
    fingerprint character varying(128) NOT NULL,
    severity character varying(16) DEFAULT 'P2'::character varying NOT NULL,
    status character varying(32) DEFAULT 'open'::character varying NOT NULL,
    service character varying(64) NOT NULL,
    environment character varying(32) NOT NULL,
    release_version character varying(128),
    title text NOT NULL,
    summary text,
    first_seen_at timestamp with time zone NOT NULL,
    last_seen_at timestamp with time zone NOT NULL,
    occurrence_count integer DEFAULT 1 NOT NULL,
    trace_id character varying(64),
    request_id character varying(128),
    automatic_recovery_attempted boolean DEFAULT false NOT NULL,
    automatic_recovery_succeeded boolean,
    recovery_action character varying(128),
    assigned_to uuid,
    resolved_at timestamp with time zone,
    resolution_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: timeline_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".timeline_events (
    id uuid NOT NULL,
    matter_id uuid,
    case_id uuid,
    event_type character varying(50) NOT NULL,
    title character varying(240) NOT NULL,
    body text,
    actor_id uuid,
    actor_email character varying(255),
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: user_google_tasks_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".user_google_tasks_configs (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    access_token_enc text,
    refresh_token_enc text,
    token_expiry timestamp with time zone,
    authorized_email character varying(254),
    authorized_at timestamp with time zone,
    google_tasklist_id character varying(256),
    last_sync_at timestamp with time zone,
    last_error character varying(500),
    sync_enabled boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".user_identities (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    provider character varying(50) NOT NULL,
    external_id character varying(255) NOT NULL,
    email character varying(255),
    display_name character varying(200),
    linked_at timestamp with time zone NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".user_positions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    position_id uuid NOT NULL,
    start_date date NOT NULL,
    end_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".user_sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    user_agent text,
    ip_address character varying(45),
    last_seen_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    refresh_jti_hash character varying(64) NOT NULL,
    previous_refresh_jti_hash character varying(64),
    auth_method character varying(32) NOT NULL,
    auth_time timestamp with time zone NOT NULL,
    rotated_at timestamp with time zone NOT NULL,
    absolute_expires_at timestamp with time zone NOT NULL,
    revoked_reason character varying(64)
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    display_name character varying(100) NOT NULL,
    avatar_url text,
    google_sub character varying(255),
    is_active boolean NOT NULL,
    is_verified boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_superuser boolean DEFAULT false NOT NULL,
    student_id character varying(20),
    show_email boolean DEFAULT true NOT NULL,
    notification_preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    mfa_enabled boolean DEFAULT false NOT NULL,
    mfa_secret text,
    mfa_pending_secret text,
    mfa_backup_code_hashes jsonb DEFAULT '{}'::jsonb NOT NULL,
    mfa_pending_backup_code_hashes jsonb DEFAULT '{}'::jsonb NOT NULL,
    ui_theme character varying(10) DEFAULT 'auto'::character varying NOT NULL,
    ui_locale character varying(10) DEFAULT 'zh-TW'::character varying NOT NULL
);


--
-- Name: vote_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".vote_events (
    id uuid NOT NULL,
    election_id uuid NOT NULL,
    ballot_box_id uuid NOT NULL,
    candidate_id uuid,
    kind character varying(20) NOT NULL,
    delta integer NOT NULL,
    reason character varying(300) NOT NULL,
    operator_id uuid NOT NULL,
    reverses_event_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: web_push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".web_push_subscriptions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    user_agent text,
    device_label character varying(100),
    is_active boolean NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: webhook_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".webhook_deliveries (
    id uuid NOT NULL,
    subscription_id uuid NOT NULL,
    event_type character varying(100) NOT NULL,
    payload jsonb NOT NULL,
    status character varying(20) NOT NULL,
    attempt_count integer NOT NULL,
    scheduled_at timestamp with time zone NOT NULL,
    last_attempted_at timestamp with time zone,
    succeeded_at timestamp with time zone,
    response_status integer,
    response_snippet text,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: webhook_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".webhook_subscriptions (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    owner_user_id uuid NOT NULL,
    url character varying(500) NOT NULL,
    events jsonb NOT NULL,
    secret character varying(200) NOT NULL,
    is_active boolean NOT NULL,
    max_retries integer NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: work_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".work_items (
    id uuid NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    status character varying(20) DEFAULT 'open'::character varying NOT NULL,
    assigned_to_id uuid,
    created_by_id uuid,
    source_type character varying(50),
    source_id uuid,
    due_at timestamp with time zone,
    reminder_sent_at timestamp with time zone,
    completed_at timestamp with time zone,
    discord_channel_id character varying(32),
    discord_message_id character varying(32),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    google_task_id character varying(256)
);


--
-- Name: workflow_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".workflow_events (
    id uuid NOT NULL,
    instance_id uuid NOT NULL,
    event_type character varying(50) NOT NULL,
    from_status character varying(50),
    to_status character varying(50),
    actor_id uuid,
    actor_email character varying(255),
    note text,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workflow_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".workflow_instances (
    id uuid NOT NULL,
    workflow_type character varying(50) NOT NULL,
    source_type character varying(50) NOT NULL,
    source_id uuid NOT NULL,
    title character varying(240) NOT NULL,
    status character varying(50) NOT NULL,
    current_step character varying(80),
    org_id uuid,
    activity_id uuid,
    created_by_id uuid,
    completed_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workflow_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "__HCCA_SCHEMA__".workflow_links (
    id uuid NOT NULL,
    instance_id uuid NOT NULL,
    target_type character varying(50) NOT NULL,
    target_id uuid,
    relation character varying(50) NOT NULL,
    title character varying(240) NOT NULL,
    href character varying(500),
    note text,
    meta jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: electronic_credential_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".electronic_credential_settings ALTER COLUMN id SET DEFAULT nextval('"__HCCA_SCHEMA__".electronic_credential_settings_id_seq'::regclass);


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: activity_conveners; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: activity_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: activity_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: activity_roles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: analytics_page_views; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: announcement_audience_orgs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: announcement_audience_users; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: announcement_media; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: announcement_reads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: audit_log_anchors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: automation_rules; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "__HCCA_SCHEMA__".automation_rules VALUES ('7e6880b4-89f9-598e-a495-710098439f8d', '陳情建立 → 開立治理事項並指派任務', '陳情送件後自動建立一件事情、開立處理案件、產生待辦並通知管理員。', 'petition.created', '{}', '[{"type": "create_matter", "title": "陳情處理：{title}", "matter_type": "petition"}, {"type": "create_case", "title": "受理與分派", "case_type": "petition"}, {"type": "create_task", "title": "指派承辦並於期限內回覆"}, {"body": "{title}", "type": "notify_admins", "title": "新陳情待處理"}]', NULL, 'paused', NULL, '2026-11-17 01:01:02.1592+08', '2026-11-17 01:01:02.1592+08', NULL, 0);
INSERT INTO "__HCCA_SCHEMA__".automation_rules VALUES ('7e175145-deda-5afd-a2b1-11f7b5e44071', '會議通過 → 提醒落實決議', '會議產生決議時，於連動事情建立追蹤任務並通知。', 'meeting.decision_created', '{"status": "passed"}', '[{"type": "create_task", "title": "落實決議：{title}"}, {"body": "{title}", "type": "notify_admins", "title": "決議待執行"}]', NULL, 'paused', NULL, '2026-11-17 01:01:02.1592+08', '2026-11-17 01:01:02.1592+08', NULL, 0);
INSERT INTO "__HCCA_SCHEMA__".automation_rules VALUES ('92a90dff-758a-5142-b029-ca523d9a0451', '活動結束 → 建立成果與檢討', '活動標記結束後，自動建立成果報告任務與檢討問卷任務。', 'activity.completed', '{}', '[{"type": "create_task", "title": "撰寫成果報告"}, {"type": "create_task", "title": "建立檢討會議與問卷"}]', NULL, 'paused', NULL, '2026-11-17 01:01:02.1592+08', '2026-11-17 01:01:02.1592+08', NULL, 0);
INSERT INTO "__HCCA_SCHEMA__".automation_rules VALUES ('6c9eb0ea-aeb4-5bcd-8a57-ab8bb89ce040', '公文核准 → 建立後續任務', '連動此公文的事情，在公文核准後自動開立後續處理任務。', 'document.approved', '{}', '[{"type": "create_task", "title": "公文核准後續：{title}"}]', NULL, 'paused', NULL, '2026-11-17 01:01:02.300468+08', '2026-11-17 01:01:02.300468+08', NULL, 0);
INSERT INTO "__HCCA_SCHEMA__".automation_rules VALUES ('701bb597-7470-543a-a0bb-b980c6a8796f', '法規公布 → 安排宣導', '法規公布後，於連動事情建立宣導公告任務並通知管理員。', 'regulation.published', '{}', '[{"type": "create_task", "title": "撰寫法規宣導公告"}, {"body": "{title}", "type": "notify_admins", "title": "法規已公布"}]', NULL, 'paused', NULL, '2026-11-17 01:01:02.300468+08', '2026-11-17 01:01:02.300468+08', NULL, 0);
INSERT INTO "__HCCA_SCHEMA__".automation_rules VALUES ('a9cc99c5-367f-5210-9605-aa1f0485df36', '提案排入議程 → 準備上會資料', '議會提案排入議程後，自動建立準備任務。', 'proposal.scheduled', '{}', '[{"type": "create_task", "title": "準備提案上會資料：{title}"}]', NULL, 'paused', NULL, '2026-11-17 01:01:02.300468+08', '2026-11-17 01:01:02.300468+08', NULL, 0);
INSERT INTO "__HCCA_SCHEMA__".automation_rules VALUES ('90f420bd-cbaa-5646-b7fc-3d7439f208a4', '問卷結束 → 整理結果', '問卷結束後，於連動事情建立成果整理任務。', 'survey.closed', '{}', '[{"type": "create_task", "title": "整理問卷結果並撰寫摘要"}]', NULL, 'paused', NULL, '2026-11-17 01:01:02.300468+08', '2026-11-17 01:01:02.300468+08', NULL, 0);


--
-- Data for Name: backup_records; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: class_cadres; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: class_confirmations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: class_correction_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: class_manual_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: class_memberships; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: class_role_bindings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: class_roster_entries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: class_student_ranges; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: council_proposals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: crux_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: decisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: defense_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discord_account_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discord_activity_workspaces; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discord_guild_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discord_member_sync_states; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discord_nickname_prefix_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discord_notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discord_notification_routes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discord_org_channel_mappings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discord_role_mappings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: discord_role_policies; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_approval_delegations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_approvals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_recipients; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_serial_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: document_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: election_ballot_boxes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: election_candidate_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: election_candidates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: elections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: electronic_credential_authorizations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: electronic_credential_settings; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "__HCCA_SCHEMA__".electronic_credential_settings VALUES (1, '["310", "410", "510"]', NULL, '2026-11-17 01:01:02.600715+08', '2026-11-17 01:01:02.600715+08');


--
-- Data for Name: email_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_campaign_recipients; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_messages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_recipient_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_recipient_list_members; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_recipient_lists; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_suppressions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_template_versions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: entity_relations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: exam_paper_downloads; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: exam_papers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: feature_flags; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "__HCCA_SCHEMA__".feature_flags VALUES ('40d9f43f-89b5-4b35-8076-c0c11872161b', 'email_scheduled_dispatch', '每 60 秒處理到期的預約郵件', true, 0, '[]', '[]', NULL, '2026-11-17 01:01:02.600715+08', '2026-11-17 01:01:02.600715+08');
INSERT INTO "__HCCA_SCHEMA__".feature_flags VALUES ('8cb7b38a-573f-44b9-8915-787ec385f44d', 'email_error_report', '寄送 API 與 Celery 錯誤通報信', true, 0, '[]', '[]', NULL, '2026-11-17 01:01:02.600715+08', '2026-11-17 01:01:02.600715+08');


--
-- Data for Name: finance_bank_transactions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budget_allocation_evidence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budget_allocation_revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budget_allocations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budget_expense_evidence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budget_expense_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budget_expenses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budget_income_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budget_income_records; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budget_nodes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budget_submissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_budgets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_chart_accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_expense_claim_item_evidence; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_expense_claim_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_fiscal_periods; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_fund_accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_journal_lines; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: finance_ledgers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: gallery_drive_sync; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: governance_cases; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: governance_discord_event_routes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: governance_discord_workspaces; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: governance_workflow_templates; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "__HCCA_SCHEMA__".governance_workflow_templates VALUES ('761c2009-e4d2-5537-a576-92e3ffd0f8a0', '活動流程', 'activity', '從構想到歸檔的完整活動生命週期', 1, '[{"key": "idea", "label": "構想"}, {"key": "plan", "label": "企劃"}, {"key": "review", "label": "審議"}, {"key": "approve", "label": "核准"}, {"key": "organize", "label": "組織建立"}, {"key": "execute", "label": "執行"}, {"key": "report", "label": "成果報告"}, {"key": "archive", "label": "歸檔"}]', NULL, true, '2026-11-17 01:01:02.1592+08', '2026-11-17 01:01:02.1592+08');
INSERT INTO "__HCCA_SCHEMA__".governance_workflow_templates VALUES ('55eb5c45-a78c-57bf-bca7-de14d378f148', '法規修正流程', 'regulation', '法規草案到公布的審議流程', 1, '[{"key": "draft", "label": "提出草案"}, {"key": "agenda", "label": "排入議程"}, {"key": "deliberate", "label": "會議審議"}, {"key": "revise", "label": "修正"}, {"key": "approve", "label": "議會核定"}, {"key": "publish", "label": "公布施行"}]', NULL, true, '2026-11-17 01:01:02.1592+08', '2026-11-17 01:01:02.1592+08');
INSERT INTO "__HCCA_SCHEMA__".governance_workflow_templates VALUES ('b99185dc-d2f0-5f21-b146-04dfc3407e49', '陳情處理流程', 'petition', '陳情自收件到結案', 1, '[{"key": "received", "label": "收件"}, {"key": "assign", "label": "分派承辦"}, {"key": "process", "label": "處理中"}, {"key": "reply", "label": "回覆"}, {"key": "close", "label": "結案"}]', NULL, true, '2026-11-17 01:01:02.1592+08', '2026-11-17 01:01:02.1592+08');
INSERT INTO "__HCCA_SCHEMA__".governance_workflow_templates VALUES ('d3a13697-3cf7-51a7-9e1a-6083de1b0f54', '評議審查流程', 'judicial', '評議委員會審查', 1, '[{"key": "submit", "label": "提出"}, {"key": "accept", "label": "受理"}, {"key": "review", "label": "審查"}, {"key": "decide", "label": "決議"}, {"key": "archive", "label": "歸檔"}]', NULL, true, '2026-11-17 01:01:02.1592+08', '2026-11-17 01:01:02.1592+08');
INSERT INTO "__HCCA_SCHEMA__".governance_workflow_templates VALUES ('a3c5a803-49e7-51d6-906f-e6d96fa107a5', '採購流程', 'procurement', '設備/廠商採購', 1, '[{"key": "request", "label": "需求提出"}, {"key": "quote", "label": "詢價比價"}, {"key": "approve", "label": "核准"}, {"key": "order", "label": "下單"}, {"key": "accept", "label": "驗收"}]', NULL, true, '2026-11-17 01:01:02.1592+08', '2026-11-17 01:01:02.1592+08');


--
-- Data for Name: inventory_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory_procurement_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory_procurements; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: inventory_transactions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: judicial_petitions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: line_account_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: matter_resources; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: matter_role_assignments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: matters; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: merchandise_submission_files; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: merchandise_submission_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: merchandise_submission_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: merchandise_submissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: navigation_profile_positions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: navigation_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "__HCCA_SCHEMA__".navigation_profiles VALUES ('61f23241-2077-4e45-ad6c-4b2042da815d', 'mealVendor', '餐商視角', '把畫面集中在餐商管理、學餐訂購狀態、待辦與個人設定。', '學生餐廳、合作餐商、供餐窗口', 10, true, true, '[]', '["meal:"]', '[]', '["document:", "regulation:", "admin:", "shop:", "finance:", "org:", "petition:", "election:"]', '[{"id": "meal-vendor-main", "items": ["mealVendor", "meal", "tasks", "settings"], "heading": "餐商工作台", "collapsible": false, "default_collapsed": false}]', '["mealVendor", "meal", "tasks", "settings"]', '2026-11-17 01:01:02.600715+08', '2026-11-17 01:01:02.600715+08');
INSERT INTO "__HCCA_SCHEMA__".navigation_profiles VALUES ('2fc04c56-25fb-4524-929d-fa6955c8f7a7', 'teacher', '教職員視角', '保留教職員常用的通知、行事曆、問卷、題庫、班級收單與學餐入口。', '導師、行政老師、協助班級或教學服務的教職員', 20, true, true, '["survey:review", "survey:manage"]', '["class:", "exam:"]', '[]', '[]', '[{"id": "teacher-main", "items": ["dashboard", "tasks", "announcements"], "heading": "教職員工作台", "collapsible": false, "default_collapsed": false}, {"id": "teacher-services", "items": ["surveys", "examPapers", "shopOrders", "meal", "settings", "merchandiseSubmissions", "recommendedVendors"], "heading": "常用模組", "collapsible": false, "default_collapsed": false}]', '["dashboard", "tasks", "surveys", "examPapers", "shopOrders", "meal", "settings", "merchandiseSubmissions", "recommendedVendors"]', '2026-11-17 01:01:02.600715+08', '2026-11-17 01:01:02.600715+08');
INSERT INTO "__HCCA_SCHEMA__".navigation_profiles VALUES ('10ecea23-8a00-4ebc-af06-91cfe8de265e', 'default', '完整平台視角', '提供學生會幹部、管理員與一般平台使用者完整導覽，再依權限隱藏不可用項目。', '學生代表、學生會幹部、系統管理員', 1000, true, true, '[]', '[]', '[]', '[]', '[{"id": "main", "items": ["dashboard", "tasks", "announcements"], "heading": "主要", "collapsible": false, "default_collapsed": false}, {"id": "platform", "items": ["governanceHub", "documents", "councilProposals", "regulations", "judicialPetitions", "surveys", "petitions", "meal", "shop", "shopOrders", "partnerMap", "examPapers", "merchandiseSubmissions", "recommendedVendors"], "heading": "自治與服務", "collapsible": false, "default_collapsed": false}, {"id": "workbench", "items": ["operations", "moduleBackoffice", "adminDashboard", "navigationProfiles", "settings", "about"], "heading": "工作後台", "collapsible": true, "default_collapsed": true}]', '["dashboard", "tasks", "governanceHub", "councilProposals", "documents", "regulations", "judicialPetitions", "examPapers", "meal", "shop", "shopOrders", "surveys", "announcements", "partnerMap", "petitions", "settings", "merchandiseSubmissions", "recommendedVendors"]', '2026-11-17 01:01:02.600715+08', '2026-11-17 01:01:02.600715+08');
INSERT INTO "__HCCA_SCHEMA__".navigation_profiles VALUES ('05cae429-75ad-45f4-a1ff-8ce8a2673119', 'public', '公開查詢視角', '提供未登入訪客檢視公開公告、公文、法規與校園服務資訊。', '未登入訪客', 900, true, true, '[]', '[]', '[]', '[]', '[{"id": "public-main", "items": ["publicRegulations", "publicDocuments", "publicAnnouncements", "publicPartnerMap", "publicRecommendedVendors", "publicPetition", "publicAbout"], "heading": "公開查詢", "collapsible": false, "default_collapsed": false}]', '["publicRegulations", "publicDocuments", "publicAnnouncements", "publicPartnerMap", "publicRecommendedVendors", "publicPetition", "publicAbout"]', '2026-11-17 01:01:02.600715+08', '2026-11-17 01:01:02.600715+08');
INSERT INTO "__HCCA_SCHEMA__".navigation_profiles VALUES ('6f0eac5d-dd1d-4b95-baf2-1b4fdd9fbb8a', 'student', '一般學生視角', '集中一般學生最常使用的公告、公開公文與法規、問卷及校園服務。', '一般學生、未持有行政或商家管理權限的登入使用者', 950, true, true, '[]', '[]', '[]', '[]', '[{"id": "student-main", "items": ["dashboard", "announcements", "documents", "regulations", "surveys"], "heading": "我的校園服務", "collapsible": false, "default_collapsed": false}, {"id": "student-services", "items": ["meal", "shop", "merchandiseSubmissions", "partnerMap", "recommendedVendors", "examPapers", "settings"], "heading": "常用入口", "collapsible": false, "default_collapsed": false}]', '["dashboard", "announcements", "surveys", "meal", "shop", "merchandiseSubmissions", "petitions", "partnerMap", "settings"]', '2026-11-17 01:01:02.600715+08', '2026-11-17 01:01:02.600715+08');


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: observability_releases; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: orgs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pagespeed_audits; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: pagespeed_runs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_application_fields; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_application_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_business_accounts; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_business_applications; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_business_images; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_business_tags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_businesses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_locations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_offers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_submissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: partner_tags; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: passkey_credentials; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: person_affiliations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: petition_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: petition_case_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: petition_cases; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: petition_notification_rules; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: petition_notification_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: petition_types; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: planning_document_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: planning_document_revision_attachments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: planning_document_revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: planning_documents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: policy_consents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: policy_documents; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "__HCCA_SCHEMA__".policy_documents VALUES ('77fbaa65-e3cf-4f12-9f36-96001dbeb248', 'privacy', '1.0.0', '隱私政策 v1.0.0', '# 隱私政策

本平台由新竹高中學生代表大會營運，用於學生自治、公共服務與學生權益治理。平台依個人資料保護法與資料最小化原則處理資料。

## 蒐集資料

我們可能處理姓名、學號、學校信箱、Google OAuth 識別碼、職務/班級資訊、登入與操作紀錄、IP、User-Agent、通知偏好，以及你在公文、法規、會議、購票、學餐、問卷、陳情等模組中主動提供或依法產生的資料。

## 使用目的

資料僅用於身份驗證、權限控管、學生自治流程、通知送達、安全稽核、事故調查、資料備份、依法保存與去識別化統計。

## 保存與刪除

一般帳號資料於最後活動後依資料保存政策保留；公文、法規、會議、稽核等具公共利益或法定保存價值的紀錄不直接刪除，但可依請求進行假名化或限制處理。

## 你的權利

你可以請求查詢、閱覽、匯出、更正、刪除、停止蒐集處理或限制使用。請於「隱私與資料請求」頁送出申請，平台會驗證身分並留下處理紀錄。

## 第三方處理者

平台可能使用 Google OAuth、Cloudflare、Sentry、AWS/S3、LINE、Discord、Email/SMTP 等服務。第三方僅依平台指示與必要範圍處理資料。

## 聯絡窗口

隱私權問題請聯絡平台管理團隊或學生代表大會指定窗口。正式上線前應替換為實際信箱。', '個資權利、資料最小化、保存期限與第三方處理者的正式版本。', '2026-05-31 00:00:00+08', true, NULL, true, '2026-11-17 01:01:00.145405+08', '2026-11-17 01:01:00.145405+08');
INSERT INTO "__HCCA_SCHEMA__".policy_documents VALUES ('a57c403d-41c3-4b8b-8a62-7bc6ac1ea894', 'terms', '1.0.0', '服務條款 v1.0.0', '# 服務條款

使用本平台即表示你同意依學生自治目的、平台規範與中華民國法律使用服務。

## 服務範圍

平台提供公文簽核、法規查詢、會議、公告、購票、學餐、問卷、陳情、通知與相關管理功能。部分資料屬公開治理資訊，部分資料僅限授權角色處理。

## 使用者義務

你應妥善保管帳號，不得共用、冒用、繞過權限、干擾服務、批量擷取非公開資料、上傳違法或侵害他人權益之內容。

## 權限與停權

平台得依職務、班級、任期、法規或安全風險調整權限。違反條款或造成資安風險時，得暫停帳號或限制功能，並保留稽核紀錄。

## 服務維護

平台可能因維護、事故、資安事件或第三方服務異常暫停部分功能，將盡可能公告並保留復原紀錄。

## 條款更新

重大更新會要求重新同意。不同意新版條款時，可能無法繼續使用需登入或寫入資料的功能。', '平台使用規則、帳號義務、停權與服務中斷處理。', '2026-05-31 00:00:00+08', true, NULL, true, '2026-11-17 01:01:00.146706+08', '2026-11-17 01:01:00.146706+08');
INSERT INTO "__HCCA_SCHEMA__".policy_documents VALUES ('23b69643-2fde-4a31-844f-2d0b072c061a', 'cookie', '1.0.0', 'Cookie 政策 v1.0.0', '# HCCA Cookie 政策

平台使用 Cookie 與瀏覽器儲存空間維持登入、安全防護與偏好設定。

## 必要 Cookie

必要 Cookie 用於登入狀態、CSRF 防護、OAuth 流程、維護模式、防濫用與安全稽核。停用後平台可能無法正常登入或送出表單。

## 偏好資料

主題、導覽排序、首次提示關閉狀態等偏好可能存於 localStorage。這些資料通常只存在你的裝置上。

## 分析與錯誤追蹤

若啟用 PostHog 或 Sentry，平台會以最小化方式紀錄頁面瀏覽、效能與錯誤資訊，預設不送出完整個資內容。

## 管理方式

你可以在瀏覽器清除 Cookie 與網站資料；清除後需重新登入，部分偏好會重設。', '必要 Cookie、偏好設定與分析工具使用說明。', '2026-05-31 00:00:00+08', true, NULL, true, '2026-11-17 01:01:00.147419+08', '2026-11-17 01:01:00.147419+08');
INSERT INTO "__HCCA_SCHEMA__".policy_documents VALUES ('70080db8-3c2c-4ea0-9316-c161cebc4c01', 'accessibility', '1.0.0', '無障礙聲明 v1.0.0', '# 無障礙聲明

平台目標是讓學生、幹部、教職員與公眾能以鍵盤、螢幕閱讀器與不同裝置完成主要流程。

## 設計原則

平台盡量提供語意化標記、清楚焦點、足夠對比、可縮放文字、減少動態效果設定與可理解的錯誤訊息。

## 已知限制

部分複雜編輯器、地圖、拖拉排序與舊頁面仍可能需要替代操作或進一步改善。

## 回報方式

若你因視覺、聽覺、肢體、認知或裝置限制無法使用功能，請回報頁面、操作步驟與需要的替代方式。平台會優先處理影響核心自治權益的流程。', '鍵盤操作、對比、輔助科技與問題回報承諾。', '2026-05-31 00:00:00+08', true, NULL, false, '2026-11-17 01:01:00.148169+08', '2026-11-17 01:01:00.148169+08');
INSERT INTO "__HCCA_SCHEMA__".policy_documents VALUES ('acff30ff-5f5d-460f-aa0e-e07ef6069e06', 'security', '1.0.0', '安全揭露政策 v1.0.0', '# 安全揭露政策

如果你發現漏洞，請以負責任方式回報。請不要存取、修改、下載或公開非自己的資料。

## 回報內容

請提供漏洞摘要、影響範圍、重現步驟、截圖或錄影、你的聯絡方式。正式上線前應設定專用安全信箱與 PGP key。

## 我們的承諾

平台會在合理時間內確認、評估、修補並回覆。善意研究者若遵守本政策且不造成損害，平台不會主張懲戒或法律追究。

## 禁止事項

禁止破壞服務、社交工程、持續掃描、外洩資料、植入後門、攻擊第三方服務或公開未修補漏洞。', '漏洞回報、負責任揭露與禁止行為。', '2026-05-31 00:00:00+08', true, NULL, false, '2026-11-17 01:01:00.148906+08', '2026-11-17 01:01:00.148906+08');


--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: privacy_requests; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_media; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_series; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_variant_groups; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: product_variant_options; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: programs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: public_link_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: public_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: public_officer_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: public_site_page_views; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: public_site_pages; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: public_site_settings; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: publication_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: publication_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: raffle_draws; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: raffle_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: raffle_prizes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: raffle_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: receivables; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recommended_vendor_categories; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recommended_vendor_menus; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recommended_vendor_products; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: recommended_vendors; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: regulation_articles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: regulation_revisions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: regulation_sync_sources; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: regulation_workflow_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: regulations; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: saved_filters; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: school_classes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: seat_assignments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: seat_holds; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: seating_waves; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: seating_zones; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: seats; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_class_collections; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_class_payments; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_delegation_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_offices; Type: TABLE DATA; Schema: public; Owner: -
--

INSERT INTO "__HCCA_SCHEMA__".shop_offices VALUES ('1c606889-2e10-47c5-bf3f-aef4da985cef', '國文科', true, '2026-11-17 01:01:02.600715+08', '2026-11-17 01:01:02.600715+08', 0);
INSERT INTO "__HCCA_SCHEMA__".shop_offices VALUES ('f0cf65ef-042e-472e-9a57-5f580923c370', '學務處', true, '2026-11-17 01:01:02.600715+08', '2026-11-17 01:01:02.600715+08', 1);


--
-- Data for Name: shop_order_closes; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_order_promotions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_order_receipt_prints; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_promotion_product_prices; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_promotion_products; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_promotion_student_targets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_promotion_users; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_promotions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_sheet_rows; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_sheet_sources; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: shop_teacher_profiles; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: short_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: support_approvals; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: support_assistance_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: support_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: support_guide_entries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: support_impersonation_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: support_ticket_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: survey_answers; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: survey_questions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: survey_responses; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: surveys; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: system_incident_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: system_incidents; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: timeline_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_google_tasks_configs; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_identities; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_positions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: vote_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: web_push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhook_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: webhook_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: work_items; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_events; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_instances; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Data for Name: workflow_links; Type: TABLE DATA; Schema: public; Owner: -
--



--
-- Name: document_serial_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"__HCCA_SCHEMA__".document_serial_seq', 1, false);


--
-- Name: electronic_credential_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"__HCCA_SCHEMA__".electronic_credential_settings_id_seq', 1, false);


--
-- Name: order_serial_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"__HCCA_SCHEMA__".order_serial_seq', 1, false);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: activity_conveners activity_conveners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_conveners
    ADD CONSTRAINT activity_conveners_pkey PRIMARY KEY (id);


--
-- Name: activity_links activity_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_links
    ADD CONSTRAINT activity_links_pkey PRIMARY KEY (id);


--
-- Name: activity_members activity_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_members
    ADD CONSTRAINT activity_members_pkey PRIMARY KEY (id);


--
-- Name: activity_roles activity_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_roles
    ADD CONSTRAINT activity_roles_pkey PRIMARY KEY (id);


--
-- Name: analytics_page_views analytics_page_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".analytics_page_views
    ADD CONSTRAINT analytics_page_views_pkey PRIMARY KEY (id);


--
-- Name: announcement_audience_orgs announcement_audience_orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_audience_orgs
    ADD CONSTRAINT announcement_audience_orgs_pkey PRIMARY KEY (announcement_id, org_id);


--
-- Name: announcement_audience_users announcement_audience_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_audience_users
    ADD CONSTRAINT announcement_audience_users_pkey PRIMARY KEY (announcement_id, user_id);


--
-- Name: announcement_media announcement_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_media
    ADD CONSTRAINT announcement_media_pkey PRIMARY KEY (id);


--
-- Name: announcement_reads announcement_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_reads
    ADD CONSTRAINT announcement_reads_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_log_anchors audit_log_anchors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".audit_log_anchors
    ADD CONSTRAINT audit_log_anchors_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: automation_rules automation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".automation_rules
    ADD CONSTRAINT automation_rules_pkey PRIMARY KEY (id);


--
-- Name: backup_records backup_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".backup_records
    ADD CONSTRAINT backup_records_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- Name: class_cadres class_cadres_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_cadres
    ADD CONSTRAINT class_cadres_pkey PRIMARY KEY (id);


--
-- Name: class_confirmations class_confirmations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_confirmations
    ADD CONSTRAINT class_confirmations_pkey PRIMARY KEY (id);


--
-- Name: class_correction_requests class_correction_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_correction_requests
    ADD CONSTRAINT class_correction_requests_pkey PRIMARY KEY (id);


--
-- Name: class_manual_members class_manual_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_manual_members
    ADD CONSTRAINT class_manual_members_pkey PRIMARY KEY (id);


--
-- Name: class_memberships class_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_memberships
    ADD CONSTRAINT class_memberships_pkey PRIMARY KEY (id);


--
-- Name: class_role_bindings class_role_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_role_bindings
    ADD CONSTRAINT class_role_bindings_pkey PRIMARY KEY (id);


--
-- Name: class_roster_entries class_roster_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_roster_entries
    ADD CONSTRAINT class_roster_entries_pkey PRIMARY KEY (id);


--
-- Name: class_student_ranges class_student_ranges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_student_ranges
    ADD CONSTRAINT class_student_ranges_pkey PRIMARY KEY (id);


--
-- Name: council_proposals council_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".council_proposals
    ADD CONSTRAINT council_proposals_pkey PRIMARY KEY (id);


--
-- Name: crux_snapshots crux_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".crux_snapshots
    ADD CONSTRAINT crux_snapshots_pkey PRIMARY KEY (id);


--
-- Name: decisions decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".decisions
    ADD CONSTRAINT decisions_pkey PRIMARY KEY (id);


--
-- Name: defense_rules defense_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".defense_rules
    ADD CONSTRAINT defense_rules_pkey PRIMARY KEY (id);


--
-- Name: discord_account_links discord_account_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_account_links
    ADD CONSTRAINT discord_account_links_pkey PRIMARY KEY (id);


--
-- Name: discord_activity_workspaces discord_activity_workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_activity_workspaces
    ADD CONSTRAINT discord_activity_workspaces_pkey PRIMARY KEY (id);


--
-- Name: discord_guild_configs discord_guild_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_guild_configs
    ADD CONSTRAINT discord_guild_configs_pkey PRIMARY KEY (id);


--
-- Name: discord_member_sync_states discord_member_sync_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_member_sync_states
    ADD CONSTRAINT discord_member_sync_states_pkey PRIMARY KEY (id);


--
-- Name: discord_nickname_prefix_rules discord_nickname_prefix_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_nickname_prefix_rules
    ADD CONSTRAINT discord_nickname_prefix_rules_pkey PRIMARY KEY (id);


--
-- Name: discord_notification_preferences discord_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_notification_preferences
    ADD CONSTRAINT discord_notification_preferences_pkey PRIMARY KEY (user_id);


--
-- Name: discord_notification_routes discord_notification_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_notification_routes
    ADD CONSTRAINT discord_notification_routes_pkey PRIMARY KEY (id);


--
-- Name: discord_org_channel_mappings discord_org_channel_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_org_channel_mappings
    ADD CONSTRAINT discord_org_channel_mappings_pkey PRIMARY KEY (id);


--
-- Name: discord_role_mappings discord_role_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_role_mappings
    ADD CONSTRAINT discord_role_mappings_pkey PRIMARY KEY (id);


--
-- Name: discord_role_policies discord_role_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_role_policies
    ADD CONSTRAINT discord_role_policies_pkey PRIMARY KEY (id);


--
-- Name: document_approval_delegations document_approval_delegations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_approval_delegations
    ADD CONSTRAINT document_approval_delegations_pkey PRIMARY KEY (id);


--
-- Name: document_approvals document_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_approvals
    ADD CONSTRAINT document_approvals_pkey PRIMARY KEY (id);


--
-- Name: document_attachments document_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_attachments
    ADD CONSTRAINT document_attachments_pkey PRIMARY KEY (id);


--
-- Name: document_recipients document_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_recipients
    ADD CONSTRAINT document_recipients_pkey PRIMARY KEY (id);


--
-- Name: document_revisions document_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_revisions
    ADD CONSTRAINT document_revisions_pkey PRIMARY KEY (id);


--
-- Name: document_serial_templates document_serial_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_serial_templates
    ADD CONSTRAINT document_serial_templates_pkey PRIMARY KEY (id);


--
-- Name: document_templates document_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_templates
    ADD CONSTRAINT document_templates_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: election_ballot_boxes election_ballot_boxes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".election_ballot_boxes
    ADD CONSTRAINT election_ballot_boxes_pkey PRIMARY KEY (id);


--
-- Name: election_candidate_members election_candidate_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".election_candidate_members
    ADD CONSTRAINT election_candidate_members_pkey PRIMARY KEY (id);


--
-- Name: election_candidates election_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".election_candidates
    ADD CONSTRAINT election_candidates_pkey PRIMARY KEY (id);


--
-- Name: elections elections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".elections
    ADD CONSTRAINT elections_pkey PRIMARY KEY (id);


--
-- Name: electronic_credential_authorizations electronic_credential_authorizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".electronic_credential_authorizations
    ADD CONSTRAINT electronic_credential_authorizations_pkey PRIMARY KEY (id);


--
-- Name: electronic_credential_settings electronic_credential_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".electronic_credential_settings
    ADD CONSTRAINT electronic_credential_settings_pkey PRIMARY KEY (id);


--
-- Name: email_attachments email_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_attachments
    ADD CONSTRAINT email_attachments_pkey PRIMARY KEY (id);


--
-- Name: email_campaign_recipients email_campaign_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_campaign_recipients
    ADD CONSTRAINT email_campaign_recipients_pkey PRIMARY KEY (id);


--
-- Name: email_messages email_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_messages
    ADD CONSTRAINT email_messages_pkey PRIMARY KEY (id);


--
-- Name: email_recipient_events email_recipient_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_recipient_events
    ADD CONSTRAINT email_recipient_events_pkey PRIMARY KEY (id);


--
-- Name: email_recipient_list_members email_recipient_list_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_recipient_list_members
    ADD CONSTRAINT email_recipient_list_members_pkey PRIMARY KEY (id);


--
-- Name: email_recipient_lists email_recipient_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_recipient_lists
    ADD CONSTRAINT email_recipient_lists_pkey PRIMARY KEY (id);


--
-- Name: email_suppressions email_suppressions_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_suppressions
    ADD CONSTRAINT email_suppressions_email_key UNIQUE (email);


--
-- Name: email_suppressions email_suppressions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_suppressions
    ADD CONSTRAINT email_suppressions_pkey PRIMARY KEY (id);


--
-- Name: email_template_versions email_template_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_template_versions
    ADD CONSTRAINT email_template_versions_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: entity_relations entity_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".entity_relations
    ADD CONSTRAINT entity_relations_pkey PRIMARY KEY (id);


--
-- Name: exam_paper_downloads exam_paper_downloads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".exam_paper_downloads
    ADD CONSTRAINT exam_paper_downloads_pkey PRIMARY KEY (id);


--
-- Name: exam_papers exam_papers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".exam_papers
    ADD CONSTRAINT exam_papers_pkey PRIMARY KEY (id);


--
-- Name: feature_flags feature_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".feature_flags
    ADD CONSTRAINT feature_flags_pkey PRIMARY KEY (id);


--
-- Name: finance_bank_transactions finance_bank_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_bank_transactions
    ADD CONSTRAINT finance_bank_transactions_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_allocation_evidence finance_budget_allocation_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocation_evidence
    ADD CONSTRAINT finance_budget_allocation_evidence_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_allocation_revisions finance_budget_allocation_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocation_revisions
    ADD CONSTRAINT finance_budget_allocation_revisions_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_allocations finance_budget_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocations
    ADD CONSTRAINT finance_budget_allocations_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_expense_evidence finance_budget_expense_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_expense_evidence
    ADD CONSTRAINT finance_budget_expense_evidence_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_expense_items finance_budget_expense_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_expense_items
    ADD CONSTRAINT finance_budget_expense_items_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_expenses finance_budget_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_expenses
    ADD CONSTRAINT finance_budget_expenses_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_income_items finance_budget_income_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_income_items
    ADD CONSTRAINT finance_budget_income_items_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_income_records finance_budget_income_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_income_records
    ADD CONSTRAINT finance_budget_income_records_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_nodes finance_budget_nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_nodes
    ADD CONSTRAINT finance_budget_nodes_pkey PRIMARY KEY (id);


--
-- Name: finance_budget_submissions finance_budget_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_submissions
    ADD CONSTRAINT finance_budget_submissions_pkey PRIMARY KEY (id);


--
-- Name: finance_budgets finance_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budgets
    ADD CONSTRAINT finance_budgets_pkey PRIMARY KEY (id);


--
-- Name: finance_chart_accounts finance_chart_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_chart_accounts
    ADD CONSTRAINT finance_chart_accounts_pkey PRIMARY KEY (id);


--
-- Name: finance_expense_claim_item_evidence finance_expense_claim_item_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_expense_claim_item_evidence
    ADD CONSTRAINT finance_expense_claim_item_evidence_pkey PRIMARY KEY (id);


--
-- Name: finance_expense_claim_items finance_expense_claim_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_expense_claim_items
    ADD CONSTRAINT finance_expense_claim_items_pkey PRIMARY KEY (id);


--
-- Name: finance_fiscal_periods finance_fiscal_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_fiscal_periods
    ADD CONSTRAINT finance_fiscal_periods_pkey PRIMARY KEY (id);


--
-- Name: finance_fund_accounts finance_fund_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_fund_accounts
    ADD CONSTRAINT finance_fund_accounts_pkey PRIMARY KEY (id);


--
-- Name: finance_journal_entries finance_journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT finance_journal_entries_pkey PRIMARY KEY (id);


--
-- Name: finance_journal_lines finance_journal_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_lines
    ADD CONSTRAINT finance_journal_lines_pkey PRIMARY KEY (id);


--
-- Name: finance_ledgers finance_ledgers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_ledgers
    ADD CONSTRAINT finance_ledgers_pkey PRIMARY KEY (id);


--
-- Name: gallery_drive_sync gallery_drive_sync_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".gallery_drive_sync
    ADD CONSTRAINT gallery_drive_sync_pkey PRIMARY KEY (id);


--
-- Name: gallery_drive_sync gallery_drive_sync_scope_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".gallery_drive_sync
    ADD CONSTRAINT gallery_drive_sync_scope_key UNIQUE (scope);


--
-- Name: governance_cases governance_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_cases
    ADD CONSTRAINT governance_cases_pkey PRIMARY KEY (id);


--
-- Name: governance_discord_event_routes governance_discord_event_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_discord_event_routes
    ADD CONSTRAINT governance_discord_event_routes_pkey PRIMARY KEY (id);


--
-- Name: governance_discord_workspaces governance_discord_workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_discord_workspaces
    ADD CONSTRAINT governance_discord_workspaces_pkey PRIMARY KEY (id);


--
-- Name: governance_workflow_templates governance_workflow_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_workflow_templates
    ADD CONSTRAINT governance_workflow_templates_pkey PRIMARY KEY (id);


--
-- Name: inventory_categories inventory_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_categories
    ADD CONSTRAINT inventory_categories_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: inventory_procurement_items inventory_procurement_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_procurement_items
    ADD CONSTRAINT inventory_procurement_items_pkey PRIMARY KEY (id);


--
-- Name: inventory_procurements inventory_procurements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_procurements
    ADD CONSTRAINT inventory_procurements_pkey PRIMARY KEY (id);


--
-- Name: inventory_transactions inventory_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_transactions
    ADD CONSTRAINT inventory_transactions_pkey PRIMARY KEY (id);


--
-- Name: judicial_petitions judicial_petitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".judicial_petitions
    ADD CONSTRAINT judicial_petitions_pkey PRIMARY KEY (id);


--
-- Name: line_account_links line_account_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".line_account_links
    ADD CONSTRAINT line_account_links_pkey PRIMARY KEY (id);


--
-- Name: matter_resources matter_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matter_resources
    ADD CONSTRAINT matter_resources_pkey PRIMARY KEY (id);


--
-- Name: matter_role_assignments matter_role_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matter_role_assignments
    ADD CONSTRAINT matter_role_assignments_pkey PRIMARY KEY (id);


--
-- Name: matters matters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matters
    ADD CONSTRAINT matters_pkey PRIMARY KEY (id);


--
-- Name: merchandise_submission_files merchandise_submission_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submission_files
    ADD CONSTRAINT merchandise_submission_files_pkey PRIMARY KEY (id);


--
-- Name: merchandise_submission_files merchandise_submission_files_storage_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submission_files
    ADD CONSTRAINT merchandise_submission_files_storage_key_key UNIQUE (storage_key);


--
-- Name: merchandise_submission_items merchandise_submission_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submission_items
    ADD CONSTRAINT merchandise_submission_items_pkey PRIMARY KEY (id);


--
-- Name: merchandise_submission_settings merchandise_submission_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submission_settings
    ADD CONSTRAINT merchandise_submission_settings_pkey PRIMARY KEY (id);


--
-- Name: merchandise_submissions merchandise_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submissions
    ADD CONSTRAINT merchandise_submissions_pkey PRIMARY KEY (id);


--
-- Name: navigation_profile_positions navigation_profile_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".navigation_profile_positions
    ADD CONSTRAINT navigation_profile_positions_pkey PRIMARY KEY (id);


--
-- Name: navigation_profiles navigation_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".navigation_profiles
    ADD CONSTRAINT navigation_profiles_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: observability_releases observability_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".observability_releases
    ADD CONSTRAINT observability_releases_pkey PRIMARY KEY (id);


--
-- Name: observability_releases observability_releases_release_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".observability_releases
    ADD CONSTRAINT observability_releases_release_key UNIQUE (release);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orgs orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orgs
    ADD CONSTRAINT orgs_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: pagespeed_audits pagespeed_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".pagespeed_audits
    ADD CONSTRAINT pagespeed_audits_pkey PRIMARY KEY (id);


--
-- Name: pagespeed_runs pagespeed_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".pagespeed_runs
    ADD CONSTRAINT pagespeed_runs_pkey PRIMARY KEY (id);


--
-- Name: partner_application_fields partner_application_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_application_fields
    ADD CONSTRAINT partner_application_fields_pkey PRIMARY KEY (id);


--
-- Name: partner_application_settings partner_application_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_application_settings
    ADD CONSTRAINT partner_application_settings_pkey PRIMARY KEY (id);


--
-- Name: partner_business_accounts partner_business_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_accounts
    ADD CONSTRAINT partner_business_accounts_pkey PRIMARY KEY (id);


--
-- Name: partner_business_applications partner_business_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_applications
    ADD CONSTRAINT partner_business_applications_pkey PRIMARY KEY (id);


--
-- Name: partner_business_images partner_business_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_images
    ADD CONSTRAINT partner_business_images_pkey PRIMARY KEY (id);


--
-- Name: partner_business_tags partner_business_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_tags
    ADD CONSTRAINT partner_business_tags_pkey PRIMARY KEY (business_id, tag_id);


--
-- Name: partner_businesses partner_businesses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_businesses
    ADD CONSTRAINT partner_businesses_pkey PRIMARY KEY (id);


--
-- Name: partner_locations partner_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_locations
    ADD CONSTRAINT partner_locations_pkey PRIMARY KEY (id);


--
-- Name: partner_offers partner_offers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_offers
    ADD CONSTRAINT partner_offers_pkey PRIMARY KEY (id);


--
-- Name: partner_submissions partner_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_submissions
    ADD CONSTRAINT partner_submissions_pkey PRIMARY KEY (id);


--
-- Name: partner_tags partner_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_tags
    ADD CONSTRAINT partner_tags_pkey PRIMARY KEY (id);


--
-- Name: passkey_credentials passkey_credentials_credential_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".passkey_credentials
    ADD CONSTRAINT passkey_credentials_credential_id_key UNIQUE (credential_id);


--
-- Name: passkey_credentials passkey_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".passkey_credentials
    ADD CONSTRAINT passkey_credentials_pkey PRIMARY KEY (id);


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: person_affiliations person_affiliations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".person_affiliations
    ADD CONSTRAINT person_affiliations_pkey PRIMARY KEY (id);


--
-- Name: petition_attachments petition_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_attachments
    ADD CONSTRAINT petition_attachments_pkey PRIMARY KEY (id);


--
-- Name: petition_case_events petition_case_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_case_events
    ADD CONSTRAINT petition_case_events_pkey PRIMARY KEY (id);


--
-- Name: petition_cases petition_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_cases
    ADD CONSTRAINT petition_cases_pkey PRIMARY KEY (id);


--
-- Name: petition_notification_rules petition_notification_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_notification_rules
    ADD CONSTRAINT petition_notification_rules_pkey PRIMARY KEY (id);


--
-- Name: petition_notification_settings petition_notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_notification_settings
    ADD CONSTRAINT petition_notification_settings_pkey PRIMARY KEY (id);


--
-- Name: petition_types petition_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_types
    ADD CONSTRAINT petition_types_pkey PRIMARY KEY (id);


--
-- Name: short_links pk_short_links; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".short_links
    ADD CONSTRAINT pk_short_links PRIMARY KEY (id);


--
-- Name: planning_document_attachments planning_document_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_document_attachments
    ADD CONSTRAINT planning_document_attachments_pkey PRIMARY KEY (id);


--
-- Name: planning_document_revision_attachments planning_document_revision_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_document_revision_attachments
    ADD CONSTRAINT planning_document_revision_attachments_pkey PRIMARY KEY (revision_id, attachment_id);


--
-- Name: planning_document_revisions planning_document_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_document_revisions
    ADD CONSTRAINT planning_document_revisions_pkey PRIMARY KEY (id);


--
-- Name: planning_documents planning_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_documents
    ADD CONSTRAINT planning_documents_pkey PRIMARY KEY (id);


--
-- Name: policy_consents policy_consents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".policy_consents
    ADD CONSTRAINT policy_consents_pkey PRIMARY KEY (id);


--
-- Name: policy_documents policy_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".policy_documents
    ADD CONSTRAINT policy_documents_pkey PRIMARY KEY (id);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: privacy_requests privacy_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".privacy_requests
    ADD CONSTRAINT privacy_requests_pkey PRIMARY KEY (id);


--
-- Name: product_categories product_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_categories
    ADD CONSTRAINT product_categories_pkey PRIMARY KEY (id);


--
-- Name: product_media product_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_media
    ADD CONSTRAINT product_media_pkey PRIMARY KEY (id);


--
-- Name: product_series product_series_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_series
    ADD CONSTRAINT product_series_pkey PRIMARY KEY (id);


--
-- Name: product_variant_groups product_variant_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_variant_groups
    ADD CONSTRAINT product_variant_groups_pkey PRIMARY KEY (id);


--
-- Name: product_variant_options product_variant_options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_variant_options
    ADD CONSTRAINT product_variant_options_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: programs programs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".programs
    ADD CONSTRAINT programs_pkey PRIMARY KEY (id);


--
-- Name: public_link_categories public_link_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_link_categories
    ADD CONSTRAINT public_link_categories_pkey PRIMARY KEY (id);


--
-- Name: public_links public_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_links
    ADD CONSTRAINT public_links_pkey PRIMARY KEY (id);


--
-- Name: public_officer_profiles public_officer_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_officer_profiles
    ADD CONSTRAINT public_officer_profiles_pkey PRIMARY KEY (id);


--
-- Name: public_site_page_views public_site_page_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_site_page_views
    ADD CONSTRAINT public_site_page_views_pkey PRIMARY KEY (id);


--
-- Name: public_site_pages public_site_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_site_pages
    ADD CONSTRAINT public_site_pages_pkey PRIMARY KEY (id);


--
-- Name: public_site_settings public_site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_site_settings
    ADD CONSTRAINT public_site_settings_pkey PRIMARY KEY (id);


--
-- Name: publication_campaigns publication_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".publication_campaigns
    ADD CONSTRAINT publication_campaigns_pkey PRIMARY KEY (id);


--
-- Name: publication_deliveries publication_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".publication_deliveries
    ADD CONSTRAINT publication_deliveries_pkey PRIMARY KEY (id);


--
-- Name: raffle_draws raffle_draws_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_draws
    ADD CONSTRAINT raffle_draws_pkey PRIMARY KEY (id);


--
-- Name: raffle_events raffle_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_events
    ADD CONSTRAINT raffle_events_pkey PRIMARY KEY (id);


--
-- Name: raffle_prizes raffle_prizes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_prizes
    ADD CONSTRAINT raffle_prizes_pkey PRIMARY KEY (id);


--
-- Name: raffle_sessions raffle_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_sessions
    ADD CONSTRAINT raffle_sessions_pkey PRIMARY KEY (id);


--
-- Name: receivables receivables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".receivables
    ADD CONSTRAINT receivables_pkey PRIMARY KEY (id);


--
-- Name: recommended_vendor_categories recommended_vendor_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".recommended_vendor_categories
    ADD CONSTRAINT recommended_vendor_categories_pkey PRIMARY KEY (id);


--
-- Name: recommended_vendor_menus recommended_vendor_menus_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".recommended_vendor_menus
    ADD CONSTRAINT recommended_vendor_menus_pkey PRIMARY KEY (id);


--
-- Name: recommended_vendor_products recommended_vendor_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".recommended_vendor_products
    ADD CONSTRAINT recommended_vendor_products_pkey PRIMARY KEY (id);


--
-- Name: recommended_vendors recommended_vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".recommended_vendors
    ADD CONSTRAINT recommended_vendors_pkey PRIMARY KEY (id);


--
-- Name: regulation_articles regulation_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_articles
    ADD CONSTRAINT regulation_articles_pkey PRIMARY KEY (id);


--
-- Name: regulation_revisions regulation_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_revisions
    ADD CONSTRAINT regulation_revisions_pkey PRIMARY KEY (id);


--
-- Name: regulation_sync_sources regulation_sync_sources_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_sync_sources
    ADD CONSTRAINT regulation_sync_sources_org_id_key UNIQUE (org_id);


--
-- Name: regulation_sync_sources regulation_sync_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_sync_sources
    ADD CONSTRAINT regulation_sync_sources_pkey PRIMARY KEY (id);


--
-- Name: regulation_workflow_logs regulation_workflow_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_workflow_logs
    ADD CONSTRAINT regulation_workflow_logs_pkey PRIMARY KEY (id);


--
-- Name: regulations regulations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulations
    ADD CONSTRAINT regulations_pkey PRIMARY KEY (id);


--
-- Name: saved_filters saved_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".saved_filters
    ADD CONSTRAINT saved_filters_pkey PRIMARY KEY (id);


--
-- Name: school_classes school_classes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".school_classes
    ADD CONSTRAINT school_classes_pkey PRIMARY KEY (id);


--
-- Name: seat_assignments seat_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_assignments
    ADD CONSTRAINT seat_assignments_pkey PRIMARY KEY (id);


--
-- Name: seat_holds seat_holds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_holds
    ADD CONSTRAINT seat_holds_pkey PRIMARY KEY (id);


--
-- Name: seating_waves seating_waves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seating_waves
    ADD CONSTRAINT seating_waves_pkey PRIMARY KEY (id);


--
-- Name: seating_zones seating_zones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seating_zones
    ADD CONSTRAINT seating_zones_pkey PRIMARY KEY (id);


--
-- Name: seats seats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seats
    ADD CONSTRAINT seats_pkey PRIMARY KEY (id);


--
-- Name: shop_class_collections shop_class_collections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_class_collections
    ADD CONSTRAINT shop_class_collections_pkey PRIMARY KEY (id);


--
-- Name: shop_class_payments shop_class_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_class_payments
    ADD CONSTRAINT shop_class_payments_pkey PRIMARY KEY (id);


--
-- Name: shop_delegation_links shop_delegation_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_delegation_links
    ADD CONSTRAINT shop_delegation_links_pkey PRIMARY KEY (id);


--
-- Name: shop_delegation_links shop_delegation_links_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_delegation_links
    ADD CONSTRAINT shop_delegation_links_token_hash_key UNIQUE (token_hash);


--
-- Name: shop_offices shop_offices_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_offices
    ADD CONSTRAINT shop_offices_name_key UNIQUE (name);


--
-- Name: shop_offices shop_offices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_offices
    ADD CONSTRAINT shop_offices_pkey PRIMARY KEY (id);


--
-- Name: shop_order_closes shop_order_closes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_order_closes
    ADD CONSTRAINT shop_order_closes_pkey PRIMARY KEY (id);


--
-- Name: shop_order_promotions shop_order_promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_order_promotions
    ADD CONSTRAINT shop_order_promotions_pkey PRIMARY KEY (order_id, promotion_id);


--
-- Name: shop_order_receipt_prints shop_order_receipt_prints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_order_receipt_prints
    ADD CONSTRAINT shop_order_receipt_prints_pkey PRIMARY KEY (order_id);


--
-- Name: shop_promotion_product_prices shop_promotion_product_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_product_prices
    ADD CONSTRAINT shop_promotion_product_prices_pkey PRIMARY KEY (promotion_id, product_id);


--
-- Name: shop_promotion_products shop_promotion_products_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_products
    ADD CONSTRAINT shop_promotion_products_pkey PRIMARY KEY (promotion_id, product_id);


--
-- Name: shop_promotion_student_targets shop_promotion_student_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_student_targets
    ADD CONSTRAINT shop_promotion_student_targets_pkey PRIMARY KEY (promotion_id, student_id);


--
-- Name: shop_promotion_users shop_promotion_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_users
    ADD CONSTRAINT shop_promotion_users_pkey PRIMARY KEY (promotion_id, user_id);


--
-- Name: shop_promotions shop_promotions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotions
    ADD CONSTRAINT shop_promotions_pkey PRIMARY KEY (id);


--
-- Name: shop_sheet_rows shop_sheet_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_sheet_rows
    ADD CONSTRAINT shop_sheet_rows_pkey PRIMARY KEY (id);


--
-- Name: shop_sheet_rows shop_sheet_rows_source_id_response_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_sheet_rows
    ADD CONSTRAINT shop_sheet_rows_source_id_response_key_key UNIQUE (source_id, response_key);


--
-- Name: shop_sheet_sources shop_sheet_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_sheet_sources
    ADD CONSTRAINT shop_sheet_sources_pkey PRIMARY KEY (id);


--
-- Name: shop_sheet_sources shop_sheet_sources_spreadsheet_id_sheet_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_sheet_sources
    ADD CONSTRAINT shop_sheet_sources_spreadsheet_id_sheet_name_key UNIQUE (spreadsheet_id, sheet_name);


--
-- Name: shop_teacher_profiles shop_teacher_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_teacher_profiles
    ADD CONSTRAINT shop_teacher_profiles_pkey PRIMARY KEY (user_id);


--
-- Name: support_approvals support_approvals_approval_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_approvals
    ADD CONSTRAINT support_approvals_approval_number_key UNIQUE (approval_number);


--
-- Name: support_approvals support_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_approvals
    ADD CONSTRAINT support_approvals_pkey PRIMARY KEY (id);


--
-- Name: support_assistance_sessions support_assistance_sessions_assistance_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_assistance_sessions
    ADD CONSTRAINT support_assistance_sessions_assistance_code_key UNIQUE (assistance_code);


--
-- Name: support_assistance_sessions support_assistance_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_assistance_sessions
    ADD CONSTRAINT support_assistance_sessions_pkey PRIMARY KEY (id);


--
-- Name: support_audit_logs support_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_audit_logs
    ADD CONSTRAINT support_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: support_guide_entries support_guide_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_guide_entries
    ADD CONSTRAINT support_guide_entries_pkey PRIMARY KEY (id);


--
-- Name: support_guide_entries support_guide_entries_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_guide_entries
    ADD CONSTRAINT support_guide_entries_slug_key UNIQUE (slug);


--
-- Name: support_impersonation_sessions support_impersonation_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_impersonation_sessions
    ADD CONSTRAINT support_impersonation_sessions_pkey PRIMARY KEY (id);


--
-- Name: support_impersonation_sessions support_impersonation_sessions_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_impersonation_sessions
    ADD CONSTRAINT support_impersonation_sessions_token_hash_key UNIQUE (token_hash);


--
-- Name: support_ticket_events support_ticket_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_ticket_events
    ADD CONSTRAINT support_ticket_events_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_tickets
    ADD CONSTRAINT support_tickets_ticket_number_key UNIQUE (ticket_number);


--
-- Name: survey_answers survey_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".survey_answers
    ADD CONSTRAINT survey_answers_pkey PRIMARY KEY (id);


--
-- Name: survey_questions survey_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".survey_questions
    ADD CONSTRAINT survey_questions_pkey PRIMARY KEY (id);


--
-- Name: survey_responses survey_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".survey_responses
    ADD CONSTRAINT survey_responses_pkey PRIMARY KEY (id);


--
-- Name: surveys surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".surveys
    ADD CONSTRAINT surveys_pkey PRIMARY KEY (id);


--
-- Name: system_incident_events system_incident_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".system_incident_events
    ADD CONSTRAINT system_incident_events_pkey PRIMARY KEY (id);


--
-- Name: system_incidents system_incidents_error_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".system_incidents
    ADD CONSTRAINT system_incidents_error_id_key UNIQUE (error_id);


--
-- Name: system_incidents system_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".system_incidents
    ADD CONSTRAINT system_incidents_pkey PRIMARY KEY (id);


--
-- Name: timeline_events timeline_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".timeline_events
    ADD CONSTRAINT timeline_events_pkey PRIMARY KEY (id);


--
-- Name: activity_conveners uq_activity_convener_term; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_conveners
    ADD CONSTRAINT uq_activity_convener_term UNIQUE (activity_id, user_id, start_date);


--
-- Name: activity_links uq_activity_link_target; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_links
    ADD CONSTRAINT uq_activity_link_target UNIQUE (activity_id, target_type, target_id);


--
-- Name: activity_members uq_activity_member_term; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_members
    ADD CONSTRAINT uq_activity_member_term UNIQUE (activity_id, role_id, user_id, start_date);


--
-- Name: activity_roles uq_activity_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_roles
    ADD CONSTRAINT uq_activity_role_key UNIQUE (activity_id, key);


--
-- Name: announcement_reads uq_announcement_reads; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_reads
    ADD CONSTRAINT uq_announcement_reads UNIQUE (announcement_id, user_id);


--
-- Name: api_keys uq_api_keys_key_hash; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".api_keys
    ADD CONSTRAINT uq_api_keys_key_hash UNIQUE (key_hash);


--
-- Name: audit_log_anchors uq_audit_log_anchors_date; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".audit_log_anchors
    ADD CONSTRAINT uq_audit_log_anchors_date UNIQUE (anchor_date);


--
-- Name: class_cadres uq_class_cadre; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_cadres
    ADD CONSTRAINT uq_class_cadre UNIQUE (class_id, user_id);


--
-- Name: class_manual_members uq_class_manual_member; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_manual_members
    ADD CONSTRAINT uq_class_manual_member UNIQUE (class_id, user_id);


--
-- Name: class_role_bindings uq_class_role_binding; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_role_bindings
    ADD CONSTRAINT uq_class_role_binding UNIQUE (class_id, role_key);


--
-- Name: class_roster_entries uq_class_roster_seat; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_roster_entries
    ADD CONSTRAINT uq_class_roster_seat UNIQUE (class_id, seat_number);


--
-- Name: class_roster_entries uq_class_roster_student_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_roster_entries
    ADD CONSTRAINT uq_class_roster_student_id UNIQUE (class_id, student_id);


--
-- Name: school_classes uq_class_year_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".school_classes
    ADD CONSTRAINT uq_class_year_code UNIQUE (academic_year, class_code);


--
-- Name: discord_activity_workspaces uq_discord_activity_workspace_activity; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_activity_workspaces
    ADD CONSTRAINT uq_discord_activity_workspace_activity UNIQUE (activity_id);


--
-- Name: discord_member_sync_states uq_discord_member_sync_state_member; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_member_sync_states
    ADD CONSTRAINT uq_discord_member_sync_state_member UNIQUE (guild_id, discord_user_id);


--
-- Name: discord_org_channel_mappings uq_discord_org_channel_mapping_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_org_channel_mappings
    ADD CONSTRAINT uq_discord_org_channel_mapping_org UNIQUE (guild_id, org_id);


--
-- Name: discord_role_mappings uq_discord_role_mapping_role; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_role_mappings
    ADD CONSTRAINT uq_discord_role_mapping_role UNIQUE (guild_id, role_id);


--
-- Name: discord_role_policies uq_discord_role_policy_role; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_role_policies
    ADD CONSTRAINT uq_discord_role_policy_role UNIQUE (guild_id, role_id);


--
-- Name: document_approvals uq_doc_approval_step; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_approvals
    ADD CONSTRAINT uq_doc_approval_step UNIQUE (document_id, step_order);


--
-- Name: document_revisions uq_doc_revision; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_revisions
    ADD CONSTRAINT uq_doc_revision UNIQUE (document_id, revision_number);


--
-- Name: document_templates uq_document_template_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_templates
    ADD CONSTRAINT uq_document_template_version UNIQUE (org_id, name, version);


--
-- Name: election_ballot_boxes uq_election_ballot_box_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".election_ballot_boxes
    ADD CONSTRAINT uq_election_ballot_box_name UNIQUE (election_id, name);


--
-- Name: election_candidates uq_election_candidate_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".election_candidates
    ADD CONSTRAINT uq_election_candidate_number UNIQUE (election_id, number);


--
-- Name: electronic_credential_authorizations uq_electronic_credential_authorizations_email; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".electronic_credential_authorizations
    ADD CONSTRAINT uq_electronic_credential_authorizations_email UNIQUE (email);


--
-- Name: email_recipient_list_members uq_email_recipient_list_email; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_recipient_list_members
    ADD CONSTRAINT uq_email_recipient_list_email UNIQUE (list_id, email);


--
-- Name: email_recipient_events uq_email_recipient_provider_event; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_recipient_events
    ADD CONSTRAINT uq_email_recipient_provider_event UNIQUE (provider_event_id);


--
-- Name: email_template_versions uq_email_template_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_template_versions
    ADD CONSTRAINT uq_email_template_version UNIQUE (template_id, version);


--
-- Name: entity_relations uq_entity_relations_edge; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".entity_relations
    ADD CONSTRAINT uq_entity_relations_edge UNIQUE (matter_id, case_id, source_type, source_id, target_type, target_id, relation);


--
-- Name: exam_paper_downloads uq_exam_paper_download_trace_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".exam_paper_downloads
    ADD CONSTRAINT uq_exam_paper_download_trace_code UNIQUE (trace_code);


--
-- Name: feature_flags uq_feature_flags_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".feature_flags
    ADD CONSTRAINT uq_feature_flags_key UNIQUE (key);


--
-- Name: finance_chart_accounts uq_finance_account_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_chart_accounts
    ADD CONSTRAINT uq_finance_account_code UNIQUE (ledger_id, code);


--
-- Name: finance_bank_transactions uq_finance_bank_external; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_bank_transactions
    ADD CONSTRAINT uq_finance_bank_external UNIQUE (fund_account_id, external_id);


--
-- Name: finance_budget_nodes uq_finance_budget_node_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_nodes
    ADD CONSTRAINT uq_finance_budget_node_name UNIQUE (budget_id, parent_id, name);


--
-- Name: finance_budgets uq_finance_budget_period; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budgets
    ADD CONSTRAINT uq_finance_budget_period UNIQUE (ledger_id, period_id);


--
-- Name: finance_fund_accounts uq_finance_fund_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_fund_accounts
    ADD CONSTRAINT uq_finance_fund_name UNIQUE (ledger_id, name);


--
-- Name: finance_ledgers uq_finance_ledger_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_ledgers
    ADD CONSTRAINT uq_finance_ledger_org UNIQUE (org_id);


--
-- Name: finance_fiscal_periods uq_finance_period_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_fiscal_periods
    ADD CONSTRAINT uq_finance_period_name UNIQUE (ledger_id, name);


--
-- Name: finance_journal_entries uq_finance_source_event; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT uq_finance_source_event UNIQUE (ledger_id, source_type, source_id, source_event);


--
-- Name: governance_discord_event_routes uq_governance_discord_event_route; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_discord_event_routes
    ADD CONSTRAINT uq_governance_discord_event_route UNIQUE (workspace_id, event_type);


--
-- Name: governance_discord_workspaces uq_governance_discord_workspace_matter; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_discord_workspaces
    ADD CONSTRAINT uq_governance_discord_workspace_matter UNIQUE (matter_id);


--
-- Name: governance_workflow_templates uq_governance_workflow_template_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_workflow_templates
    ADD CONSTRAINT uq_governance_workflow_template_version UNIQUE (name, version);


--
-- Name: matter_resources uq_matter_resources_matter_url; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matter_resources
    ADD CONSTRAINT uq_matter_resources_matter_url UNIQUE (matter_id, url);


--
-- Name: navigation_profile_positions uq_navigation_profile_position; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".navigation_profile_positions
    ADD CONSTRAINT uq_navigation_profile_position UNIQUE (profile_id, position_id);


--
-- Name: partner_application_fields uq_partner_application_fields_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_application_fields
    ADD CONSTRAINT uq_partner_application_fields_key UNIQUE (settings_id, key);


--
-- Name: partner_business_accounts uq_partner_business_accounts_business_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_accounts
    ADD CONSTRAINT uq_partner_business_accounts_business_user UNIQUE (business_id, user_id);


--
-- Name: partner_tags uq_partner_tags_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_tags
    ADD CONSTRAINT uq_partner_tags_name UNIQUE (name);


--
-- Name: people uq_people_student_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".people
    ADD CONSTRAINT uq_people_student_id UNIQUE (student_id);


--
-- Name: people uq_people_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".people
    ADD CONSTRAINT uq_people_user_id UNIQUE (user_id);


--
-- Name: petition_notification_rules uq_petition_notification_rule_org; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_notification_rules
    ADD CONSTRAINT uq_petition_notification_rule_org UNIQUE (org_id);


--
-- Name: petition_notification_rules uq_petition_notification_rule_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_notification_rules
    ADD CONSTRAINT uq_petition_notification_rule_type UNIQUE (petition_type_id);


--
-- Name: planning_document_revisions uq_planning_document_revision_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_document_revisions
    ADD CONSTRAINT uq_planning_document_revision_version UNIQUE (document_id, version_number);


--
-- Name: policy_consents uq_policy_consents_user_document; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".policy_consents
    ADD CONSTRAINT uq_policy_consents_user_document UNIQUE (user_id, policy_document_id);


--
-- Name: policy_documents uq_policy_documents_kind_version; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".policy_documents
    ADD CONSTRAINT uq_policy_documents_kind_version UNIQUE (kind, version);


--
-- Name: permissions uq_position_permission; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".permissions
    ADD CONSTRAINT uq_position_permission UNIQUE (position_id, code);


--
-- Name: programs uq_programs_matter_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".programs
    ADD CONSTRAINT uq_programs_matter_name UNIQUE (matter_id, name);


--
-- Name: public_link_categories uq_public_link_categories_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_link_categories
    ADD CONSTRAINT uq_public_link_categories_slug UNIQUE (slug);


--
-- Name: public_officer_profiles uq_public_officer_profiles_user_position; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_officer_profiles
    ADD CONSTRAINT uq_public_officer_profiles_user_position UNIQUE (user_position_id);


--
-- Name: public_site_pages uq_public_site_pages_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_site_pages
    ADD CONSTRAINT uq_public_site_pages_slug UNIQUE (slug);


--
-- Name: raffle_draws uq_raffle_draws_idempotency; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_draws
    ADD CONSTRAINT uq_raffle_draws_idempotency UNIQUE (event_id, idempotency_key);


--
-- Name: raffle_draws uq_raffle_draws_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_draws
    ADD CONSTRAINT uq_raffle_draws_number UNIQUE (event_id, draw_number);


--
-- Name: raffle_draws uq_raffle_draws_session; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_draws
    ADD CONSTRAINT uq_raffle_draws_session UNIQUE (event_id, session_id);


--
-- Name: raffle_events uq_raffle_events_event_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_events
    ADD CONSTRAINT uq_raffle_events_event_code UNIQUE (event_code);


--
-- Name: raffle_sessions uq_raffle_sessions_token; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_sessions
    ADD CONSTRAINT uq_raffle_sessions_token UNIQUE (event_id, token_hash);


--
-- Name: receivables uq_receivables_source; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".receivables
    ADD CONSTRAINT uq_receivables_source UNIQUE (source_type, source_id);


--
-- Name: recommended_vendor_categories uq_recommended_vendor_categories_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".recommended_vendor_categories
    ADD CONSTRAINT uq_recommended_vendor_categories_name UNIQUE (name);


--
-- Name: seat_holds uq_seat_hold_seat; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_holds
    ADD CONSTRAINT uq_seat_hold_seat UNIQUE (seat_id);


--
-- Name: seats uq_seat_zone_label; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seats
    ADD CONSTRAINT uq_seat_zone_label UNIQUE (zone_id, label);


--
-- Name: document_serial_templates uq_serial_template; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_serial_templates
    ADD CONSTRAINT uq_serial_template UNIQUE (org_id, org_prefix, category_char);


--
-- Name: short_links uq_short_links_slug; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".short_links
    ADD CONSTRAINT uq_short_links_slug UNIQUE (slug);


--
-- Name: user_google_tasks_configs uq_user_google_tasks_configs_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_google_tasks_configs
    ADD CONSTRAINT uq_user_google_tasks_configs_user UNIQUE (user_id);


--
-- Name: user_identities uq_user_identities_provider_external_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_identities
    ADD CONSTRAINT uq_user_identities_provider_external_id UNIQUE (provider, external_id);


--
-- Name: web_push_subscriptions uq_web_push_user_endpoint; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".web_push_subscriptions
    ADD CONSTRAINT uq_web_push_user_endpoint UNIQUE (user_id, endpoint);


--
-- Name: workflow_instances uq_workflow_instances_source; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_instances
    ADD CONSTRAINT uq_workflow_instances_source UNIQUE (source_type, source_id);


--
-- Name: workflow_links uq_workflow_link_target; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_links
    ADD CONSTRAINT uq_workflow_link_target UNIQUE (instance_id, target_type, target_id, relation);


--
-- Name: user_google_tasks_configs user_google_tasks_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_google_tasks_configs
    ADD CONSTRAINT user_google_tasks_configs_pkey PRIMARY KEY (id);


--
-- Name: user_identities user_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_identities
    ADD CONSTRAINT user_identities_pkey PRIMARY KEY (id);


--
-- Name: user_positions user_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_positions
    ADD CONSTRAINT user_positions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_google_sub_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".users
    ADD CONSTRAINT users_google_sub_key UNIQUE (google_sub);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vote_events vote_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".vote_events
    ADD CONSTRAINT vote_events_pkey PRIMARY KEY (id);


--
-- Name: vote_events vote_events_reverses_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".vote_events
    ADD CONSTRAINT vote_events_reverses_event_id_key UNIQUE (reverses_event_id);


--
-- Name: web_push_subscriptions web_push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".web_push_subscriptions
    ADD CONSTRAINT web_push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: webhook_deliveries webhook_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: webhook_subscriptions webhook_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".webhook_subscriptions
    ADD CONSTRAINT webhook_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: work_items work_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".work_items
    ADD CONSTRAINT work_items_pkey PRIMARY KEY (id);


--
-- Name: workflow_events workflow_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_events
    ADD CONSTRAINT workflow_events_pkey PRIMARY KEY (id);


--
-- Name: workflow_instances workflow_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_instances
    ADD CONSTRAINT workflow_instances_pkey PRIMARY KEY (id);


--
-- Name: workflow_links workflow_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_links
    ADD CONSTRAINT workflow_links_pkey PRIMARY KEY (id);


--
-- Name: ix_activities_active_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activities_active_status ON "__HCCA_SCHEMA__".activities USING btree (is_active, status);


--
-- Name: ix_activities_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activities_is_active ON "__HCCA_SCHEMA__".activities USING btree (is_active);


--
-- Name: ix_activities_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activities_name ON "__HCCA_SCHEMA__".activities USING btree (name);


--
-- Name: ix_activities_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activities_org_id ON "__HCCA_SCHEMA__".activities USING btree (org_id);


--
-- Name: ix_activities_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activities_org_status ON "__HCCA_SCHEMA__".activities USING btree (org_id, status);


--
-- Name: ix_activities_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activities_status ON "__HCCA_SCHEMA__".activities USING btree (status);


--
-- Name: ix_activity_conveners_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_conveners_active ON "__HCCA_SCHEMA__".activity_conveners USING btree (activity_id, user_id, end_date);


--
-- Name: ix_activity_conveners_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_conveners_user_id ON "__HCCA_SCHEMA__".activity_conveners USING btree (user_id);


--
-- Name: ix_activity_links_activity_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_links_activity_type ON "__HCCA_SCHEMA__".activity_links USING btree (activity_id, target_type);


--
-- Name: ix_activity_links_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_links_created_by_id ON "__HCCA_SCHEMA__".activity_links USING btree (created_by_id);


--
-- Name: ix_activity_links_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_links_target ON "__HCCA_SCHEMA__".activity_links USING btree (target_type, target_id);


--
-- Name: ix_activity_members_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_members_active ON "__HCCA_SCHEMA__".activity_members USING btree (activity_id, user_id, end_date);


--
-- Name: ix_activity_roles_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_activity_roles_active ON "__HCCA_SCHEMA__".activity_roles USING btree (activity_id, is_active);


--
-- Name: ix_analytics_page_views_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_analytics_page_views_created_at ON "__HCCA_SCHEMA__".analytics_page_views USING btree (created_at);


--
-- Name: ix_analytics_page_views_path_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_analytics_page_views_path_created_at ON "__HCCA_SCHEMA__".analytics_page_views USING btree (path, created_at);


--
-- Name: ix_announcement_audience_orgs_org_announcement; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcement_audience_orgs_org_announcement ON "__HCCA_SCHEMA__".announcement_audience_orgs USING btree (org_id, announcement_id);


--
-- Name: ix_announcement_audience_users_user_announcement; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcement_audience_users_user_announcement ON "__HCCA_SCHEMA__".announcement_audience_users USING btree (user_id, announcement_id);


--
-- Name: ix_announcement_media_announcement_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcement_media_announcement_id ON "__HCCA_SCHEMA__".announcement_media USING btree (announcement_id);


--
-- Name: ix_announcement_reads_announcement_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcement_reads_announcement_id ON "__HCCA_SCHEMA__".announcement_reads USING btree (announcement_id);


--
-- Name: ix_announcement_reads_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcement_reads_user_id ON "__HCCA_SCHEMA__".announcement_reads USING btree (user_id);


--
-- Name: ix_announcements_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_activity_id ON "__HCCA_SCHEMA__".announcements USING btree (activity_id);


--
-- Name: ix_announcements_activity_published; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_activity_published ON "__HCCA_SCHEMA__".announcements USING btree (activity_id, is_published, published_at DESC NULLS LAST);


--
-- Name: ix_announcements_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_author_id ON "__HCCA_SCHEMA__".announcements USING btree (author_id);


--
-- Name: ix_announcements_created_at_desc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_created_at_desc ON "__HCCA_SCHEMA__".announcements USING btree (created_at DESC);


--
-- Name: ix_announcements_is_published; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_is_published ON "__HCCA_SCHEMA__".announcements USING btree (is_published);


--
-- Name: ix_announcements_is_urgent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_is_urgent ON "__HCCA_SCHEMA__".announcements USING btree (is_urgent);


--
-- Name: ix_announcements_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_org_id ON "__HCCA_SCHEMA__".announcements USING btree (org_id);


--
-- Name: ix_announcements_org_published; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_org_published ON "__HCCA_SCHEMA__".announcements USING btree (org_id, is_published, published_at);


--
-- Name: ix_announcements_published_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_published_at ON "__HCCA_SCHEMA__".announcements USING btree (published_at);


--
-- Name: ix_announcements_published_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_published_created ON "__HCCA_SCHEMA__".announcements USING btree (is_published, published_at DESC NULLS LAST, created_at DESC);


--
-- Name: ix_announcements_search_vector; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_announcements_search_vector ON "__HCCA_SCHEMA__".announcements USING gin (search_vector);


--
-- Name: ix_api_keys_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_api_keys_owner ON "__HCCA_SCHEMA__".api_keys USING btree (owner_user_id);


--
-- Name: ix_api_keys_revoked; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_api_keys_revoked ON "__HCCA_SCHEMA__".api_keys USING btree (revoked_at);


--
-- Name: ix_audit_log_anchors_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_anchors_date ON "__HCCA_SCHEMA__".audit_log_anchors USING btree (anchor_date);


--
-- Name: ix_audit_logs_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_actor ON "__HCCA_SCHEMA__".audit_logs USING btree (actor_id);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_created_at ON "__HCCA_SCHEMA__".audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_entity ON "__HCCA_SCHEMA__".audit_logs USING btree (entity_type, entity_id);


--
-- Name: ix_audit_logs_self_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_logs_self_hash ON "__HCCA_SCHEMA__".audit_logs USING btree (self_hash);


--
-- Name: ix_automation_rules_matter; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_rules_matter ON "__HCCA_SCHEMA__".automation_rules USING btree (matter_id);


--
-- Name: ix_automation_rules_matter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_rules_matter_id ON "__HCCA_SCHEMA__".automation_rules USING btree (matter_id);


--
-- Name: ix_automation_rules_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_rules_status ON "__HCCA_SCHEMA__".automation_rules USING btree (status);


--
-- Name: ix_automation_rules_trigger; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_rules_trigger ON "__HCCA_SCHEMA__".automation_rules USING btree (trigger_type, status);


--
-- Name: ix_automation_rules_trigger_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_rules_trigger_type ON "__HCCA_SCHEMA__".automation_rules USING btree (trigger_type);


--
-- Name: ix_backup_records_kind_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_backup_records_kind_created ON "__HCCA_SCHEMA__".backup_records USING btree (kind, created_at);


--
-- Name: ix_backup_records_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_backup_records_status ON "__HCCA_SCHEMA__".backup_records USING btree (status);


--
-- Name: ix_cart_items_cart_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cart_items_cart_id ON "__HCCA_SCHEMA__".cart_items USING btree (cart_id);


--
-- Name: ix_cart_items_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_cart_items_product_id ON "__HCCA_SCHEMA__".cart_items USING btree (product_id);


--
-- Name: ix_carts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_carts_user_id ON "__HCCA_SCHEMA__".carts USING btree (user_id);


--
-- Name: ix_class_cadres_class_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_cadres_class_id ON "__HCCA_SCHEMA__".class_cadres USING btree (class_id);


--
-- Name: ix_class_cadres_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_cadres_user_id ON "__HCCA_SCHEMA__".class_cadres USING btree (user_id);


--
-- Name: ix_class_confirmations_class_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_confirmations_class_id ON "__HCCA_SCHEMA__".class_confirmations USING btree (class_id);


--
-- Name: ix_class_confirmations_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_confirmations_user_id ON "__HCCA_SCHEMA__".class_confirmations USING btree (user_id);


--
-- Name: ix_class_correction_requests_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_correction_requests_status_created ON "__HCCA_SCHEMA__".class_correction_requests USING btree (status, created_at);


--
-- Name: ix_class_correction_requests_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_correction_requests_user_id ON "__HCCA_SCHEMA__".class_correction_requests USING btree (user_id);


--
-- Name: ix_class_correction_requests_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_correction_requests_user_status ON "__HCCA_SCHEMA__".class_correction_requests USING btree (user_id, status);


--
-- Name: ix_class_manual_members_class_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_manual_members_class_id ON "__HCCA_SCHEMA__".class_manual_members USING btree (class_id);


--
-- Name: ix_class_manual_members_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_manual_members_user_id ON "__HCCA_SCHEMA__".class_manual_members USING btree (user_id);


--
-- Name: ix_class_memberships_academic_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_memberships_academic_year ON "__HCCA_SCHEMA__".class_memberships USING btree (academic_year);


--
-- Name: ix_class_memberships_class_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_memberships_class_id ON "__HCCA_SCHEMA__".class_memberships USING btree (class_id);


--
-- Name: ix_class_memberships_class_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_memberships_class_status ON "__HCCA_SCHEMA__".class_memberships USING btree (class_id, status);


--
-- Name: ix_class_memberships_user_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_memberships_user_active ON "__HCCA_SCHEMA__".class_memberships USING btree (user_id, status);


--
-- Name: ix_class_memberships_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_memberships_user_id ON "__HCCA_SCHEMA__".class_memberships USING btree (user_id);


--
-- Name: ix_class_role_bindings_class_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_role_bindings_class_id ON "__HCCA_SCHEMA__".class_role_bindings USING btree (class_id);


--
-- Name: ix_class_role_bindings_position_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_role_bindings_position_id ON "__HCCA_SCHEMA__".class_role_bindings USING btree (position_id);


--
-- Name: ix_class_role_bindings_role_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_role_bindings_role_key ON "__HCCA_SCHEMA__".class_role_bindings USING btree (role_key);


--
-- Name: ix_class_roster_entries_class_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_roster_entries_class_id ON "__HCCA_SCHEMA__".class_roster_entries USING btree (class_id);


--
-- Name: ix_class_roster_entries_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_roster_entries_user_id ON "__HCCA_SCHEMA__".class_roster_entries USING btree (user_id);


--
-- Name: ix_class_student_ranges_class_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_class_student_ranges_class_id ON "__HCCA_SCHEMA__".class_student_ranges USING btree (class_id);


--
-- Name: ix_council_proposals_case_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_council_proposals_case_type ON "__HCCA_SCHEMA__".council_proposals USING btree (case_type);


--
-- Name: ix_council_proposals_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_council_proposals_kind ON "__HCCA_SCHEMA__".council_proposals USING btree (kind);


--
-- Name: ix_council_proposals_regulation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_council_proposals_regulation_id ON "__HCCA_SCHEMA__".council_proposals USING btree (regulation_id);


--
-- Name: ix_council_proposals_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_council_proposals_serial_number ON "__HCCA_SCHEMA__".council_proposals USING btree (serial_number);


--
-- Name: ix_council_proposals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_council_proposals_status ON "__HCCA_SCHEMA__".council_proposals USING btree (status);


--
-- Name: ix_council_proposals_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_council_proposals_status_created ON "__HCCA_SCHEMA__".council_proposals USING btree (status, created_at);


--
-- Name: ix_council_proposals_submitter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_council_proposals_submitter_id ON "__HCCA_SCHEMA__".council_proposals USING btree (submitter_id);


--
-- Name: ix_council_proposals_submitter_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_council_proposals_submitter_status ON "__HCCA_SCHEMA__".council_proposals USING btree (submitter_id, status);


--
-- Name: ix_council_proposals_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_council_proposals_title ON "__HCCA_SCHEMA__".council_proposals USING btree (title);


--
-- Name: ix_decisions_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decisions_case_id ON "__HCCA_SCHEMA__".decisions USING btree (case_id);


--
-- Name: ix_decisions_matter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decisions_matter_id ON "__HCCA_SCHEMA__".decisions USING btree (matter_id);


--
-- Name: ix_decisions_matter_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decisions_matter_status ON "__HCCA_SCHEMA__".decisions USING btree (matter_id, status);


--
-- Name: ix_decisions_owner_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decisions_owner_status ON "__HCCA_SCHEMA__".decisions USING btree (owner_user_id, status);


--
-- Name: ix_decisions_owner_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decisions_owner_user_id ON "__HCCA_SCHEMA__".decisions USING btree (owner_user_id);


--
-- Name: ix_decisions_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decisions_source ON "__HCCA_SCHEMA__".decisions USING btree (source_type, source_id);


--
-- Name: ix_decisions_source_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decisions_source_type ON "__HCCA_SCHEMA__".decisions USING btree (source_type);


--
-- Name: ix_decisions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decisions_status ON "__HCCA_SCHEMA__".decisions USING btree (status);


--
-- Name: ix_decisions_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_decisions_title ON "__HCCA_SCHEMA__".decisions USING btree (title);


--
-- Name: ix_defense_rules_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_defense_rules_active ON "__HCCA_SCHEMA__".defense_rules USING btree (is_active);


--
-- Name: ix_defense_rules_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_defense_rules_expires_at ON "__HCCA_SCHEMA__".defense_rules USING btree (expires_at);


--
-- Name: ix_defense_rules_type_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_defense_rules_type_target ON "__HCCA_SCHEMA__".defense_rules USING btree (rule_type, target);


--
-- Name: ix_discord_account_links_discord_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_discord_account_links_discord_user_id ON "__HCCA_SCHEMA__".discord_account_links USING btree (discord_user_id);


--
-- Name: ix_discord_account_links_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_account_links_is_active ON "__HCCA_SCHEMA__".discord_account_links USING btree (is_active);


--
-- Name: ix_discord_account_links_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_discord_account_links_user_id ON "__HCCA_SCHEMA__".discord_account_links USING btree (user_id);


--
-- Name: ix_discord_activity_workspace_guild; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_activity_workspace_guild ON "__HCCA_SCHEMA__".discord_activity_workspaces USING btree (guild_id, is_active);


--
-- Name: ix_discord_guild_configs_guild_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_discord_guild_configs_guild_id ON "__HCCA_SCHEMA__".discord_guild_configs USING btree (guild_id);


--
-- Name: ix_discord_guild_configs_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_guild_configs_is_active ON "__HCCA_SCHEMA__".discord_guild_configs USING btree (is_active);


--
-- Name: ix_discord_member_sync_state_drift; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_member_sync_state_drift ON "__HCCA_SCHEMA__".discord_member_sync_states USING btree (guild_id, has_role_drift);


--
-- Name: ix_discord_member_sync_states_discord_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_member_sync_states_discord_user_id ON "__HCCA_SCHEMA__".discord_member_sync_states USING btree (discord_user_id);


--
-- Name: ix_discord_member_sync_states_guild_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_member_sync_states_guild_id ON "__HCCA_SCHEMA__".discord_member_sync_states USING btree (guild_id);


--
-- Name: ix_discord_member_sync_states_has_role_drift; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_member_sync_states_has_role_drift ON "__HCCA_SCHEMA__".discord_member_sync_states USING btree (has_role_drift);


--
-- Name: ix_discord_member_sync_states_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_member_sync_states_user_id ON "__HCCA_SCHEMA__".discord_member_sync_states USING btree (user_id);


--
-- Name: ix_discord_nickname_prefix_rule_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_nickname_prefix_rule_active ON "__HCCA_SCHEMA__".discord_nickname_prefix_rules USING btree (guild_id, is_active);


--
-- Name: ix_discord_nickname_prefix_rule_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_nickname_prefix_rule_target ON "__HCCA_SCHEMA__".discord_nickname_prefix_rules USING btree (mapping_kind, org_id, position_id);


--
-- Name: ix_discord_nickname_prefix_rules_guild_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_nickname_prefix_rules_guild_id ON "__HCCA_SCHEMA__".discord_nickname_prefix_rules USING btree (guild_id);


--
-- Name: ix_discord_nickname_prefix_rules_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_nickname_prefix_rules_is_active ON "__HCCA_SCHEMA__".discord_nickname_prefix_rules USING btree (is_active);


--
-- Name: ix_discord_nickname_prefix_rules_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_nickname_prefix_rules_org_id ON "__HCCA_SCHEMA__".discord_nickname_prefix_rules USING btree (org_id);


--
-- Name: ix_discord_nickname_prefix_rules_position_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_nickname_prefix_rules_position_id ON "__HCCA_SCHEMA__".discord_nickname_prefix_rules USING btree (position_id);


--
-- Name: ix_discord_nickname_prefix_rules_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_nickname_prefix_rules_priority ON "__HCCA_SCHEMA__".discord_nickname_prefix_rules USING btree (priority);


--
-- Name: ix_discord_notification_route_event_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_notification_route_event_active ON "__HCCA_SCHEMA__".discord_notification_routes USING btree (event_key, is_active);


--
-- Name: ix_discord_notification_route_filters; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_notification_route_filters ON "__HCCA_SCHEMA__".discord_notification_routes USING btree (petition_type_id, org_id);


--
-- Name: ix_discord_notification_routes_guild_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_notification_routes_guild_id ON "__HCCA_SCHEMA__".discord_notification_routes USING btree (guild_id);


--
-- Name: ix_discord_notification_routes_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_notification_routes_is_active ON "__HCCA_SCHEMA__".discord_notification_routes USING btree (is_active);


--
-- Name: ix_discord_notification_routes_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_notification_routes_org_id ON "__HCCA_SCHEMA__".discord_notification_routes USING btree (org_id);


--
-- Name: ix_discord_notification_routes_petition_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_notification_routes_petition_type_id ON "__HCCA_SCHEMA__".discord_notification_routes USING btree (petition_type_id);


--
-- Name: ix_discord_org_channel_mapping_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_org_channel_mapping_active ON "__HCCA_SCHEMA__".discord_org_channel_mappings USING btree (guild_id, is_active);


--
-- Name: ix_discord_org_channel_mappings_guild_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_org_channel_mappings_guild_id ON "__HCCA_SCHEMA__".discord_org_channel_mappings USING btree (guild_id);


--
-- Name: ix_discord_org_channel_mappings_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_org_channel_mappings_is_active ON "__HCCA_SCHEMA__".discord_org_channel_mappings USING btree (is_active);


--
-- Name: ix_discord_org_channel_mappings_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_org_channel_mappings_org_id ON "__HCCA_SCHEMA__".discord_org_channel_mappings USING btree (org_id);


--
-- Name: ix_discord_role_mapping_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_mapping_target ON "__HCCA_SCHEMA__".discord_role_mappings USING btree (mapping_kind, org_id, position_id);


--
-- Name: ix_discord_role_mappings_guild_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_mappings_guild_id ON "__HCCA_SCHEMA__".discord_role_mappings USING btree (guild_id);


--
-- Name: ix_discord_role_mappings_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_mappings_is_active ON "__HCCA_SCHEMA__".discord_role_mappings USING btree (is_active);


--
-- Name: ix_discord_role_mappings_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_mappings_org_id ON "__HCCA_SCHEMA__".discord_role_mappings USING btree (org_id);


--
-- Name: ix_discord_role_mappings_position_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_mappings_position_id ON "__HCCA_SCHEMA__".discord_role_mappings USING btree (position_id);


--
-- Name: ix_discord_role_policies_guild_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_policies_guild_id ON "__HCCA_SCHEMA__".discord_role_policies USING btree (guild_id);


--
-- Name: ix_discord_role_policies_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_policies_is_active ON "__HCCA_SCHEMA__".discord_role_policies USING btree (is_active);


--
-- Name: ix_discord_role_policies_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_policies_org_id ON "__HCCA_SCHEMA__".discord_role_policies USING btree (org_id);


--
-- Name: ix_discord_role_policies_position_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_policies_position_id ON "__HCCA_SCHEMA__".discord_role_policies USING btree (position_id);


--
-- Name: ix_discord_role_policies_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_policies_priority ON "__HCCA_SCHEMA__".discord_role_policies USING btree (priority);


--
-- Name: ix_discord_role_policy_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_policy_active ON "__HCCA_SCHEMA__".discord_role_policies USING btree (guild_id, is_active);


--
-- Name: ix_discord_role_policy_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_discord_role_policy_target ON "__HCCA_SCHEMA__".discord_role_policies USING btree (org_id, position_id);


--
-- Name: ix_doc_approval_delegation_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_approval_delegation_lookup ON "__HCCA_SCHEMA__".document_approval_delegations USING btree (principal_user_id, org_id, is_active, start_at);


--
-- Name: ix_doc_approvals_pending_approver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_doc_approvals_pending_approver ON "__HCCA_SCHEMA__".document_approvals USING btree (status, approver_id) WHERE (status = 'pending'::"__HCCA_SCHEMA__".approvalstepstatus);


--
-- Name: ix_document_approval_delegations_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approval_delegations_created_by ON "__HCCA_SCHEMA__".document_approval_delegations USING btree (created_by);


--
-- Name: ix_document_approval_delegations_delegate_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approval_delegations_delegate_user_id ON "__HCCA_SCHEMA__".document_approval_delegations USING btree (delegate_user_id);


--
-- Name: ix_document_approval_delegations_end_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approval_delegations_end_at ON "__HCCA_SCHEMA__".document_approval_delegations USING btree (end_at);


--
-- Name: ix_document_approval_delegations_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approval_delegations_is_active ON "__HCCA_SCHEMA__".document_approval_delegations USING btree (is_active);


--
-- Name: ix_document_approval_delegations_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approval_delegations_org_id ON "__HCCA_SCHEMA__".document_approval_delegations USING btree (org_id);


--
-- Name: ix_document_approval_delegations_principal_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approval_delegations_principal_user_id ON "__HCCA_SCHEMA__".document_approval_delegations USING btree (principal_user_id);


--
-- Name: ix_document_approval_delegations_start_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approval_delegations_start_at ON "__HCCA_SCHEMA__".document_approval_delegations USING btree (start_at);


--
-- Name: ix_document_approvals_approver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approvals_approver_id ON "__HCCA_SCHEMA__".document_approvals USING btree (approver_id);


--
-- Name: ix_document_approvals_delegate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approvals_delegate_id ON "__HCCA_SCHEMA__".document_approvals USING btree (delegate_id);


--
-- Name: ix_document_approvals_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approvals_document_id ON "__HCCA_SCHEMA__".document_approvals USING btree (document_id);


--
-- Name: ix_document_approvals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approvals_status ON "__HCCA_SCHEMA__".document_approvals USING btree (status);


--
-- Name: ix_document_approvals_status_approver; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approvals_status_approver ON "__HCCA_SCHEMA__".document_approvals USING btree (status, approver_id);


--
-- Name: ix_document_approvals_status_delegate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_approvals_status_delegate ON "__HCCA_SCHEMA__".document_approvals USING btree (status, delegate_id);


--
-- Name: ix_document_attachments_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_attachments_document_id ON "__HCCA_SCHEMA__".document_attachments USING btree (document_id);


--
-- Name: ix_document_recipients_doc_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_recipients_doc_type ON "__HCCA_SCHEMA__".document_recipients USING btree (document_id, recipient_type);


--
-- Name: ix_document_recipients_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_recipients_document_id ON "__HCCA_SCHEMA__".document_recipients USING btree (document_id);


--
-- Name: ix_document_recipients_target_class; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_recipients_target_class ON "__HCCA_SCHEMA__".document_recipients USING btree (target_class_id);


--
-- Name: ix_document_recipients_target_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_recipients_target_org ON "__HCCA_SCHEMA__".document_recipients USING btree (target_org_id);


--
-- Name: ix_document_recipients_target_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_recipients_target_user ON "__HCCA_SCHEMA__".document_recipients USING btree (target_user_id);


--
-- Name: ix_document_revisions_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_revisions_document_id ON "__HCCA_SCHEMA__".document_revisions USING btree (document_id);


--
-- Name: ix_document_serial_templates_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_serial_templates_created_by ON "__HCCA_SCHEMA__".document_serial_templates USING btree (created_by);


--
-- Name: ix_document_serial_templates_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_serial_templates_is_active ON "__HCCA_SCHEMA__".document_serial_templates USING btree (is_active);


--
-- Name: ix_document_serial_templates_is_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_serial_templates_is_default ON "__HCCA_SCHEMA__".document_serial_templates USING btree (is_default);


--
-- Name: ix_document_serial_templates_is_default_president_publish; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_serial_templates_is_default_president_publish ON "__HCCA_SCHEMA__".document_serial_templates USING btree (is_default_president_publish);


--
-- Name: ix_document_serial_templates_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_serial_templates_org_id ON "__HCCA_SCHEMA__".document_serial_templates USING btree (org_id);


--
-- Name: ix_document_templates_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_category ON "__HCCA_SCHEMA__".document_templates USING btree (category);


--
-- Name: ix_document_templates_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_created_by ON "__HCCA_SCHEMA__".document_templates USING btree (created_by);


--
-- Name: ix_document_templates_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_is_active ON "__HCCA_SCHEMA__".document_templates USING btree (is_active);


--
-- Name: ix_document_templates_org_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_org_active ON "__HCCA_SCHEMA__".document_templates USING btree (org_id, is_active);


--
-- Name: ix_document_templates_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_document_templates_org_id ON "__HCCA_SCHEMA__".document_templates USING btree (org_id);


--
-- Name: ix_documents_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_activity_id ON "__HCCA_SCHEMA__".documents USING btree (activity_id);


--
-- Name: ix_documents_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_category ON "__HCCA_SCHEMA__".documents USING btree (category);


--
-- Name: ix_documents_created_at_desc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_created_at_desc ON "__HCCA_SCHEMA__".documents USING btree (created_at);


--
-- Name: ix_documents_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_created_by ON "__HCCA_SCHEMA__".documents USING btree (created_by);


--
-- Name: ix_documents_created_by_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_created_by_status ON "__HCCA_SCHEMA__".documents USING btree (created_by, status);


--
-- Name: ix_documents_is_public; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_is_public ON "__HCCA_SCHEMA__".documents USING btree (is_public);


--
-- Name: ix_documents_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_org_id ON "__HCCA_SCHEMA__".documents USING btree (org_id);


--
-- Name: ix_documents_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_org_status ON "__HCCA_SCHEMA__".documents USING btree (org_id, status);


--
-- Name: ix_documents_petition_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_petition_case_id ON "__HCCA_SCHEMA__".documents USING btree (petition_case_id);


--
-- Name: ix_documents_regulation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_regulation_id ON "__HCCA_SCHEMA__".documents USING btree (regulation_id);


--
-- Name: ix_documents_regulation_revision_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_regulation_revision_id ON "__HCCA_SCHEMA__".documents USING btree (regulation_revision_id);


--
-- Name: ix_documents_search_vector; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_search_vector ON "__HCCA_SCHEMA__".documents USING gin (search_vector);


--
-- Name: ix_documents_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_documents_serial_number ON "__HCCA_SCHEMA__".documents USING btree (serial_number);


--
-- Name: ix_documents_serial_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_serial_template_id ON "__HCCA_SCHEMA__".documents USING btree (serial_template_id);


--
-- Name: ix_documents_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_status ON "__HCCA_SCHEMA__".documents USING btree (status);


--
-- Name: ix_documents_status_archive_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_status_archive_at ON "__HCCA_SCHEMA__".documents USING btree (status, archive_at);


--
-- Name: ix_documents_status_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_status_created_at ON "__HCCA_SCHEMA__".documents USING btree (status, created_at);


--
-- Name: ix_documents_visibility_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_documents_visibility_level ON "__HCCA_SCHEMA__".documents USING btree (visibility_level);


--
-- Name: ix_election_ballot_boxes_election_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_election_ballot_boxes_election_id ON "__HCCA_SCHEMA__".election_ballot_boxes USING btree (election_id);


--
-- Name: ix_election_ballot_boxes_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_election_ballot_boxes_status ON "__HCCA_SCHEMA__".election_ballot_boxes USING btree (status);


--
-- Name: ix_election_candidate_members_candidate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_election_candidate_members_candidate_id ON "__HCCA_SCHEMA__".election_candidate_members USING btree (candidate_id);


--
-- Name: ix_election_candidates_election_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_election_candidates_election_id ON "__HCCA_SCHEMA__".election_candidates USING btree (election_id);


--
-- Name: ix_elections_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_elections_slug ON "__HCCA_SCHEMA__".elections USING btree (slug);


--
-- Name: ix_elections_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_elections_status ON "__HCCA_SCHEMA__".elections USING btree (status);


--
-- Name: ix_elections_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_elections_title ON "__HCCA_SCHEMA__".elections USING btree (title);


--
-- Name: ix_electronic_credential_authorizations_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_electronic_credential_authorizations_is_active ON "__HCCA_SCHEMA__".electronic_credential_authorizations USING btree (is_active);


--
-- Name: ix_email_attachments_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_attachments_message ON "__HCCA_SCHEMA__".email_attachments USING btree (message_id);


--
-- Name: ix_email_attachments_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_attachments_template ON "__HCCA_SCHEMA__".email_attachments USING btree (template_id);


--
-- Name: ix_email_campaign_recipients_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_campaign_recipients_email ON "__HCCA_SCHEMA__".email_campaign_recipients USING btree (email);


--
-- Name: ix_email_campaign_recipients_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_campaign_recipients_message_id ON "__HCCA_SCHEMA__".email_campaign_recipients USING btree (message_id);


--
-- Name: ix_email_campaign_recipients_message_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_campaign_recipients_message_status ON "__HCCA_SCHEMA__".email_campaign_recipients USING btree (message_id, status);


--
-- Name: ix_email_campaign_recipients_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_campaign_recipients_user_id ON "__HCCA_SCHEMA__".email_campaign_recipients USING btree (user_id);


--
-- Name: ix_email_messages_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_email_messages_idempotency_key ON "__HCCA_SCHEMA__".email_messages USING btree (idempotency_key);


--
-- Name: ix_email_messages_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_messages_org_id ON "__HCCA_SCHEMA__".email_messages USING btree (org_id);


--
-- Name: ix_email_messages_sender_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_messages_sender_created ON "__HCCA_SCHEMA__".email_messages USING btree (sender_id, created_at);


--
-- Name: ix_email_messages_sender_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_messages_sender_id ON "__HCCA_SCHEMA__".email_messages USING btree (sender_id);


--
-- Name: ix_email_messages_status_scheduled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_messages_status_scheduled ON "__HCCA_SCHEMA__".email_messages USING btree (status, scheduled_at);


--
-- Name: ix_email_messages_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_messages_template_id ON "__HCCA_SCHEMA__".email_messages USING btree (template_id);


--
-- Name: ix_email_recipient_events_recipient_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_recipient_events_recipient_type ON "__HCCA_SCHEMA__".email_recipient_events USING btree (recipient_id, event_type);


--
-- Name: ix_email_recipient_list_members_list_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_recipient_list_members_list_id ON "__HCCA_SCHEMA__".email_recipient_list_members USING btree (list_id);


--
-- Name: ix_email_recipient_lists_org_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_recipient_lists_org_active ON "__HCCA_SCHEMA__".email_recipient_lists USING btree (org_id, is_active);


--
-- Name: ix_email_recipient_lists_owner_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_recipient_lists_owner_updated ON "__HCCA_SCHEMA__".email_recipient_lists USING btree (owner_id, updated_at);


--
-- Name: ix_email_suppressions_active_reason; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_suppressions_active_reason ON "__HCCA_SCHEMA__".email_suppressions USING btree (is_active, reason);


--
-- Name: ix_email_suppressions_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_email_suppressions_email ON "__HCCA_SCHEMA__".email_suppressions USING btree (email);


--
-- Name: ix_email_template_versions_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_template_versions_template_id ON "__HCCA_SCHEMA__".email_template_versions USING btree (template_id);


--
-- Name: ix_email_templates_org_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_templates_org_active ON "__HCCA_SCHEMA__".email_templates USING btree (org_id, is_active);


--
-- Name: ix_email_templates_owner_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_email_templates_owner_updated ON "__HCCA_SCHEMA__".email_templates USING btree (owner_id, updated_at);


--
-- Name: ix_entity_relations_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_entity_relations_case ON "__HCCA_SCHEMA__".entity_relations USING btree (case_id, target_type);


--
-- Name: ix_entity_relations_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_entity_relations_case_id ON "__HCCA_SCHEMA__".entity_relations USING btree (case_id);


--
-- Name: ix_entity_relations_matter; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_entity_relations_matter ON "__HCCA_SCHEMA__".entity_relations USING btree (matter_id, target_type);


--
-- Name: ix_entity_relations_matter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_entity_relations_matter_id ON "__HCCA_SCHEMA__".entity_relations USING btree (matter_id);


--
-- Name: ix_entity_relations_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_entity_relations_target ON "__HCCA_SCHEMA__".entity_relations USING btree (target_type, target_id);


--
-- Name: ix_entity_relations_target_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_entity_relations_target_type ON "__HCCA_SCHEMA__".entity_relations USING btree (target_type);


--
-- Name: ix_exam_paper_downloads_paper_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_paper_downloads_paper_created ON "__HCCA_SCHEMA__".exam_paper_downloads USING btree (paper_id, downloaded_at);


--
-- Name: ix_exam_paper_downloads_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_paper_downloads_user ON "__HCCA_SCHEMA__".exam_paper_downloads USING btree (user_id);


--
-- Name: ix_exam_papers_academic_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_papers_academic_year ON "__HCCA_SCHEMA__".exam_papers USING btree (academic_year);


--
-- Name: ix_exam_papers_exam_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_papers_exam_number ON "__HCCA_SCHEMA__".exam_papers USING btree (exam_number);


--
-- Name: ix_exam_papers_filters; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_papers_filters ON "__HCCA_SCHEMA__".exam_papers USING btree (is_published, academic_year, semester, grade, grade_track);


--
-- Name: ix_exam_papers_grade; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_papers_grade ON "__HCCA_SCHEMA__".exam_papers USING btree (grade);


--
-- Name: ix_exam_papers_grade_track; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_papers_grade_track ON "__HCCA_SCHEMA__".exam_papers USING btree (grade_track);


--
-- Name: ix_exam_papers_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_papers_is_active ON "__HCCA_SCHEMA__".exam_papers USING btree (is_active);


--
-- Name: ix_exam_papers_is_published; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_papers_is_published ON "__HCCA_SCHEMA__".exam_papers USING btree (is_published);


--
-- Name: ix_exam_papers_semester; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_papers_semester ON "__HCCA_SCHEMA__".exam_papers USING btree (semester);


--
-- Name: ix_exam_papers_subject; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_exam_papers_subject ON "__HCCA_SCHEMA__".exam_papers USING btree (subject);


--
-- Name: ix_feature_flags_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_feature_flags_enabled ON "__HCCA_SCHEMA__".feature_flags USING btree (is_globally_enabled);


--
-- Name: ix_finance_budget_allocation_node; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budget_allocation_node ON "__HCCA_SCHEMA__".finance_budget_allocations USING btree (node_id, submission_id);


--
-- Name: ix_finance_budget_evidence_allocation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budget_evidence_allocation ON "__HCCA_SCHEMA__".finance_budget_allocation_evidence USING btree (allocation_id);


--
-- Name: ix_finance_budget_expense_budget_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budget_expense_budget_date ON "__HCCA_SCHEMA__".finance_budget_expenses USING btree (budget_id, entry_date);


--
-- Name: ix_finance_budget_expense_evidence_expense; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budget_expense_evidence_expense ON "__HCCA_SCHEMA__".finance_budget_expense_evidence USING btree (expense_id);


--
-- Name: ix_finance_budget_expense_item_expense; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budget_expense_item_expense ON "__HCCA_SCHEMA__".finance_budget_expense_items USING btree (expense_id);


--
-- Name: ix_finance_budget_income_record_budget; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budget_income_record_budget ON "__HCCA_SCHEMA__".finance_budget_income_records USING btree (budget_id, entry_date);


--
-- Name: ix_finance_budget_income_submission; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budget_income_submission ON "__HCCA_SCHEMA__".finance_budget_income_items USING btree (submission_id);


--
-- Name: ix_finance_budget_node_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budget_node_parent ON "__HCCA_SCHEMA__".finance_budget_nodes USING btree (budget_id, parent_id);


--
-- Name: ix_finance_budget_submission_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budget_submission_status ON "__HCCA_SCHEMA__".finance_budget_submissions USING btree (budget_id, status);


--
-- Name: ix_finance_budget_submissions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budget_submissions_status ON "__HCCA_SCHEMA__".finance_budget_submissions USING btree (status);


--
-- Name: ix_finance_budgets_ledger; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budgets_ledger ON "__HCCA_SCHEMA__".finance_budgets USING btree (ledger_id);


--
-- Name: ix_finance_budgets_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_budgets_period ON "__HCCA_SCHEMA__".finance_budgets USING btree (period_id);


--
-- Name: ix_finance_chart_accounts_account_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_chart_accounts_account_type ON "__HCCA_SCHEMA__".finance_chart_accounts USING btree (account_type);


--
-- Name: ix_finance_claim_item_budget_node; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_claim_item_budget_node ON "__HCCA_SCHEMA__".finance_expense_claim_items USING btree (budget_node_id);


--
-- Name: ix_finance_expense_claim_item_evidence_item; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_expense_claim_item_evidence_item ON "__HCCA_SCHEMA__".finance_expense_claim_item_evidence USING btree (item_id);


--
-- Name: ix_finance_expense_claim_items_journal_entry_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_expense_claim_items_journal_entry_id ON "__HCCA_SCHEMA__".finance_expense_claim_items USING btree (journal_entry_id);


--
-- Name: ix_finance_journal_advanced_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_journal_advanced_by ON "__HCCA_SCHEMA__".finance_journal_entries USING btree (advanced_by_id);


--
-- Name: ix_finance_journal_entries_claim_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_journal_entries_claim_status ON "__HCCA_SCHEMA__".finance_journal_entries USING btree (claim_status);


--
-- Name: ix_finance_journal_ledger_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_journal_ledger_status ON "__HCCA_SCHEMA__".finance_journal_entries USING btree (ledger_id, status);


--
-- Name: ix_finance_journal_proposing_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_journal_proposing_org ON "__HCCA_SCHEMA__".finance_journal_entries USING btree (proposing_org_id);


--
-- Name: ix_finance_line_account; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_finance_line_account ON "__HCCA_SCHEMA__".finance_journal_lines USING btree (account_id);


--
-- Name: ix_governance_cases_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_cases_is_active ON "__HCCA_SCHEMA__".governance_cases USING btree (is_active);


--
-- Name: ix_governance_cases_matter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_cases_matter_id ON "__HCCA_SCHEMA__".governance_cases USING btree (matter_id);


--
-- Name: ix_governance_cases_matter_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_cases_matter_status ON "__HCCA_SCHEMA__".governance_cases USING btree (matter_id, status);


--
-- Name: ix_governance_cases_owner_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_cases_owner_status ON "__HCCA_SCHEMA__".governance_cases USING btree (owner_user_id, status);


--
-- Name: ix_governance_cases_owner_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_cases_owner_user_id ON "__HCCA_SCHEMA__".governance_cases USING btree (owner_user_id);


--
-- Name: ix_governance_cases_program_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_cases_program_id ON "__HCCA_SCHEMA__".governance_cases USING btree (program_id);


--
-- Name: ix_governance_cases_program_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_cases_program_status ON "__HCCA_SCHEMA__".governance_cases USING btree (program_id, status);


--
-- Name: ix_governance_cases_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_cases_status ON "__HCCA_SCHEMA__".governance_cases USING btree (status);


--
-- Name: ix_governance_cases_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_cases_title ON "__HCCA_SCHEMA__".governance_cases USING btree (title);


--
-- Name: ix_governance_discord_event_routes_workspace_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_discord_event_routes_workspace_id ON "__HCCA_SCHEMA__".governance_discord_event_routes USING btree (workspace_id);


--
-- Name: ix_governance_discord_workspace_guild; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_discord_workspace_guild ON "__HCCA_SCHEMA__".governance_discord_workspaces USING btree (guild_id, is_active);


--
-- Name: ix_governance_workflow_templates_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_workflow_templates_is_active ON "__HCCA_SCHEMA__".governance_workflow_templates USING btree (is_active);


--
-- Name: ix_governance_workflow_templates_template_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_workflow_templates_template_type ON "__HCCA_SCHEMA__".governance_workflow_templates USING btree (template_type);


--
-- Name: ix_governance_workflow_templates_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_governance_workflow_templates_type ON "__HCCA_SCHEMA__".governance_workflow_templates USING btree (template_type, is_active);


--
-- Name: ix_inventory_categories_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_categories_is_active ON "__HCCA_SCHEMA__".inventory_categories USING btree (is_active);


--
-- Name: ix_inventory_categories_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_categories_org_id ON "__HCCA_SCHEMA__".inventory_categories USING btree (org_id);


--
-- Name: ix_inventory_items_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_items_category_id ON "__HCCA_SCHEMA__".inventory_items USING btree (category_id);


--
-- Name: ix_inventory_items_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_items_is_active ON "__HCCA_SCHEMA__".inventory_items USING btree (is_active);


--
-- Name: ix_inventory_items_item_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_items_item_type ON "__HCCA_SCHEMA__".inventory_items USING btree (item_type);


--
-- Name: ix_inventory_items_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_items_name ON "__HCCA_SCHEMA__".inventory_items USING btree (name);


--
-- Name: ix_inventory_items_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_items_org_id ON "__HCCA_SCHEMA__".inventory_items USING btree (org_id);


--
-- Name: ix_inventory_procurement_items_procurement_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_procurement_items_procurement_id ON "__HCCA_SCHEMA__".inventory_procurement_items USING btree (procurement_id);


--
-- Name: ix_inventory_procurements_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_procurements_org_id ON "__HCCA_SCHEMA__".inventory_procurements USING btree (org_id);


--
-- Name: ix_inventory_procurements_requester_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_procurements_requester_id ON "__HCCA_SCHEMA__".inventory_procurements USING btree (requester_id);


--
-- Name: ix_inventory_procurements_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_procurements_status ON "__HCCA_SCHEMA__".inventory_procurements USING btree (status);


--
-- Name: ix_inventory_transactions_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_transactions_created_by_id ON "__HCCA_SCHEMA__".inventory_transactions USING btree (created_by_id);


--
-- Name: ix_inventory_transactions_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_transactions_item_id ON "__HCCA_SCHEMA__".inventory_transactions USING btree (item_id);


--
-- Name: ix_inventory_transactions_txn_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_inventory_transactions_txn_type ON "__HCCA_SCHEMA__".inventory_transactions USING btree (txn_type);


--
-- Name: ix_judicial_petitions_docket_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_judicial_petitions_docket_number ON "__HCCA_SCHEMA__".judicial_petitions USING btree (docket_number);


--
-- Name: ix_judicial_petitions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_judicial_petitions_status ON "__HCCA_SCHEMA__".judicial_petitions USING btree (status);


--
-- Name: ix_judicial_petitions_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_judicial_petitions_status_created ON "__HCCA_SCHEMA__".judicial_petitions USING btree (status, created_at);


--
-- Name: ix_judicial_petitions_submitter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_judicial_petitions_submitter_id ON "__HCCA_SCHEMA__".judicial_petitions USING btree (submitter_id);


--
-- Name: ix_judicial_petitions_submitter_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_judicial_petitions_submitter_status ON "__HCCA_SCHEMA__".judicial_petitions USING btree (submitter_id, status);


--
-- Name: ix_judicial_petitions_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_judicial_petitions_title ON "__HCCA_SCHEMA__".judicial_petitions USING btree (title);


--
-- Name: ix_line_account_links_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_line_account_links_is_active ON "__HCCA_SCHEMA__".line_account_links USING btree (is_active);


--
-- Name: ix_line_account_links_line_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_line_account_links_line_user_id ON "__HCCA_SCHEMA__".line_account_links USING btree (line_user_id);


--
-- Name: ix_line_account_links_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_line_account_links_user_id ON "__HCCA_SCHEMA__".line_account_links USING btree (user_id);


--
-- Name: ix_matter_resources_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_resources_external_id ON "__HCCA_SCHEMA__".matter_resources USING btree (external_id);


--
-- Name: ix_matter_resources_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_resources_is_active ON "__HCCA_SCHEMA__".matter_resources USING btree (is_active);


--
-- Name: ix_matter_resources_matter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_resources_matter_id ON "__HCCA_SCHEMA__".matter_resources USING btree (matter_id);


--
-- Name: ix_matter_resources_matter_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_resources_matter_type ON "__HCCA_SCHEMA__".matter_resources USING btree (matter_id, resource_type);


--
-- Name: ix_matter_resources_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_resources_provider ON "__HCCA_SCHEMA__".matter_resources USING btree (provider, external_id);


--
-- Name: ix_matter_resources_provider_single; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_resources_provider_single ON "__HCCA_SCHEMA__".matter_resources USING btree (provider);


--
-- Name: ix_matter_resources_resource_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_resources_resource_type ON "__HCCA_SCHEMA__".matter_resources USING btree (resource_type);


--
-- Name: ix_matter_role_assignments_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_role_assignments_is_active ON "__HCCA_SCHEMA__".matter_role_assignments USING btree (is_active);


--
-- Name: ix_matter_role_assignments_matter; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_role_assignments_matter ON "__HCCA_SCHEMA__".matter_role_assignments USING btree (matter_id, parent_id);


--
-- Name: ix_matter_role_assignments_matter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_role_assignments_matter_id ON "__HCCA_SCHEMA__".matter_role_assignments USING btree (matter_id);


--
-- Name: ix_matter_role_assignments_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_role_assignments_parent_id ON "__HCCA_SCHEMA__".matter_role_assignments USING btree (parent_id);


--
-- Name: ix_matter_role_assignments_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_role_assignments_user ON "__HCCA_SCHEMA__".matter_role_assignments USING btree (user_id);


--
-- Name: ix_matter_role_assignments_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matter_role_assignments_user_id ON "__HCCA_SCHEMA__".matter_role_assignments USING btree (user_id);


--
-- Name: ix_matters_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matters_is_active ON "__HCCA_SCHEMA__".matters USING btree (is_active);


--
-- Name: ix_matters_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matters_org_status ON "__HCCA_SCHEMA__".matters USING btree (org_id, status);


--
-- Name: ix_matters_owner_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matters_owner_status ON "__HCCA_SCHEMA__".matters USING btree (owner_user_id, status);


--
-- Name: ix_matters_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matters_priority ON "__HCCA_SCHEMA__".matters USING btree (priority);


--
-- Name: ix_matters_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_matters_slug ON "__HCCA_SCHEMA__".matters USING btree (slug);


--
-- Name: ix_matters_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matters_status ON "__HCCA_SCHEMA__".matters USING btree (status);


--
-- Name: ix_matters_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matters_title ON "__HCCA_SCHEMA__".matters USING btree (title);


--
-- Name: ix_matters_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matters_type_status ON "__HCCA_SCHEMA__".matters USING btree (matter_type, status);


--
-- Name: ix_matters_visibility; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_matters_visibility ON "__HCCA_SCHEMA__".matters USING btree (visibility);


--
-- Name: ix_merchandise_submission_files_submission_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_merchandise_submission_files_submission_id ON "__HCCA_SCHEMA__".merchandise_submission_files USING btree (submission_id);


--
-- Name: ix_merchandise_submission_items_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_merchandise_submission_items_created_by_id ON "__HCCA_SCHEMA__".merchandise_submission_items USING btree (created_by_id);


--
-- Name: ix_merchandise_submission_items_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_merchandise_submission_items_name ON "__HCCA_SCHEMA__".merchandise_submission_items USING btree (name);


--
-- Name: ix_merchandise_submissions_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_merchandise_submissions_item_id ON "__HCCA_SCHEMA__".merchandise_submissions USING btree (item_id);


--
-- Name: ix_merchandise_submissions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_merchandise_submissions_status ON "__HCCA_SCHEMA__".merchandise_submissions USING btree (status);


--
-- Name: ix_merchandise_submissions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_merchandise_submissions_user_id ON "__HCCA_SCHEMA__".merchandise_submissions USING btree (user_id);


--
-- Name: ix_merchandise_submissions_voting_survey_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_merchandise_submissions_voting_survey_id ON "__HCCA_SCHEMA__".merchandise_submissions USING btree (voting_survey_id);


--
-- Name: ix_navigation_profile_positions_position_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_navigation_profile_positions_position_id ON "__HCCA_SCHEMA__".navigation_profile_positions USING btree (position_id);


--
-- Name: ix_navigation_profile_positions_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_navigation_profile_positions_profile_id ON "__HCCA_SCHEMA__".navigation_profile_positions USING btree (profile_id);


--
-- Name: ix_navigation_profiles_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_navigation_profiles_key ON "__HCCA_SCHEMA__".navigation_profiles USING btree (key);


--
-- Name: ix_notifications_email_batch; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_email_batch ON "__HCCA_SCHEMA__".notifications USING btree (user_id, type, email_queued_at, created_at);


--
-- Name: ix_notifications_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_created ON "__HCCA_SCHEMA__".notifications USING btree (user_id, created_at);


--
-- Name: ix_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_id ON "__HCCA_SCHEMA__".notifications USING btree (user_id);


--
-- Name: ix_notifications_user_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notifications_user_read ON "__HCCA_SCHEMA__".notifications USING btree (user_id, is_read);


--
-- Name: ix_observability_releases_commit_sha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_observability_releases_commit_sha ON "__HCCA_SCHEMA__".observability_releases USING btree (commit_sha);


--
-- Name: ix_order_items_delegation_link_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_order_items_delegation_link_id ON "__HCCA_SCHEMA__".order_items USING btree (delegation_link_id);


--
-- Name: ix_order_items_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_order_items_order_id ON "__HCCA_SCHEMA__".order_items USING btree (order_id);


--
-- Name: ix_order_items_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_order_items_product_id ON "__HCCA_SCHEMA__".order_items USING btree (product_id);


--
-- Name: ix_orders_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_activity_id ON "__HCCA_SCHEMA__".orders USING btree (activity_id);


--
-- Name: ix_orders_assistance_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_assistance_scope ON "__HCCA_SCHEMA__".orders USING btree (assistance_scope);


--
-- Name: ix_orders_assisted_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_assisted_by_id ON "__HCCA_SCHEMA__".orders USING btree (assisted_by_id);


--
-- Name: ix_orders_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_category_id ON "__HCCA_SCHEMA__".orders USING btree (category_id);


--
-- Name: ix_orders_class_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_class_id ON "__HCCA_SCHEMA__".orders USING btree (class_id);


--
-- Name: ix_orders_is_class_collected; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_is_class_collected ON "__HCCA_SCHEMA__".orders USING btree (is_class_collected);


--
-- Name: ix_orders_promotion_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_promotion_id ON "__HCCA_SCHEMA__".orders USING btree (promotion_id);


--
-- Name: ix_orders_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_orders_serial_number ON "__HCCA_SCHEMA__".orders USING btree (serial_number);


--
-- Name: ix_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_status ON "__HCCA_SCHEMA__".orders USING btree (status);


--
-- Name: ix_orders_test_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_test_product_id ON "__HCCA_SCHEMA__".orders USING btree (test_product_id);


--
-- Name: ix_orders_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orders_user_id ON "__HCCA_SCHEMA__".orders USING btree (user_id);


--
-- Name: ix_orgs_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orgs_is_active ON "__HCCA_SCHEMA__".orgs USING btree (is_active);


--
-- Name: ix_orgs_leader_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orgs_leader_user_id ON "__HCCA_SCHEMA__".orgs USING btree (leader_user_id);


--
-- Name: ix_orgs_parent_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orgs_parent_active ON "__HCCA_SCHEMA__".orgs USING btree (parent_id, is_active);


--
-- Name: ix_orgs_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_orgs_parent_id ON "__HCCA_SCHEMA__".orgs USING btree (parent_id);


--
-- Name: ix_outbox_events_locked_until; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_outbox_events_locked_until ON "__HCCA_SCHEMA__".outbox_events USING btree (locked_until);


--
-- Name: ix_outbox_events_next_attempt_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_outbox_events_next_attempt_at ON "__HCCA_SCHEMA__".outbox_events USING btree (next_attempt_at);


--
-- Name: ix_outbox_pending_schedule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_outbox_pending_schedule ON "__HCCA_SCHEMA__".outbox_events USING btree (status, next_attempt_at, locked_until, created_at);


--
-- Name: ix_outbox_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_outbox_status_created ON "__HCCA_SCHEMA__".outbox_events USING btree (status, created_at);


--
-- Name: ix_pagespeed_audits_run_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pagespeed_audits_run_id ON "__HCCA_SCHEMA__".pagespeed_audits USING btree (run_id);


--
-- Name: ix_pagespeed_runs_url_strategy_tested_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pagespeed_runs_url_strategy_tested_at ON "__HCCA_SCHEMA__".pagespeed_runs USING btree (url, strategy, tested_at);


--
-- Name: ix_partner_application_fields_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_application_fields_is_active ON "__HCCA_SCHEMA__".partner_application_fields USING btree (is_active);


--
-- Name: ix_partner_application_fields_settings_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_application_fields_settings_id ON "__HCCA_SCHEMA__".partner_application_fields USING btree (settings_id);


--
-- Name: ix_partner_business_accounts_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_business_accounts_business_id ON "__HCCA_SCHEMA__".partner_business_accounts USING btree (business_id);


--
-- Name: ix_partner_business_accounts_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_business_accounts_is_active ON "__HCCA_SCHEMA__".partner_business_accounts USING btree (is_active);


--
-- Name: ix_partner_business_accounts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_business_accounts_user_id ON "__HCCA_SCHEMA__".partner_business_accounts USING btree (user_id);


--
-- Name: ix_partner_business_applications_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_business_applications_status ON "__HCCA_SCHEMA__".partner_business_applications USING btree (status);


--
-- Name: ix_partner_business_applications_submitted_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_business_applications_submitted_by ON "__HCCA_SCHEMA__".partner_business_applications USING btree (submitted_by);


--
-- Name: ix_partner_business_images_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_business_images_business_id ON "__HCCA_SCHEMA__".partner_business_images USING btree (business_id);


--
-- Name: ix_partner_businesses_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_businesses_category ON "__HCCA_SCHEMA__".partner_businesses USING btree (category);


--
-- Name: ix_partner_businesses_listing_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_businesses_listing_type ON "__HCCA_SCHEMA__".partner_businesses USING btree (listing_type);


--
-- Name: ix_partner_businesses_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_businesses_name ON "__HCCA_SCHEMA__".partner_businesses USING btree (name);


--
-- Name: ix_partner_businesses_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_businesses_status ON "__HCCA_SCHEMA__".partner_businesses USING btree (status);


--
-- Name: ix_partner_locations_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_locations_business_id ON "__HCCA_SCHEMA__".partner_locations USING btree (business_id);


--
-- Name: ix_partner_locations_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_locations_is_active ON "__HCCA_SCHEMA__".partner_locations USING btree (is_active);


--
-- Name: ix_partner_locations_latitude; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_locations_latitude ON "__HCCA_SCHEMA__".partner_locations USING btree (latitude);


--
-- Name: ix_partner_locations_longitude; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_locations_longitude ON "__HCCA_SCHEMA__".partner_locations USING btree (longitude);


--
-- Name: ix_partner_offers_business_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_offers_business_id ON "__HCCA_SCHEMA__".partner_offers USING btree (business_id);


--
-- Name: ix_partner_offers_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_offers_is_active ON "__HCCA_SCHEMA__".partner_offers USING btree (is_active);


--
-- Name: ix_partner_submissions_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_submissions_name ON "__HCCA_SCHEMA__".partner_submissions USING btree (name);


--
-- Name: ix_partner_submissions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_submissions_status ON "__HCCA_SCHEMA__".partner_submissions USING btree (status);


--
-- Name: ix_partner_submissions_submitted_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_submissions_submitted_by ON "__HCCA_SCHEMA__".partner_submissions USING btree (submitted_by);


--
-- Name: ix_partner_tags_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_partner_tags_is_active ON "__HCCA_SCHEMA__".partner_tags USING btree (is_active);


--
-- Name: ix_passkey_credentials_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_passkey_credentials_user_id ON "__HCCA_SCHEMA__".passkey_credentials USING btree (user_id);


--
-- Name: ix_people_display_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_people_display_name ON "__HCCA_SCHEMA__".people USING btree (display_name);


--
-- Name: ix_people_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_people_email ON "__HCCA_SCHEMA__".people USING btree (email);


--
-- Name: ix_people_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_people_status ON "__HCCA_SCHEMA__".people USING btree (status);


--
-- Name: ix_people_student_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_people_student_id ON "__HCCA_SCHEMA__".people USING btree (student_id);


--
-- Name: ix_people_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_people_user_id ON "__HCCA_SCHEMA__".people USING btree (user_id);


--
-- Name: ix_permissions_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_permissions_code ON "__HCCA_SCHEMA__".permissions USING btree (code);


--
-- Name: ix_person_affiliations_academic_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_academic_year ON "__HCCA_SCHEMA__".person_affiliations USING btree (academic_year);


--
-- Name: ix_person_affiliations_class_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_class_kind ON "__HCCA_SCHEMA__".person_affiliations USING btree (class_id, kind);


--
-- Name: ix_person_affiliations_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_kind ON "__HCCA_SCHEMA__".person_affiliations USING btree (kind);


--
-- Name: ix_person_affiliations_kind_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_kind_status ON "__HCCA_SCHEMA__".person_affiliations USING btree (kind, status);


--
-- Name: ix_person_affiliations_org_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_org_kind ON "__HCCA_SCHEMA__".person_affiliations USING btree (org_id, kind);


--
-- Name: ix_person_affiliations_person_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_person_id ON "__HCCA_SCHEMA__".person_affiliations USING btree (person_id);


--
-- Name: ix_person_affiliations_person_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_person_status ON "__HCCA_SCHEMA__".person_affiliations USING btree (person_id, status);


--
-- Name: ix_person_affiliations_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_position ON "__HCCA_SCHEMA__".person_affiliations USING btree (position_id);


--
-- Name: ix_person_affiliations_role_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_role_key ON "__HCCA_SCHEMA__".person_affiliations USING btree (role_key);


--
-- Name: ix_person_affiliations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_status ON "__HCCA_SCHEMA__".person_affiliations USING btree (status);


--
-- Name: ix_person_affiliations_synced_up; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_person_affiliations_synced_up ON "__HCCA_SCHEMA__".person_affiliations USING btree (synced_user_position_id);


--
-- Name: ix_petition_attachments_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_attachments_case_id ON "__HCCA_SCHEMA__".petition_attachments USING btree (case_id);


--
-- Name: ix_petition_attachments_visibility; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_attachments_visibility ON "__HCCA_SCHEMA__".petition_attachments USING btree (visibility);


--
-- Name: ix_petition_case_events_actor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_case_events_actor_id ON "__HCCA_SCHEMA__".petition_case_events USING btree (actor_id);


--
-- Name: ix_petition_case_events_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_case_events_case_id ON "__HCCA_SCHEMA__".petition_case_events USING btree (case_id);


--
-- Name: ix_petition_case_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_case_events_event_type ON "__HCCA_SCHEMA__".petition_case_events USING btree (event_type);


--
-- Name: ix_petition_case_events_related_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_case_events_related_document_id ON "__HCCA_SCHEMA__".petition_case_events USING btree (related_document_id);


--
-- Name: ix_petition_case_events_visibility; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_case_events_visibility ON "__HCCA_SCHEMA__".petition_case_events USING btree (visibility);


--
-- Name: ix_petition_cases_assigned_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_assigned_to_id ON "__HCCA_SCHEMA__".petition_cases USING btree (assigned_to_id);


--
-- Name: ix_petition_cases_case_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_petition_cases_case_number ON "__HCCA_SCHEMA__".petition_cases USING btree (case_number);


--
-- Name: ix_petition_cases_current_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_current_org_id ON "__HCCA_SCHEMA__".petition_cases USING btree (current_org_id);


--
-- Name: ix_petition_cases_discord_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_discord_channel_id ON "__HCCA_SCHEMA__".petition_cases USING btree (discord_channel_id);


--
-- Name: ix_petition_cases_is_confidential; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_is_confidential ON "__HCCA_SCHEMA__".petition_cases USING btree (is_confidential);


--
-- Name: ix_petition_cases_is_named; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_is_named ON "__HCCA_SCHEMA__".petition_cases USING btree (is_named);


--
-- Name: ix_petition_cases_public_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_public_status ON "__HCCA_SCHEMA__".petition_cases USING btree (public_status);


--
-- Name: ix_petition_cases_share_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_share_token_hash ON "__HCCA_SCHEMA__".petition_cases USING btree (share_token_hash);


--
-- Name: ix_petition_cases_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_status ON "__HCCA_SCHEMA__".petition_cases USING btree (status);


--
-- Name: ix_petition_cases_submitter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_submitter_id ON "__HCCA_SCHEMA__".petition_cases USING btree (submitter_id);


--
-- Name: ix_petition_cases_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_title ON "__HCCA_SCHEMA__".petition_cases USING btree (title);


--
-- Name: ix_petition_cases_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_cases_type_id ON "__HCCA_SCHEMA__".petition_cases USING btree (type_id);


--
-- Name: ix_petition_notification_rules_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_notification_rules_org ON "__HCCA_SCHEMA__".petition_notification_rules USING btree (org_id);


--
-- Name: ix_petition_notification_rules_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_notification_rules_type ON "__HCCA_SCHEMA__".petition_notification_rules USING btree (petition_type_id);


--
-- Name: ix_petition_types_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_types_is_active ON "__HCCA_SCHEMA__".petition_types USING btree (is_active);


--
-- Name: ix_petition_types_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_petition_types_name ON "__HCCA_SCHEMA__".petition_types USING btree (name);


--
-- Name: ix_petition_types_responsible_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_types_responsible_org_id ON "__HCCA_SCHEMA__".petition_types USING btree (responsible_org_id);


--
-- Name: ix_petition_types_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petition_types_sort_order ON "__HCCA_SCHEMA__".petition_types USING btree (sort_order);


--
-- Name: ix_petitions_assigned_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_petitions_assigned_status ON "__HCCA_SCHEMA__".petition_cases USING btree (assigned_to_id, status) WHERE (status = ANY (ARRAY['submitted'::"__HCCA_SCHEMA__".petitionstatus, 'in_progress'::"__HCCA_SCHEMA__".petitionstatus, 'needs_info'::"__HCCA_SCHEMA__".petitionstatus]));


--
-- Name: ix_planning_document_attachments_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_document_attachments_document_id ON "__HCCA_SCHEMA__".planning_document_attachments USING btree (document_id);


--
-- Name: ix_planning_document_revisions_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_document_revisions_document ON "__HCCA_SCHEMA__".planning_document_revisions USING btree (document_id, version_number);


--
-- Name: ix_planning_document_revisions_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_document_revisions_document_id ON "__HCCA_SCHEMA__".planning_document_revisions USING btree (document_id);


--
-- Name: ix_planning_documents_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_documents_case ON "__HCCA_SCHEMA__".planning_documents USING btree (case_id);


--
-- Name: ix_planning_documents_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_documents_is_active ON "__HCCA_SCHEMA__".planning_documents USING btree (is_active);


--
-- Name: ix_planning_documents_matter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_documents_matter_id ON "__HCCA_SCHEMA__".planning_documents USING btree (matter_id);


--
-- Name: ix_planning_documents_matter_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_documents_matter_status ON "__HCCA_SCHEMA__".planning_documents USING btree (matter_id, status);


--
-- Name: ix_planning_documents_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_documents_status ON "__HCCA_SCHEMA__".planning_documents USING btree (status);


--
-- Name: ix_planning_documents_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_documents_title ON "__HCCA_SCHEMA__".planning_documents USING btree (title);


--
-- Name: ix_planning_revision_attachments_revision; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_planning_revision_attachments_revision ON "__HCCA_SCHEMA__".planning_document_revision_attachments USING btree (revision_id, sort_order);


--
-- Name: ix_policy_consents_document; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policy_consents_document ON "__HCCA_SCHEMA__".policy_consents USING btree (policy_document_id);


--
-- Name: ix_policy_consents_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policy_consents_user ON "__HCCA_SCHEMA__".policy_consents USING btree (user_id);


--
-- Name: ix_policy_documents_effective_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policy_documents_effective_at ON "__HCCA_SCHEMA__".policy_documents USING btree (effective_at);


--
-- Name: ix_policy_documents_kind_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_policy_documents_kind_active ON "__HCCA_SCHEMA__".policy_documents USING btree (kind, is_active);


--
-- Name: ix_positions_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_positions_category ON "__HCCA_SCHEMA__".positions USING btree (category);


--
-- Name: ix_positions_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_positions_org_id ON "__HCCA_SCHEMA__".positions USING btree (org_id);


--
-- Name: ix_positions_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_positions_parent_id ON "__HCCA_SCHEMA__".positions USING btree (parent_id);


--
-- Name: ix_positions_weight; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_positions_weight ON "__HCCA_SCHEMA__".positions USING btree (weight);


--
-- Name: ix_privacy_requests_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_privacy_requests_type_status ON "__HCCA_SCHEMA__".privacy_requests USING btree (request_type, status);


--
-- Name: ix_privacy_requests_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_privacy_requests_user_status ON "__HCCA_SCHEMA__".privacy_requests USING btree (user_id, status);


--
-- Name: ix_product_categories_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_categories_activity_id ON "__HCCA_SCHEMA__".product_categories USING btree (activity_id);


--
-- Name: ix_product_categories_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_categories_created_by ON "__HCCA_SCHEMA__".product_categories USING btree (created_by);


--
-- Name: ix_product_categories_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_categories_is_active ON "__HCCA_SCHEMA__".product_categories USING btree (is_active);


--
-- Name: ix_product_media_product_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_media_product_sort ON "__HCCA_SCHEMA__".product_media USING btree (product_id, sort_order);


--
-- Name: ix_product_series_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_series_category_id ON "__HCCA_SCHEMA__".product_series USING btree (category_id);


--
-- Name: ix_product_series_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_series_is_active ON "__HCCA_SCHEMA__".product_series USING btree (is_active);


--
-- Name: ix_product_variant_groups_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_variant_groups_product_id ON "__HCCA_SCHEMA__".product_variant_groups USING btree (product_id);


--
-- Name: ix_product_variant_options_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_product_variant_options_group_id ON "__HCCA_SCHEMA__".product_variant_options USING btree (group_id);


--
-- Name: ix_products_category_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_category_status_created ON "__HCCA_SCHEMA__".products USING btree (category_id, status, created_at DESC);


--
-- Name: ix_products_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_created_by ON "__HCCA_SCHEMA__".products USING btree (created_by);


--
-- Name: ix_products_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_name ON "__HCCA_SCHEMA__".products USING btree (name);


--
-- Name: ix_products_series_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_series_id ON "__HCCA_SCHEMA__".products USING btree (series_id);


--
-- Name: ix_products_series_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_series_status_created ON "__HCCA_SCHEMA__".products USING btree (series_id, status, created_at DESC);


--
-- Name: ix_products_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_products_status ON "__HCCA_SCHEMA__".products USING btree (status);


--
-- Name: ix_programs_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_programs_is_active ON "__HCCA_SCHEMA__".programs USING btree (is_active);


--
-- Name: ix_programs_matter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_programs_matter_id ON "__HCCA_SCHEMA__".programs USING btree (matter_id);


--
-- Name: ix_programs_matter_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_programs_matter_status ON "__HCCA_SCHEMA__".programs USING btree (matter_id, status);


--
-- Name: ix_programs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_programs_status ON "__HCCA_SCHEMA__".programs USING btree (status);


--
-- Name: ix_public_link_categories_active_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_link_categories_active_sort ON "__HCCA_SCHEMA__".public_link_categories USING btree (is_active, sort_order);


--
-- Name: ix_public_link_categories_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_link_categories_is_active ON "__HCCA_SCHEMA__".public_link_categories USING btree (is_active);


--
-- Name: ix_public_link_categories_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_link_categories_sort_order ON "__HCCA_SCHEMA__".public_link_categories USING btree (sort_order);


--
-- Name: ix_public_links_active_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_links_active_sort ON "__HCCA_SCHEMA__".public_links USING btree (is_active, sort_order);


--
-- Name: ix_public_links_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_links_category_id ON "__HCCA_SCHEMA__".public_links USING btree (category_id);


--
-- Name: ix_public_links_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_links_is_active ON "__HCCA_SCHEMA__".public_links USING btree (is_active);


--
-- Name: ix_public_links_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_links_sort_order ON "__HCCA_SCHEMA__".public_links USING btree (sort_order);


--
-- Name: ix_public_officer_profiles_is_featured; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_officer_profiles_is_featured ON "__HCCA_SCHEMA__".public_officer_profiles USING btree (is_featured);


--
-- Name: ix_public_officer_profiles_is_visible; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_officer_profiles_is_visible ON "__HCCA_SCHEMA__".public_officer_profiles USING btree (is_visible);


--
-- Name: ix_public_officer_profiles_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_officer_profiles_sort_order ON "__HCCA_SCHEMA__".public_officer_profiles USING btree (sort_order);


--
-- Name: ix_public_officer_profiles_user_position_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_officer_profiles_user_position_id ON "__HCCA_SCHEMA__".public_officer_profiles USING btree (user_position_id);


--
-- Name: ix_public_officer_profiles_visible_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_officer_profiles_visible_sort ON "__HCCA_SCHEMA__".public_officer_profiles USING btree (is_visible, sort_order);


--
-- Name: ix_public_site_page_views_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_site_page_views_created_at ON "__HCCA_SCHEMA__".public_site_page_views USING btree (created_at);


--
-- Name: ix_public_site_page_views_page_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_site_page_views_page_created_at ON "__HCCA_SCHEMA__".public_site_page_views USING btree (page_id, created_at);


--
-- Name: ix_public_site_page_views_visitor_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_site_page_views_visitor_created_at ON "__HCCA_SCHEMA__".public_site_page_views USING btree (visitor_hash, created_at);


--
-- Name: ix_public_site_pages_is_published; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_site_pages_is_published ON "__HCCA_SCHEMA__".public_site_pages USING btree (is_published);


--
-- Name: ix_public_site_pages_nav; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_site_pages_nav ON "__HCCA_SCHEMA__".public_site_pages USING btree (show_in_nav, nav_order);


--
-- Name: ix_public_site_pages_nav_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_site_pages_nav_order ON "__HCCA_SCHEMA__".public_site_pages USING btree (nav_order);


--
-- Name: ix_public_site_pages_page_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_site_pages_page_kind ON "__HCCA_SCHEMA__".public_site_pages USING btree (page_kind);


--
-- Name: ix_public_site_pages_published_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_site_pages_published_sort ON "__HCCA_SCHEMA__".public_site_pages USING btree (is_published, sort_order);


--
-- Name: ix_public_site_pages_show_in_nav; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_site_pages_show_in_nav ON "__HCCA_SCHEMA__".public_site_pages USING btree (show_in_nav);


--
-- Name: ix_public_site_pages_sort_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_public_site_pages_sort_order ON "__HCCA_SCHEMA__".public_site_pages USING btree (sort_order);


--
-- Name: ix_publication_campaigns_activity_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_publication_campaigns_activity_status ON "__HCCA_SCHEMA__".publication_campaigns USING btree (activity_id, status);


--
-- Name: ix_publication_campaigns_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_publication_campaigns_created_by_id ON "__HCCA_SCHEMA__".publication_campaigns USING btree (created_by_id);


--
-- Name: ix_publication_campaigns_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_publication_campaigns_source ON "__HCCA_SCHEMA__".publication_campaigns USING btree (source_type, source_id);


--
-- Name: ix_publication_campaigns_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_publication_campaigns_status ON "__HCCA_SCHEMA__".publication_campaigns USING btree (status);


--
-- Name: ix_publication_deliveries_campaign_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_publication_deliveries_campaign_channel ON "__HCCA_SCHEMA__".publication_deliveries USING btree (campaign_id, channel);


--
-- Name: ix_publication_deliveries_recipient_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_publication_deliveries_recipient_user_id ON "__HCCA_SCHEMA__".publication_deliveries USING btree (recipient_user_id);


--
-- Name: ix_publication_deliveries_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_publication_deliveries_status ON "__HCCA_SCHEMA__".publication_deliveries USING btree (status);


--
-- Name: ix_raffle_draws_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_raffle_draws_event_id ON "__HCCA_SCHEMA__".raffle_draws USING btree (event_id);


--
-- Name: ix_raffle_draws_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_raffle_draws_session_id ON "__HCCA_SCHEMA__".raffle_draws USING btree (session_id);


--
-- Name: ix_raffle_events_event_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_raffle_events_event_code ON "__HCCA_SCHEMA__".raffle_events USING btree (event_code);


--
-- Name: ix_raffle_events_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_raffle_events_status ON "__HCCA_SCHEMA__".raffle_events USING btree (status);


--
-- Name: ix_raffle_prizes_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_raffle_prizes_event_id ON "__HCCA_SCHEMA__".raffle_prizes USING btree (event_id);


--
-- Name: ix_raffle_prizes_event_tier; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_raffle_prizes_event_tier ON "__HCCA_SCHEMA__".raffle_prizes USING btree (event_id, tier);


--
-- Name: ix_raffle_sessions_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_raffle_sessions_event_id ON "__HCCA_SCHEMA__".raffle_sessions USING btree (event_id);


--
-- Name: ix_receivables_activity_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_receivables_activity_status ON "__HCCA_SCHEMA__".receivables USING btree (activity_id, status);


--
-- Name: ix_receivables_class_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_receivables_class_status ON "__HCCA_SCHEMA__".receivables USING btree (class_id, status);


--
-- Name: ix_receivables_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_receivables_org_id ON "__HCCA_SCHEMA__".receivables USING btree (org_id);


--
-- Name: ix_receivables_source_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_receivables_source_type ON "__HCCA_SCHEMA__".receivables USING btree (source_type);


--
-- Name: ix_receivables_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_receivables_status ON "__HCCA_SCHEMA__".receivables USING btree (status);


--
-- Name: ix_receivables_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_receivables_user_status ON "__HCCA_SCHEMA__".receivables USING btree (user_id, status);


--
-- Name: ix_recommended_vendor_categories_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendor_categories_is_active ON "__HCCA_SCHEMA__".recommended_vendor_categories USING btree (is_active);


--
-- Name: ix_recommended_vendor_categories_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendor_categories_name ON "__HCCA_SCHEMA__".recommended_vendor_categories USING btree (name);


--
-- Name: ix_recommended_vendor_menus_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendor_menus_is_active ON "__HCCA_SCHEMA__".recommended_vendor_menus USING btree (is_active);


--
-- Name: ix_recommended_vendor_menus_vendor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendor_menus_vendor_id ON "__HCCA_SCHEMA__".recommended_vendor_menus USING btree (vendor_id);


--
-- Name: ix_recommended_vendor_products_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendor_products_is_active ON "__HCCA_SCHEMA__".recommended_vendor_products USING btree (is_active);


--
-- Name: ix_recommended_vendor_products_vendor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendor_products_vendor_id ON "__HCCA_SCHEMA__".recommended_vendor_products USING btree (vendor_id);


--
-- Name: ix_recommended_vendors_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendors_category ON "__HCCA_SCHEMA__".recommended_vendors USING btree (category);


--
-- Name: ix_recommended_vendors_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendors_category_id ON "__HCCA_SCHEMA__".recommended_vendors USING btree (category_id);


--
-- Name: ix_recommended_vendors_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendors_is_active ON "__HCCA_SCHEMA__".recommended_vendors USING btree (is_active);


--
-- Name: ix_recommended_vendors_latitude; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendors_latitude ON "__HCCA_SCHEMA__".recommended_vendors USING btree (latitude);


--
-- Name: ix_recommended_vendors_longitude; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendors_longitude ON "__HCCA_SCHEMA__".recommended_vendors USING btree (longitude);


--
-- Name: ix_recommended_vendors_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendors_name ON "__HCCA_SCHEMA__".recommended_vendors USING btree (name);


--
-- Name: ix_recommended_vendors_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_recommended_vendors_status ON "__HCCA_SCHEMA__".recommended_vendors USING btree (status);


--
-- Name: ix_regulation_articles_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulation_articles_parent_id ON "__HCCA_SCHEMA__".regulation_articles USING btree (parent_id);


--
-- Name: ix_regulation_articles_regulation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulation_articles_regulation_id ON "__HCCA_SCHEMA__".regulation_articles USING btree (regulation_id);


--
-- Name: ix_regulation_revisions_regulation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulation_revisions_regulation_id ON "__HCCA_SCHEMA__".regulation_revisions USING btree (regulation_id);


--
-- Name: ix_regulation_workflow_logs_regulation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulation_workflow_logs_regulation_id ON "__HCCA_SCHEMA__".regulation_workflow_logs USING btree (regulation_id);


--
-- Name: ix_regulations_active_published_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_active_published_updated ON "__HCCA_SCHEMA__".regulations USING btree (updated_at DESC) WHERE ((is_active = true) AND (published_at IS NOT NULL));


--
-- Name: ix_regulations_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_category ON "__HCCA_SCHEMA__".regulations USING btree (category);


--
-- Name: ix_regulations_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_created_by ON "__HCCA_SCHEMA__".regulations USING btree (created_by);


--
-- Name: ix_regulations_freeze_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_freeze_document_id ON "__HCCA_SCHEMA__".regulations USING btree (freeze_document_id);


--
-- Name: ix_regulations_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_is_active ON "__HCCA_SCHEMA__".regulations USING btree (is_active);


--
-- Name: ix_regulations_is_active_workflow; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_is_active_workflow ON "__HCCA_SCHEMA__".regulations USING btree (is_active, workflow_status);


--
-- Name: ix_regulations_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_org_id ON "__HCCA_SCHEMA__".regulations USING btree (org_id);


--
-- Name: ix_regulations_published_document_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_published_document_id ON "__HCCA_SCHEMA__".regulations USING btree (published_document_id);


--
-- Name: ix_regulations_repeal_replacement_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_repeal_replacement_id ON "__HCCA_SCHEMA__".regulations USING btree (repeal_replacement_id);


--
-- Name: ix_regulations_search_vector; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_search_vector ON "__HCCA_SCHEMA__".regulations USING gin (search_vector);


--
-- Name: ix_regulations_source_regulation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_source_regulation_id ON "__HCCA_SCHEMA__".regulations USING btree (source_regulation_id);


--
-- Name: ix_regulations_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_title ON "__HCCA_SCHEMA__".regulations USING btree (title);


--
-- Name: ix_regulations_workflow_pub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_regulations_workflow_pub ON "__HCCA_SCHEMA__".regulations USING btree (workflow_status, updated_at DESC) WHERE (workflow_status = ANY (ARRAY['under_review'::"__HCCA_SCHEMA__".regulationworkflowstatus, 'scheduled'::"__HCCA_SCHEMA__".regulationworkflowstatus, 'council_approved'::"__HCCA_SCHEMA__".regulationworkflowstatus]));


--
-- Name: ix_saved_filters_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_saved_filters_scope ON "__HCCA_SCHEMA__".saved_filters USING btree (scope);


--
-- Name: ix_saved_filters_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_saved_filters_user_id ON "__HCCA_SCHEMA__".saved_filters USING btree (user_id);


--
-- Name: ix_school_classes_academic_year; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_school_classes_academic_year ON "__HCCA_SCHEMA__".school_classes USING btree (academic_year);


--
-- Name: ix_school_classes_grade; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_school_classes_grade ON "__HCCA_SCHEMA__".school_classes USING btree (grade);


--
-- Name: ix_school_classes_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_school_classes_is_active ON "__HCCA_SCHEMA__".school_classes USING btree (is_active);


--
-- Name: ix_school_classes_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_school_classes_org_id ON "__HCCA_SCHEMA__".school_classes USING btree (org_id);


--
-- Name: ix_seat_assignments_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seat_assignments_order ON "__HCCA_SCHEMA__".seat_assignments USING btree (order_id);


--
-- Name: ix_seat_assignments_order_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seat_assignments_order_item_id ON "__HCCA_SCHEMA__".seat_assignments USING btree (order_item_id);


--
-- Name: ix_seat_assignments_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seat_assignments_user_id ON "__HCCA_SCHEMA__".seat_assignments USING btree (user_id);


--
-- Name: ix_seat_assignments_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seat_assignments_zone_id ON "__HCCA_SCHEMA__".seat_assignments USING btree (zone_id);


--
-- Name: ix_seat_assignments_zone_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seat_assignments_zone_status ON "__HCCA_SCHEMA__".seat_assignments USING btree (zone_id, status);


--
-- Name: ix_seat_holds_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seat_holds_expires ON "__HCCA_SCHEMA__".seat_holds USING btree (expires_at);


--
-- Name: ix_seat_holds_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seat_holds_user_id ON "__HCCA_SCHEMA__".seat_holds USING btree (user_id);


--
-- Name: ix_seat_holds_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seat_holds_zone_id ON "__HCCA_SCHEMA__".seat_holds USING btree (zone_id);


--
-- Name: ix_seating_waves_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seating_waves_zone_id ON "__HCCA_SCHEMA__".seating_waves USING btree (zone_id);


--
-- Name: ix_seating_waves_zone_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seating_waves_zone_sort ON "__HCCA_SCHEMA__".seating_waves USING btree (zone_id, sort_order);


--
-- Name: ix_seating_zones_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seating_zones_product_id ON "__HCCA_SCHEMA__".seating_zones USING btree (product_id);


--
-- Name: ix_seating_zones_product_sort; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seating_zones_product_sort ON "__HCCA_SCHEMA__".seating_zones USING btree (product_id, sort_order);


--
-- Name: ix_seats_zone_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seats_zone_id ON "__HCCA_SCHEMA__".seats USING btree (zone_id);


--
-- Name: ix_seats_zone_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_seats_zone_status ON "__HCCA_SCHEMA__".seats USING btree (zone_id, status);


--
-- Name: ix_shop_class_collections_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_class_collections_order_id ON "__HCCA_SCHEMA__".shop_class_collections USING btree (order_id);


--
-- Name: ix_shop_delegation_links_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_delegation_links_user_id ON "__HCCA_SCHEMA__".shop_delegation_links USING btree (user_id);


--
-- Name: ix_shop_order_closes_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_order_closes_category_id ON "__HCCA_SCHEMA__".shop_order_closes USING btree (category_id);


--
-- Name: ix_shop_order_closes_class_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_order_closes_class_id ON "__HCCA_SCHEMA__".shop_order_closes USING btree (class_id);


--
-- Name: ix_shop_order_closes_closed_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_order_closes_closed_by_id ON "__HCCA_SCHEMA__".shop_order_closes USING btree (closed_by_id);


--
-- Name: ix_shop_order_closes_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_order_closes_is_active ON "__HCCA_SCHEMA__".shop_order_closes USING btree (is_active);


--
-- Name: ix_shop_order_closes_reopened_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_order_closes_reopened_by_id ON "__HCCA_SCHEMA__".shop_order_closes USING btree (reopened_by_id);


--
-- Name: ix_shop_order_promotions_promotion_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_order_promotions_promotion_id ON "__HCCA_SCHEMA__".shop_order_promotions USING btree (promotion_id);


--
-- Name: ix_shop_promotion_product_prices_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_promotion_product_prices_product_id ON "__HCCA_SCHEMA__".shop_promotion_product_prices USING btree (product_id);


--
-- Name: ix_shop_promotion_products_product_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_promotion_products_product_id ON "__HCCA_SCHEMA__".shop_promotion_products USING btree (product_id);


--
-- Name: ix_shop_promotion_student_targets_student_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_promotion_student_targets_student_id ON "__HCCA_SCHEMA__".shop_promotion_student_targets USING btree (student_id);


--
-- Name: ix_shop_promotion_users_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_promotion_users_user_id ON "__HCCA_SCHEMA__".shop_promotion_users USING btree (user_id);


--
-- Name: ix_shop_promotions_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_promotions_activity_id ON "__HCCA_SCHEMA__".shop_promotions USING btree (activity_id);


--
-- Name: ix_shop_promotions_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_shop_promotions_code ON "__HCCA_SCHEMA__".shop_promotions USING btree (code);


--
-- Name: ix_shop_promotions_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_promotions_created_by ON "__HCCA_SCHEMA__".shop_promotions USING btree (created_by);


--
-- Name: ix_shop_promotions_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_promotions_is_active ON "__HCCA_SCHEMA__".shop_promotions USING btree (is_active);


--
-- Name: ix_shop_promotions_target_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_promotions_target_user_id ON "__HCCA_SCHEMA__".shop_promotions USING btree (target_user_id);


--
-- Name: ix_shop_sheet_rows_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_shop_sheet_rows_source_id ON "__HCCA_SCHEMA__".shop_sheet_rows USING btree (source_id);


--
-- Name: ix_support_approvals_approval_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_approvals_approval_number ON "__HCCA_SCHEMA__".support_approvals USING btree (approval_number);


--
-- Name: ix_support_approvals_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_approvals_status ON "__HCCA_SCHEMA__".support_approvals USING btree (status);


--
-- Name: ix_support_approvals_status_requested; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_approvals_status_requested ON "__HCCA_SCHEMA__".support_approvals USING btree (status, requested_at);


--
-- Name: ix_support_assistance_assistance_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_assistance_assistance_code ON "__HCCA_SCHEMA__".support_assistance_sessions USING btree (assistance_code);


--
-- Name: ix_support_assistance_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_assistance_status ON "__HCCA_SCHEMA__".support_assistance_sessions USING btree (status);


--
-- Name: ix_support_assistance_target_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_assistance_target_status ON "__HCCA_SCHEMA__".support_assistance_sessions USING btree (user_id, status);


--
-- Name: ix_support_audit_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_audit_action ON "__HCCA_SCHEMA__".support_audit_logs USING btree (action);


--
-- Name: ix_support_audit_actor_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_audit_actor_created ON "__HCCA_SCHEMA__".support_audit_logs USING btree (actor_user_id, created_at);


--
-- Name: ix_support_audit_target_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_audit_target_created ON "__HCCA_SCHEMA__".support_audit_logs USING btree (target_user_id, created_at);


--
-- Name: ix_support_audit_ticket_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_audit_ticket_created ON "__HCCA_SCHEMA__".support_audit_logs USING btree (ticket_id, created_at);


--
-- Name: ix_support_guide_entries_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_guide_entries_is_active ON "__HCCA_SCHEMA__".support_guide_entries USING btree (is_active);


--
-- Name: ix_support_guide_entries_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_guide_entries_slug ON "__HCCA_SCHEMA__".support_guide_entries USING btree (slug);


--
-- Name: ix_support_impersonation_target_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_impersonation_target_expires ON "__HCCA_SCHEMA__".support_impersonation_sessions USING btree (impersonated_user_id, expires_at);


--
-- Name: ix_support_impersonation_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_impersonation_token_hash ON "__HCCA_SCHEMA__".support_impersonation_sessions USING btree (token_hash);


--
-- Name: ix_support_ticket_events_ticket_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_ticket_events_ticket_created ON "__HCCA_SCHEMA__".support_ticket_events USING btree (ticket_id, created_at);


--
-- Name: ix_support_tickets_assigned_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_tickets_assigned_to_id ON "__HCCA_SCHEMA__".support_tickets USING btree (assigned_to_id);


--
-- Name: ix_support_tickets_error_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_tickets_error_code ON "__HCCA_SCHEMA__".support_tickets USING btree (error_code);


--
-- Name: ix_support_tickets_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_tickets_priority ON "__HCCA_SCHEMA__".support_tickets USING btree (priority);


--
-- Name: ix_support_tickets_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_tickets_request_id ON "__HCCA_SCHEMA__".support_tickets USING btree (request_id);


--
-- Name: ix_support_tickets_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_tickets_status ON "__HCCA_SCHEMA__".support_tickets USING btree (status);


--
-- Name: ix_support_tickets_status_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_tickets_status_priority ON "__HCCA_SCHEMA__".support_tickets USING btree (status, priority);


--
-- Name: ix_support_tickets_ticket_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_tickets_ticket_number ON "__HCCA_SCHEMA__".support_tickets USING btree (ticket_number);


--
-- Name: ix_support_tickets_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_tickets_user_id ON "__HCCA_SCHEMA__".support_tickets USING btree (user_id);


--
-- Name: ix_support_tickets_user_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_support_tickets_user_status ON "__HCCA_SCHEMA__".support_tickets USING btree (user_id, status);


--
-- Name: ix_survey_answers_question_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_survey_answers_question_id ON "__HCCA_SCHEMA__".survey_answers USING btree (question_id);


--
-- Name: ix_survey_answers_response_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_survey_answers_response_id ON "__HCCA_SCHEMA__".survey_answers USING btree (response_id);


--
-- Name: ix_survey_questions_survey_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_survey_questions_survey_id ON "__HCCA_SCHEMA__".survey_questions USING btree (survey_id);


--
-- Name: ix_survey_responses_anon_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_survey_responses_anon_token ON "__HCCA_SCHEMA__".survey_responses USING btree (anon_token);


--
-- Name: ix_survey_responses_respondent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_survey_responses_respondent_id ON "__HCCA_SCHEMA__".survey_responses USING btree (respondent_id);


--
-- Name: ix_survey_responses_survey_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_survey_responses_survey_id ON "__HCCA_SCHEMA__".survey_responses USING btree (survey_id);


--
-- Name: ix_surveys_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_surveys_activity_id ON "__HCCA_SCHEMA__".surveys USING btree (activity_id);


--
-- Name: ix_surveys_created_at_desc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_surveys_created_at_desc ON "__HCCA_SCHEMA__".surveys USING btree (created_at DESC);


--
-- Name: ix_surveys_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_surveys_created_by ON "__HCCA_SCHEMA__".surveys USING btree (created_by);


--
-- Name: ix_surveys_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_surveys_open ON "__HCCA_SCHEMA__".surveys USING btree (status, updated_at DESC) WHERE (status = 'open'::"__HCCA_SCHEMA__".surveystatus);


--
-- Name: ix_surveys_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_surveys_org_id ON "__HCCA_SCHEMA__".surveys USING btree (org_id);


--
-- Name: ix_surveys_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_surveys_status ON "__HCCA_SCHEMA__".surveys USING btree (status);


--
-- Name: ix_surveys_status_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_surveys_status_updated_at ON "__HCCA_SCHEMA__".surveys USING btree (status, updated_at DESC);


--
-- Name: ix_surveys_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_surveys_title ON "__HCCA_SCHEMA__".surveys USING btree (title);


--
-- Name: ix_system_incident_events_incident_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_system_incident_events_incident_created ON "__HCCA_SCHEMA__".system_incident_events USING btree (incident_id, created_at);


--
-- Name: ix_system_incidents_fingerprint_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_system_incidents_fingerprint_status ON "__HCCA_SCHEMA__".system_incidents USING btree (fingerprint, status);


--
-- Name: ix_system_incidents_service_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_system_incidents_service_last_seen ON "__HCCA_SCHEMA__".system_incidents USING btree (service, last_seen_at);


--
-- Name: ix_timeline_events_case_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timeline_events_case_created ON "__HCCA_SCHEMA__".timeline_events USING btree (case_id, created_at);


--
-- Name: ix_timeline_events_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timeline_events_case_id ON "__HCCA_SCHEMA__".timeline_events USING btree (case_id);


--
-- Name: ix_timeline_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timeline_events_event_type ON "__HCCA_SCHEMA__".timeline_events USING btree (event_type);


--
-- Name: ix_timeline_events_matter_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timeline_events_matter_created ON "__HCCA_SCHEMA__".timeline_events USING btree (matter_id, created_at);


--
-- Name: ix_timeline_events_matter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_timeline_events_matter_id ON "__HCCA_SCHEMA__".timeline_events USING btree (matter_id);


--
-- Name: ix_user_google_tasks_configs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_google_tasks_configs_user_id ON "__HCCA_SCHEMA__".user_google_tasks_configs USING btree (user_id);


--
-- Name: ix_user_identities_provider_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_identities_provider_email ON "__HCCA_SCHEMA__".user_identities USING btree (provider, email);


--
-- Name: ix_user_identities_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_identities_user ON "__HCCA_SCHEMA__".user_identities USING btree (user_id);


--
-- Name: ix_user_identities_user_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_identities_user_email ON "__HCCA_SCHEMA__".user_identities USING btree (user_id, email) WHERE (email IS NOT NULL);


--
-- Name: ix_user_positions_position_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_positions_position_id ON "__HCCA_SCHEMA__".user_positions USING btree (position_id);


--
-- Name: ix_user_positions_user_end_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_positions_user_end_date ON "__HCCA_SCHEMA__".user_positions USING btree (user_id, end_date);


--
-- Name: ix_user_positions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_positions_user_id ON "__HCCA_SCHEMA__".user_positions USING btree (user_id);


--
-- Name: ix_user_positions_user_tenure_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_positions_user_tenure_position ON "__HCCA_SCHEMA__".user_positions USING btree (user_id, start_date, end_date, position_id);


--
-- Name: ix_user_sessions_refresh_jti; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_user_sessions_refresh_jti ON "__HCCA_SCHEMA__".user_sessions USING btree (refresh_jti_hash);


--
-- Name: ix_user_sessions_user_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_sessions_user_active ON "__HCCA_SCHEMA__".user_sessions USING btree (user_id, revoked_at, expires_at);


--
-- Name: ix_user_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_sessions_user_id ON "__HCCA_SCHEMA__".user_sessions USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON "__HCCA_SCHEMA__".users USING btree (email);


--
-- Name: ix_users_student_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_student_id ON "__HCCA_SCHEMA__".users USING btree (student_id);


--
-- Name: ix_vote_events_ballot_box_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vote_events_ballot_box_id ON "__HCCA_SCHEMA__".vote_events USING btree (ballot_box_id);


--
-- Name: ix_vote_events_box_candidate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vote_events_box_candidate ON "__HCCA_SCHEMA__".vote_events USING btree (ballot_box_id, candidate_id);


--
-- Name: ix_vote_events_candidate_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vote_events_candidate_id ON "__HCCA_SCHEMA__".vote_events USING btree (candidate_id);


--
-- Name: ix_vote_events_election_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vote_events_election_created ON "__HCCA_SCHEMA__".vote_events USING btree (election_id, created_at);


--
-- Name: ix_vote_events_election_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vote_events_election_id ON "__HCCA_SCHEMA__".vote_events USING btree (election_id);


--
-- Name: ix_vote_events_operator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_vote_events_operator_id ON "__HCCA_SCHEMA__".vote_events USING btree (operator_id);


--
-- Name: ix_web_push_subscriptions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_web_push_subscriptions_user_id ON "__HCCA_SCHEMA__".web_push_subscriptions USING btree (user_id);


--
-- Name: ix_webhook_deliveries_scheduled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_deliveries_scheduled ON "__HCCA_SCHEMA__".webhook_deliveries USING btree (scheduled_at);


--
-- Name: ix_webhook_deliveries_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_deliveries_status ON "__HCCA_SCHEMA__".webhook_deliveries USING btree (status);


--
-- Name: ix_webhook_deliveries_sub; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_deliveries_sub ON "__HCCA_SCHEMA__".webhook_deliveries USING btree (subscription_id);


--
-- Name: ix_webhook_subs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_subs_active ON "__HCCA_SCHEMA__".webhook_subscriptions USING btree (is_active);


--
-- Name: ix_webhook_subs_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_webhook_subs_owner ON "__HCCA_SCHEMA__".webhook_subscriptions USING btree (owner_user_id);


--
-- Name: ix_work_items_assigned_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_items_assigned_open ON "__HCCA_SCHEMA__".work_items USING btree (assigned_to_id, status, is_active) WHERE (((status)::text = 'open'::text) AND (is_active = true));


--
-- Name: ix_work_items_assigned_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_items_assigned_to_id ON "__HCCA_SCHEMA__".work_items USING btree (assigned_to_id);


--
-- Name: ix_work_items_assignee_open_active_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_items_assignee_open_active_due ON "__HCCA_SCHEMA__".work_items USING btree (assigned_to_id, status, is_active, due_at);


--
-- Name: ix_work_items_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_items_created_by_id ON "__HCCA_SCHEMA__".work_items USING btree (created_by_id);


--
-- Name: ix_work_items_due_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_items_due_at ON "__HCCA_SCHEMA__".work_items USING btree (due_at);


--
-- Name: ix_work_items_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_items_is_active ON "__HCCA_SCHEMA__".work_items USING btree (is_active);


--
-- Name: ix_work_items_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_items_source_id ON "__HCCA_SCHEMA__".work_items USING btree (source_id);


--
-- Name: ix_work_items_source_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_items_source_type ON "__HCCA_SCHEMA__".work_items USING btree (source_type);


--
-- Name: ix_work_items_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_items_status ON "__HCCA_SCHEMA__".work_items USING btree (status);


--
-- Name: ix_work_items_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_work_items_title ON "__HCCA_SCHEMA__".work_items USING btree (title);


--
-- Name: ix_workflow_events_actor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_events_actor_id ON "__HCCA_SCHEMA__".workflow_events USING btree (actor_id);


--
-- Name: ix_workflow_events_event_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_events_event_type ON "__HCCA_SCHEMA__".workflow_events USING btree (event_type);


--
-- Name: ix_workflow_events_instance_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_events_instance_created ON "__HCCA_SCHEMA__".workflow_events USING btree (instance_id, created_at);


--
-- Name: ix_workflow_events_instance_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_events_instance_id ON "__HCCA_SCHEMA__".workflow_events USING btree (instance_id);


--
-- Name: ix_workflow_events_instance_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_events_instance_type ON "__HCCA_SCHEMA__".workflow_events USING btree (instance_id, event_type);


--
-- Name: ix_workflow_instances_activity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_activity ON "__HCCA_SCHEMA__".workflow_instances USING btree (activity_id);


--
-- Name: ix_workflow_instances_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_activity_id ON "__HCCA_SCHEMA__".workflow_instances USING btree (activity_id);


--
-- Name: ix_workflow_instances_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_created_by_id ON "__HCCA_SCHEMA__".workflow_instances USING btree (created_by_id);


--
-- Name: ix_workflow_instances_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_is_active ON "__HCCA_SCHEMA__".workflow_instances USING btree (is_active);


--
-- Name: ix_workflow_instances_org_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_org_id ON "__HCCA_SCHEMA__".workflow_instances USING btree (org_id);


--
-- Name: ix_workflow_instances_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_source ON "__HCCA_SCHEMA__".workflow_instances USING btree (source_type, source_id);


--
-- Name: ix_workflow_instances_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_source_id ON "__HCCA_SCHEMA__".workflow_instances USING btree (source_id);


--
-- Name: ix_workflow_instances_source_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_source_type ON "__HCCA_SCHEMA__".workflow_instances USING btree (source_type);


--
-- Name: ix_workflow_instances_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_status ON "__HCCA_SCHEMA__".workflow_instances USING btree (status);


--
-- Name: ix_workflow_instances_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_type_status ON "__HCCA_SCHEMA__".workflow_instances USING btree (workflow_type, status);


--
-- Name: ix_workflow_instances_workflow_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_instances_workflow_type ON "__HCCA_SCHEMA__".workflow_instances USING btree (workflow_type);


--
-- Name: ix_workflow_links_created_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_links_created_by_id ON "__HCCA_SCHEMA__".workflow_links USING btree (created_by_id);


--
-- Name: ix_workflow_links_instance_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_links_instance_id ON "__HCCA_SCHEMA__".workflow_links USING btree (instance_id);


--
-- Name: ix_workflow_links_instance_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_links_instance_type ON "__HCCA_SCHEMA__".workflow_links USING btree (instance_id, target_type);


--
-- Name: ix_workflow_links_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_links_target ON "__HCCA_SCHEMA__".workflow_links USING btree (target_type, target_id);


--
-- Name: ix_workflow_links_target_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_workflow_links_target_type ON "__HCCA_SCHEMA__".workflow_links USING btree (target_type);


--
-- Name: uq_class_correction_pending_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_class_correction_pending_user ON "__HCCA_SCHEMA__".class_correction_requests USING btree (user_id) WHERE ((status)::text = 'pending'::text);


--
-- Name: uq_policy_documents_one_active_per_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_policy_documents_one_active_per_kind ON "__HCCA_SCHEMA__".policy_documents USING btree (kind) WHERE (is_active IS TRUE);


--
-- Name: uq_seat_assignment_active_seat; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_seat_assignment_active_seat ON "__HCCA_SCHEMA__".seat_assignments USING btree (seat_id) WHERE (status = 'active'::"__HCCA_SCHEMA__".seatassignmentstatus);


--
-- Name: uq_shop_class_payments_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_shop_class_payments_scope ON "__HCCA_SCHEMA__".shop_class_payments USING btree (class_id, activity_id) NULLS NOT DISTINCT;


--
-- Name: regulations regulations_search_vector_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER regulations_search_vector_trigger BEFORE INSERT OR UPDATE ON "__HCCA_SCHEMA__".regulations FOR EACH ROW EXECUTE FUNCTION "__HCCA_SCHEMA__".regulations_search_vector_update();


--
-- Name: activities activities_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activities
    ADD CONSTRAINT activities_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: activity_conveners activity_conveners_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_conveners
    ADD CONSTRAINT activity_conveners_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE CASCADE;


--
-- Name: activity_conveners activity_conveners_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_conveners
    ADD CONSTRAINT activity_conveners_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: activity_links activity_links_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_links
    ADD CONSTRAINT activity_links_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE CASCADE;


--
-- Name: activity_links activity_links_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_links
    ADD CONSTRAINT activity_links_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: activity_members activity_members_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_members
    ADD CONSTRAINT activity_members_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE CASCADE;


--
-- Name: activity_members activity_members_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_members
    ADD CONSTRAINT activity_members_role_id_fkey FOREIGN KEY (role_id) REFERENCES "__HCCA_SCHEMA__".activity_roles(id) ON DELETE CASCADE;


--
-- Name: activity_members activity_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_members
    ADD CONSTRAINT activity_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: activity_roles activity_roles_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".activity_roles
    ADD CONSTRAINT activity_roles_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE CASCADE;


--
-- Name: analytics_page_views analytics_page_views_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".analytics_page_views
    ADD CONSTRAINT analytics_page_views_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: announcement_audience_orgs announcement_audience_orgs_announcement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_audience_orgs
    ADD CONSTRAINT announcement_audience_orgs_announcement_id_fkey FOREIGN KEY (announcement_id) REFERENCES "__HCCA_SCHEMA__".announcements(id) ON DELETE CASCADE;


--
-- Name: announcement_audience_orgs announcement_audience_orgs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_audience_orgs
    ADD CONSTRAINT announcement_audience_orgs_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: announcement_audience_users announcement_audience_users_announcement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_audience_users
    ADD CONSTRAINT announcement_audience_users_announcement_id_fkey FOREIGN KEY (announcement_id) REFERENCES "__HCCA_SCHEMA__".announcements(id) ON DELETE CASCADE;


--
-- Name: announcement_audience_users announcement_audience_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_audience_users
    ADD CONSTRAINT announcement_audience_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: announcement_media announcement_media_announcement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_media
    ADD CONSTRAINT announcement_media_announcement_id_fkey FOREIGN KEY (announcement_id) REFERENCES "__HCCA_SCHEMA__".announcements(id) ON DELETE CASCADE;


--
-- Name: announcement_reads announcement_reads_announcement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_reads
    ADD CONSTRAINT announcement_reads_announcement_id_fkey FOREIGN KEY (announcement_id) REFERENCES "__HCCA_SCHEMA__".announcements(id) ON DELETE CASCADE;


--
-- Name: announcement_reads announcement_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcement_reads
    ADD CONSTRAINT announcement_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: announcements announcements_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcements
    ADD CONSTRAINT announcements_author_id_fkey FOREIGN KEY (author_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: announcements announcements_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcements
    ADD CONSTRAINT announcements_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: api_keys api_keys_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".api_keys
    ADD CONSTRAINT api_keys_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: audit_log_anchors audit_log_anchors_last_audit_log_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".audit_log_anchors
    ADD CONSTRAINT audit_log_anchors_last_audit_log_id_fkey FOREIGN KEY (last_audit_log_id) REFERENCES "__HCCA_SCHEMA__".audit_logs(id) ON DELETE SET NULL;


--
-- Name: automation_rules automation_rules_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".automation_rules
    ADD CONSTRAINT automation_rules_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: automation_rules automation_rules_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".automation_rules
    ADD CONSTRAINT automation_rules_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES "__HCCA_SCHEMA__".matters(id) ON DELETE CASCADE;


--
-- Name: cart_items cart_items_cart_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".cart_items
    ADD CONSTRAINT cart_items_cart_id_fkey FOREIGN KEY (cart_id) REFERENCES "__HCCA_SCHEMA__".carts(id) ON DELETE CASCADE;


--
-- Name: cart_items cart_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".cart_items
    ADD CONSTRAINT cart_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES "__HCCA_SCHEMA__".products(id) ON DELETE CASCADE;


--
-- Name: carts carts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".carts
    ADD CONSTRAINT carts_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: class_cadres class_cadres_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_cadres
    ADD CONSTRAINT class_cadres_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE CASCADE;


--
-- Name: class_cadres class_cadres_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_cadres
    ADD CONSTRAINT class_cadres_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: class_confirmations class_confirmations_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_confirmations
    ADD CONSTRAINT class_confirmations_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE CASCADE;


--
-- Name: class_confirmations class_confirmations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_confirmations
    ADD CONSTRAINT class_confirmations_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: class_correction_requests class_correction_requests_reported_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_correction_requests
    ADD CONSTRAINT class_correction_requests_reported_class_id_fkey FOREIGN KEY (reported_class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE SET NULL;


--
-- Name: class_correction_requests class_correction_requests_requested_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_correction_requests
    ADD CONSTRAINT class_correction_requests_requested_class_id_fkey FOREIGN KEY (requested_class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE RESTRICT;


--
-- Name: class_correction_requests class_correction_requests_resolved_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_correction_requests
    ADD CONSTRAINT class_correction_requests_resolved_class_id_fkey FOREIGN KEY (resolved_class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE SET NULL;


--
-- Name: class_correction_requests class_correction_requests_reviewed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_correction_requests
    ADD CONSTRAINT class_correction_requests_reviewed_by_id_fkey FOREIGN KEY (reviewed_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: class_correction_requests class_correction_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_correction_requests
    ADD CONSTRAINT class_correction_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: class_manual_members class_manual_members_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_manual_members
    ADD CONSTRAINT class_manual_members_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE CASCADE;


--
-- Name: class_manual_members class_manual_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_manual_members
    ADD CONSTRAINT class_manual_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: class_memberships class_memberships_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_memberships
    ADD CONSTRAINT class_memberships_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE CASCADE;


--
-- Name: class_memberships class_memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_memberships
    ADD CONSTRAINT class_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: class_role_bindings class_role_bindings_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_role_bindings
    ADD CONSTRAINT class_role_bindings_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE CASCADE;


--
-- Name: class_role_bindings class_role_bindings_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_role_bindings
    ADD CONSTRAINT class_role_bindings_position_id_fkey FOREIGN KEY (position_id) REFERENCES "__HCCA_SCHEMA__".positions(id) ON DELETE CASCADE;


--
-- Name: class_roster_entries class_roster_entries_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_roster_entries
    ADD CONSTRAINT class_roster_entries_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE CASCADE;


--
-- Name: class_roster_entries class_roster_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_roster_entries
    ADD CONSTRAINT class_roster_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: class_student_ranges class_student_ranges_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".class_student_ranges
    ADD CONSTRAINT class_student_ranges_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE CASCADE;


--
-- Name: council_proposals council_proposals_submitter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".council_proposals
    ADD CONSTRAINT council_proposals_submitter_id_fkey FOREIGN KEY (submitter_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: decisions decisions_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".decisions
    ADD CONSTRAINT decisions_case_id_fkey FOREIGN KEY (case_id) REFERENCES "__HCCA_SCHEMA__".governance_cases(id) ON DELETE SET NULL;


--
-- Name: decisions decisions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".decisions
    ADD CONSTRAINT decisions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: decisions decisions_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".decisions
    ADD CONSTRAINT decisions_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES "__HCCA_SCHEMA__".matters(id) ON DELETE CASCADE;


--
-- Name: decisions decisions_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".decisions
    ADD CONSTRAINT decisions_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: defense_rules defense_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".defense_rules
    ADD CONSTRAINT defense_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: defense_rules defense_rules_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".defense_rules
    ADD CONSTRAINT defense_rules_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: discord_account_links discord_account_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_account_links
    ADD CONSTRAINT discord_account_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: discord_activity_workspaces discord_activity_workspaces_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_activity_workspaces
    ADD CONSTRAINT discord_activity_workspaces_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE CASCADE;


--
-- Name: discord_member_sync_states discord_member_sync_states_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_member_sync_states
    ADD CONSTRAINT discord_member_sync_states_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: discord_nickname_prefix_rules discord_nickname_prefix_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_nickname_prefix_rules
    ADD CONSTRAINT discord_nickname_prefix_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: discord_nickname_prefix_rules discord_nickname_prefix_rules_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_nickname_prefix_rules
    ADD CONSTRAINT discord_nickname_prefix_rules_position_id_fkey FOREIGN KEY (position_id) REFERENCES "__HCCA_SCHEMA__".positions(id) ON DELETE CASCADE;


--
-- Name: discord_notification_preferences discord_notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_notification_preferences
    ADD CONSTRAINT discord_notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: discord_notification_routes discord_notification_routes_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_notification_routes
    ADD CONSTRAINT discord_notification_routes_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: discord_notification_routes discord_notification_routes_petition_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_notification_routes
    ADD CONSTRAINT discord_notification_routes_petition_type_id_fkey FOREIGN KEY (petition_type_id) REFERENCES "__HCCA_SCHEMA__".petition_types(id) ON DELETE SET NULL;


--
-- Name: discord_org_channel_mappings discord_org_channel_mappings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_org_channel_mappings
    ADD CONSTRAINT discord_org_channel_mappings_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: discord_role_mappings discord_role_mappings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_role_mappings
    ADD CONSTRAINT discord_role_mappings_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: discord_role_mappings discord_role_mappings_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_role_mappings
    ADD CONSTRAINT discord_role_mappings_position_id_fkey FOREIGN KEY (position_id) REFERENCES "__HCCA_SCHEMA__".positions(id) ON DELETE CASCADE;


--
-- Name: discord_role_policies discord_role_policies_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_role_policies
    ADD CONSTRAINT discord_role_policies_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: discord_role_policies discord_role_policies_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".discord_role_policies
    ADD CONSTRAINT discord_role_policies_position_id_fkey FOREIGN KEY (position_id) REFERENCES "__HCCA_SCHEMA__".positions(id) ON DELETE CASCADE;


--
-- Name: document_approval_delegations document_approval_delegations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_approval_delegations
    ADD CONSTRAINT document_approval_delegations_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: document_approval_delegations document_approval_delegations_delegate_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_approval_delegations
    ADD CONSTRAINT document_approval_delegations_delegate_user_id_fkey FOREIGN KEY (delegate_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: document_approval_delegations document_approval_delegations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_approval_delegations
    ADD CONSTRAINT document_approval_delegations_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: document_approval_delegations document_approval_delegations_principal_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_approval_delegations
    ADD CONSTRAINT document_approval_delegations_principal_user_id_fkey FOREIGN KEY (principal_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: document_approvals document_approvals_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_approvals
    ADD CONSTRAINT document_approvals_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: document_approvals document_approvals_delegate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_approvals
    ADD CONSTRAINT document_approvals_delegate_id_fkey FOREIGN KEY (delegate_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: document_approvals document_approvals_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_approvals
    ADD CONSTRAINT document_approvals_document_id_fkey FOREIGN KEY (document_id) REFERENCES "__HCCA_SCHEMA__".documents(id) ON DELETE CASCADE;


--
-- Name: document_attachments document_attachments_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_attachments
    ADD CONSTRAINT document_attachments_document_id_fkey FOREIGN KEY (document_id) REFERENCES "__HCCA_SCHEMA__".documents(id) ON DELETE CASCADE;


--
-- Name: document_attachments document_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_attachments
    ADD CONSTRAINT document_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: document_recipients document_recipients_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_recipients
    ADD CONSTRAINT document_recipients_document_id_fkey FOREIGN KEY (document_id) REFERENCES "__HCCA_SCHEMA__".documents(id) ON DELETE CASCADE;


--
-- Name: document_revisions document_revisions_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_revisions
    ADD CONSTRAINT document_revisions_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: document_revisions document_revisions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_revisions
    ADD CONSTRAINT document_revisions_document_id_fkey FOREIGN KEY (document_id) REFERENCES "__HCCA_SCHEMA__".documents(id) ON DELETE CASCADE;


--
-- Name: document_serial_templates document_serial_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_serial_templates
    ADD CONSTRAINT document_serial_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: document_serial_templates document_serial_templates_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_serial_templates
    ADD CONSTRAINT document_serial_templates_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE RESTRICT;


--
-- Name: document_templates document_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_templates
    ADD CONSTRAINT document_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: document_templates document_templates_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_templates
    ADD CONSTRAINT document_templates_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE RESTRICT;


--
-- Name: document_templates document_templates_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_templates
    ADD CONSTRAINT document_templates_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: documents documents_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".documents
    ADD CONSTRAINT documents_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE RESTRICT;


--
-- Name: election_ballot_boxes election_ballot_boxes_election_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".election_ballot_boxes
    ADD CONSTRAINT election_ballot_boxes_election_id_fkey FOREIGN KEY (election_id) REFERENCES "__HCCA_SCHEMA__".elections(id) ON DELETE CASCADE;


--
-- Name: election_candidate_members election_candidate_members_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".election_candidate_members
    ADD CONSTRAINT election_candidate_members_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES "__HCCA_SCHEMA__".election_candidates(id) ON DELETE CASCADE;


--
-- Name: election_candidates election_candidates_election_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".election_candidates
    ADD CONSTRAINT election_candidates_election_id_fkey FOREIGN KEY (election_id) REFERENCES "__HCCA_SCHEMA__".elections(id) ON DELETE CASCADE;


--
-- Name: elections elections_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".elections
    ADD CONSTRAINT elections_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: electronic_credential_authorizations electronic_credential_authorizations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".electronic_credential_authorizations
    ADD CONSTRAINT electronic_credential_authorizations_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: electronic_credential_authorizations electronic_credential_authorizations_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".electronic_credential_authorizations
    ADD CONSTRAINT electronic_credential_authorizations_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: electronic_credential_settings electronic_credential_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".electronic_credential_settings
    ADD CONSTRAINT electronic_credential_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: email_attachments email_attachments_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_attachments
    ADD CONSTRAINT email_attachments_message_id_fkey FOREIGN KEY (message_id) REFERENCES "__HCCA_SCHEMA__".email_messages(id) ON DELETE CASCADE;


--
-- Name: email_attachments email_attachments_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_attachments
    ADD CONSTRAINT email_attachments_template_id_fkey FOREIGN KEY (template_id) REFERENCES "__HCCA_SCHEMA__".email_templates(id) ON DELETE SET NULL;


--
-- Name: email_attachments email_attachments_uploaded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_attachments
    ADD CONSTRAINT email_attachments_uploaded_by_id_fkey FOREIGN KEY (uploaded_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: email_campaign_recipients email_campaign_recipients_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_campaign_recipients
    ADD CONSTRAINT email_campaign_recipients_message_id_fkey FOREIGN KEY (message_id) REFERENCES "__HCCA_SCHEMA__".email_messages(id) ON DELETE CASCADE;


--
-- Name: email_campaign_recipients email_campaign_recipients_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_campaign_recipients
    ADD CONSTRAINT email_campaign_recipients_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: email_messages email_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_messages
    ADD CONSTRAINT email_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: email_recipient_events email_recipient_events_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_recipient_events
    ADD CONSTRAINT email_recipient_events_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES "__HCCA_SCHEMA__".email_campaign_recipients(id) ON DELETE CASCADE;


--
-- Name: email_recipient_list_members email_recipient_list_members_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_recipient_list_members
    ADD CONSTRAINT email_recipient_list_members_list_id_fkey FOREIGN KEY (list_id) REFERENCES "__HCCA_SCHEMA__".email_recipient_lists(id) ON DELETE CASCADE;


--
-- Name: email_recipient_list_members email_recipient_list_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_recipient_list_members
    ADD CONSTRAINT email_recipient_list_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: email_recipient_lists email_recipient_lists_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_recipient_lists
    ADD CONSTRAINT email_recipient_lists_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: email_recipient_lists email_recipient_lists_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_recipient_lists
    ADD CONSTRAINT email_recipient_lists_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: email_template_versions email_template_versions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_template_versions
    ADD CONSTRAINT email_template_versions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: email_template_versions email_template_versions_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_template_versions
    ADD CONSTRAINT email_template_versions_template_id_fkey FOREIGN KEY (template_id) REFERENCES "__HCCA_SCHEMA__".email_templates(id) ON DELETE CASCADE;


--
-- Name: email_templates email_templates_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_templates
    ADD CONSTRAINT email_templates_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: email_templates email_templates_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_templates
    ADD CONSTRAINT email_templates_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: entity_relations entity_relations_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".entity_relations
    ADD CONSTRAINT entity_relations_case_id_fkey FOREIGN KEY (case_id) REFERENCES "__HCCA_SCHEMA__".governance_cases(id) ON DELETE CASCADE;


--
-- Name: entity_relations entity_relations_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".entity_relations
    ADD CONSTRAINT entity_relations_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: entity_relations entity_relations_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".entity_relations
    ADD CONSTRAINT entity_relations_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES "__HCCA_SCHEMA__".matters(id) ON DELETE CASCADE;


--
-- Name: exam_paper_downloads exam_paper_downloads_paper_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".exam_paper_downloads
    ADD CONSTRAINT exam_paper_downloads_paper_id_fkey FOREIGN KEY (paper_id) REFERENCES "__HCCA_SCHEMA__".exam_papers(id) ON DELETE CASCADE;


--
-- Name: exam_paper_downloads exam_paper_downloads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".exam_paper_downloads
    ADD CONSTRAINT exam_paper_downloads_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: exam_papers exam_papers_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".exam_papers
    ADD CONSTRAINT exam_papers_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: finance_bank_transactions finance_bank_transactions_fund_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_bank_transactions
    ADD CONSTRAINT finance_bank_transactions_fund_account_id_fkey FOREIGN KEY (fund_account_id) REFERENCES "__HCCA_SCHEMA__".finance_fund_accounts(id);


--
-- Name: finance_bank_transactions finance_bank_transactions_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_bank_transactions
    ADD CONSTRAINT finance_bank_transactions_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES "__HCCA_SCHEMA__".finance_journal_entries(id);


--
-- Name: finance_budget_allocation_evidence finance_budget_allocation_evidence_allocation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocation_evidence
    ADD CONSTRAINT finance_budget_allocation_evidence_allocation_id_fkey FOREIGN KEY (allocation_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_allocations(id) ON DELETE CASCADE;


--
-- Name: finance_budget_allocation_evidence finance_budget_allocation_evidence_uploaded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocation_evidence
    ADD CONSTRAINT finance_budget_allocation_evidence_uploaded_by_id_fkey FOREIGN KEY (uploaded_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_budget_allocation_revisions finance_budget_allocation_revisions_allocation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocation_revisions
    ADD CONSTRAINT finance_budget_allocation_revisions_allocation_id_fkey FOREIGN KEY (allocation_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_allocations(id) ON DELETE CASCADE;


--
-- Name: finance_budget_allocation_revisions finance_budget_allocation_revisions_changed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocation_revisions
    ADD CONSTRAINT finance_budget_allocation_revisions_changed_by_id_fkey FOREIGN KEY (changed_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_budget_allocations finance_budget_allocations_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocations
    ADD CONSTRAINT finance_budget_allocations_node_id_fkey FOREIGN KEY (node_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_nodes(id);


--
-- Name: finance_budget_allocations finance_budget_allocations_proposed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocations
    ADD CONSTRAINT finance_budget_allocations_proposed_by_id_fkey FOREIGN KEY (proposed_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_budget_allocations finance_budget_allocations_proposing_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocations
    ADD CONSTRAINT finance_budget_allocations_proposing_org_id_fkey FOREIGN KEY (proposing_org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id);


--
-- Name: finance_budget_allocations finance_budget_allocations_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_allocations
    ADD CONSTRAINT finance_budget_allocations_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_submissions(id) ON DELETE CASCADE;


--
-- Name: finance_budget_expense_evidence finance_budget_expense_evidence_expense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_expense_evidence
    ADD CONSTRAINT finance_budget_expense_evidence_expense_id_fkey FOREIGN KEY (expense_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_expenses(id) ON DELETE CASCADE;


--
-- Name: finance_budget_expense_evidence finance_budget_expense_evidence_uploaded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_expense_evidence
    ADD CONSTRAINT finance_budget_expense_evidence_uploaded_by_id_fkey FOREIGN KEY (uploaded_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_budget_expense_items finance_budget_expense_items_expense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_expense_items
    ADD CONSTRAINT finance_budget_expense_items_expense_id_fkey FOREIGN KEY (expense_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_expenses(id) ON DELETE CASCADE;


--
-- Name: finance_budget_expenses finance_budget_expenses_allocation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_expenses
    ADD CONSTRAINT finance_budget_expenses_allocation_id_fkey FOREIGN KEY (allocation_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_allocations(id);


--
-- Name: finance_budget_expenses finance_budget_expenses_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_expenses
    ADD CONSTRAINT finance_budget_expenses_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES "__HCCA_SCHEMA__".finance_budgets(id) ON DELETE CASCADE;


--
-- Name: finance_budget_expenses finance_budget_expenses_recorded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_expenses
    ADD CONSTRAINT finance_budget_expenses_recorded_by_id_fkey FOREIGN KEY (recorded_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_budget_income_items finance_budget_income_items_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_income_items
    ADD CONSTRAINT finance_budget_income_items_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_submissions(id) ON DELETE CASCADE;


--
-- Name: finance_budget_income_records finance_budget_income_records_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_income_records
    ADD CONSTRAINT finance_budget_income_records_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES "__HCCA_SCHEMA__".finance_budgets(id) ON DELETE CASCADE;


--
-- Name: finance_budget_income_records finance_budget_income_records_income_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_income_records
    ADD CONSTRAINT finance_budget_income_records_income_item_id_fkey FOREIGN KEY (income_item_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_income_items(id);


--
-- Name: finance_budget_income_records finance_budget_income_records_recorded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_income_records
    ADD CONSTRAINT finance_budget_income_records_recorded_by_id_fkey FOREIGN KEY (recorded_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_budget_nodes finance_budget_nodes_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_nodes
    ADD CONSTRAINT finance_budget_nodes_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES "__HCCA_SCHEMA__".finance_budgets(id) ON DELETE CASCADE;


--
-- Name: finance_budget_nodes finance_budget_nodes_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_nodes
    ADD CONSTRAINT finance_budget_nodes_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_nodes(id) ON DELETE CASCADE;


--
-- Name: finance_budget_submissions finance_budget_submissions_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_submissions
    ADD CONSTRAINT finance_budget_submissions_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES "__HCCA_SCHEMA__".finance_budgets(id) ON DELETE CASCADE;


--
-- Name: finance_budget_submissions finance_budget_submissions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_submissions
    ADD CONSTRAINT finance_budget_submissions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_budget_submissions finance_budget_submissions_reviewed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_submissions
    ADD CONSTRAINT finance_budget_submissions_reviewed_by_id_fkey FOREIGN KEY (reviewed_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_budgets finance_budgets_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budgets
    ADD CONSTRAINT finance_budgets_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES "__HCCA_SCHEMA__".finance_ledgers(id);


--
-- Name: finance_budgets finance_budgets_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budgets
    ADD CONSTRAINT finance_budgets_period_id_fkey FOREIGN KEY (period_id) REFERENCES "__HCCA_SCHEMA__".finance_fiscal_periods(id);


--
-- Name: finance_chart_accounts finance_chart_accounts_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_chart_accounts
    ADD CONSTRAINT finance_chart_accounts_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES "__HCCA_SCHEMA__".finance_ledgers(id);


--
-- Name: finance_expense_claim_item_evidence finance_expense_claim_item_evidence_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_expense_claim_item_evidence
    ADD CONSTRAINT finance_expense_claim_item_evidence_item_id_fkey FOREIGN KEY (item_id) REFERENCES "__HCCA_SCHEMA__".finance_expense_claim_items(id) ON DELETE CASCADE;


--
-- Name: finance_expense_claim_item_evidence finance_expense_claim_item_evidence_uploaded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_expense_claim_item_evidence
    ADD CONSTRAINT finance_expense_claim_item_evidence_uploaded_by_id_fkey FOREIGN KEY (uploaded_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_expense_claim_items finance_expense_claim_items_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_expense_claim_items
    ADD CONSTRAINT finance_expense_claim_items_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES "__HCCA_SCHEMA__".finance_journal_entries(id) ON DELETE CASCADE;


--
-- Name: finance_fiscal_periods finance_fiscal_periods_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_fiscal_periods
    ADD CONSTRAINT finance_fiscal_periods_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES "__HCCA_SCHEMA__".finance_ledgers(id);


--
-- Name: finance_fund_accounts finance_fund_accounts_chart_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_fund_accounts
    ADD CONSTRAINT finance_fund_accounts_chart_account_id_fkey FOREIGN KEY (chart_account_id) REFERENCES "__HCCA_SCHEMA__".finance_chart_accounts(id);


--
-- Name: finance_fund_accounts finance_fund_accounts_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_fund_accounts
    ADD CONSTRAINT finance_fund_accounts_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES "__HCCA_SCHEMA__".finance_ledgers(id);


--
-- Name: finance_journal_entries finance_journal_entries_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT finance_journal_entries_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_journal_entries finance_journal_entries_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT finance_journal_entries_ledger_id_fkey FOREIGN KEY (ledger_id) REFERENCES "__HCCA_SCHEMA__".finance_ledgers(id);


--
-- Name: finance_journal_entries finance_journal_entries_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT finance_journal_entries_period_id_fkey FOREIGN KEY (period_id) REFERENCES "__HCCA_SCHEMA__".finance_fiscal_periods(id);


--
-- Name: finance_journal_entries finance_journal_entries_reversal_of_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT finance_journal_entries_reversal_of_id_fkey FOREIGN KEY (reversal_of_id) REFERENCES "__HCCA_SCHEMA__".finance_journal_entries(id);


--
-- Name: finance_journal_entries finance_journal_entries_reviewed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT finance_journal_entries_reviewed_by_id_fkey FOREIGN KEY (reviewed_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_journal_lines finance_journal_lines_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_lines
    ADD CONSTRAINT finance_journal_lines_account_id_fkey FOREIGN KEY (account_id) REFERENCES "__HCCA_SCHEMA__".finance_chart_accounts(id);


--
-- Name: finance_journal_lines finance_journal_lines_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_lines
    ADD CONSTRAINT finance_journal_lines_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES "__HCCA_SCHEMA__".finance_journal_entries(id) ON DELETE CASCADE;


--
-- Name: finance_ledgers finance_ledgers_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_ledgers
    ADD CONSTRAINT finance_ledgers_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id);


--
-- Name: announcements fk_announcements_activity_id_activities; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".announcements
    ADD CONSTRAINT fk_announcements_activity_id_activities FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE SET NULL;


--
-- Name: council_proposals fk_council_proposals_regulation_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".council_proposals
    ADD CONSTRAINT fk_council_proposals_regulation_id FOREIGN KEY (regulation_id) REFERENCES "__HCCA_SCHEMA__".regulations(id) ON DELETE SET NULL;


--
-- Name: document_recipients fk_document_recipients_target_class_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_recipients
    ADD CONSTRAINT fk_document_recipients_target_class_id FOREIGN KEY (target_class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE SET NULL;


--
-- Name: document_recipients fk_document_recipients_target_org; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_recipients
    ADD CONSTRAINT fk_document_recipients_target_org FOREIGN KEY (target_org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: document_recipients fk_document_recipients_target_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".document_recipients
    ADD CONSTRAINT fk_document_recipients_target_user FOREIGN KEY (target_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: documents fk_documents_activity_id_activities; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".documents
    ADD CONSTRAINT fk_documents_activity_id_activities FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE SET NULL;


--
-- Name: documents fk_documents_petition_case_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".documents
    ADD CONSTRAINT fk_documents_petition_case_id FOREIGN KEY (petition_case_id) REFERENCES "__HCCA_SCHEMA__".petition_cases(id) ON DELETE SET NULL;


--
-- Name: documents fk_documents_regulation_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".documents
    ADD CONSTRAINT fk_documents_regulation_id FOREIGN KEY (regulation_id) REFERENCES "__HCCA_SCHEMA__".regulations(id) ON DELETE SET NULL;


--
-- Name: documents fk_documents_regulation_revision_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".documents
    ADD CONSTRAINT fk_documents_regulation_revision_id FOREIGN KEY (regulation_revision_id) REFERENCES "__HCCA_SCHEMA__".regulation_revisions(id) ON DELETE SET NULL;


--
-- Name: documents fk_documents_serial_template_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".documents
    ADD CONSTRAINT fk_documents_serial_template_id FOREIGN KEY (serial_template_id) REFERENCES "__HCCA_SCHEMA__".document_serial_templates(id) ON DELETE RESTRICT;


--
-- Name: email_messages fk_email_messages_org_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_messages
    ADD CONSTRAINT fk_email_messages_org_id FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: email_messages fk_email_messages_template_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".email_messages
    ADD CONSTRAINT fk_email_messages_template_id FOREIGN KEY (template_id) REFERENCES "__HCCA_SCHEMA__".email_templates(id) ON DELETE SET NULL;


--
-- Name: finance_budget_expenses fk_finance_budget_expenses_department_org_id_orgs; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_budget_expenses
    ADD CONSTRAINT fk_finance_budget_expenses_department_org_id_orgs FOREIGN KEY (department_org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id);


--
-- Name: finance_expense_claim_items fk_finance_claim_item_budget_node; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_expense_claim_items
    ADD CONSTRAINT fk_finance_claim_item_budget_node FOREIGN KEY (budget_node_id) REFERENCES "__HCCA_SCHEMA__".finance_budget_nodes(id);


--
-- Name: finance_journal_entries fk_finance_journal_advanced_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT fk_finance_journal_advanced_user FOREIGN KEY (advanced_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_journal_entries fk_finance_journal_budget_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT fk_finance_journal_budget_user FOREIGN KEY (budget_included_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_journal_entries fk_finance_journal_payment_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT fk_finance_journal_payment_user FOREIGN KEY (payment_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_journal_entries fk_finance_journal_procurement_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT fk_finance_journal_procurement_user FOREIGN KEY (procurement_updated_by_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: finance_journal_entries fk_finance_journal_proposing_org; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT fk_finance_journal_proposing_org FOREIGN KEY (proposing_org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id);


--
-- Name: finance_journal_entries fk_finance_journal_reimbursement; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".finance_journal_entries
    ADD CONSTRAINT fk_finance_journal_reimbursement FOREIGN KEY (reimbursement_entry_id) REFERENCES "__HCCA_SCHEMA__".finance_journal_entries(id);


--
-- Name: merchandise_submissions fk_merchandise_submissions_voting_survey_id_surveys; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submissions
    ADD CONSTRAINT fk_merchandise_submissions_voting_survey_id_surveys FOREIGN KEY (voting_survey_id) REFERENCES "__HCCA_SCHEMA__".surveys(id) ON DELETE SET NULL;


--
-- Name: order_items fk_order_items_delegation_link; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".order_items
    ADD CONSTRAINT fk_order_items_delegation_link FOREIGN KEY (delegation_link_id) REFERENCES "__HCCA_SCHEMA__".shop_delegation_links(id) ON DELETE RESTRICT;


--
-- Name: order_items fk_order_items_ordered_by; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".order_items
    ADD CONSTRAINT fk_order_items_ordered_by FOREIGN KEY (ordered_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders_activity_id_activities; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT fk_orders_activity_id_activities FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders_assisted_by_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT fk_orders_assisted_by_id_users FOREIGN KEY (assisted_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders_category_id_product_categories; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT fk_orders_category_id_product_categories FOREIGN KEY (category_id) REFERENCES "__HCCA_SCHEMA__".product_categories(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders_class_collected_by_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT fk_orders_class_collected_by_id_users FOREIGN KEY (class_collected_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders_class_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT fk_orders_class_id FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders_paid_by_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT fk_orders_paid_by_id FOREIGN KEY (paid_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders_promotion_id_shop_promotions; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT fk_orders_promotion_id_shop_promotions FOREIGN KEY (promotion_id) REFERENCES "__HCCA_SCHEMA__".shop_promotions(id) ON DELETE SET NULL;


--
-- Name: orders fk_orders_supplement_class_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT fk_orders_supplement_class_id FOREIGN KEY (supplement_class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE RESTRICT;


--
-- Name: orders fk_orders_test_product_id_products; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT fk_orders_test_product_id_products FOREIGN KEY (test_product_id) REFERENCES "__HCCA_SCHEMA__".products(id) ON DELETE RESTRICT;


--
-- Name: orgs fk_orgs_leader_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orgs
    ADD CONSTRAINT fk_orgs_leader_user_id_users FOREIGN KEY (leader_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: petition_case_events fk_petition_case_events_related_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_case_events
    ADD CONSTRAINT fk_petition_case_events_related_document_id FOREIGN KEY (related_document_id) REFERENCES "__HCCA_SCHEMA__".documents(id) ON DELETE SET NULL;


--
-- Name: positions fk_positions_parent_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".positions
    ADD CONSTRAINT fk_positions_parent_id FOREIGN KEY (parent_id) REFERENCES "__HCCA_SCHEMA__".positions(id) ON DELETE SET NULL;


--
-- Name: product_categories fk_product_categories_activity_id_activities; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_categories
    ADD CONSTRAINT fk_product_categories_activity_id_activities FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE SET NULL;


--
-- Name: products fk_products_category_id_product_categories; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".products
    ADD CONSTRAINT fk_products_category_id_product_categories FOREIGN KEY (category_id) REFERENCES "__HCCA_SCHEMA__".product_categories(id) ON DELETE RESTRICT;


--
-- Name: products fk_products_series_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".products
    ADD CONSTRAINT fk_products_series_id FOREIGN KEY (series_id) REFERENCES "__HCCA_SCHEMA__".product_series(id) ON DELETE RESTRICT;


--
-- Name: recommended_vendors fk_recommended_vendors_category_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".recommended_vendors
    ADD CONSTRAINT fk_recommended_vendors_category_id FOREIGN KEY (category_id) REFERENCES "__HCCA_SCHEMA__".recommended_vendor_categories(id) ON DELETE SET NULL;


--
-- Name: regulation_articles fk_regulation_articles_parent_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_articles
    ADD CONSTRAINT fk_regulation_articles_parent_id FOREIGN KEY (parent_id) REFERENCES "__HCCA_SCHEMA__".regulation_articles(id) ON DELETE CASCADE;


--
-- Name: regulations fk_regulations_published_document_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulations
    ADD CONSTRAINT fk_regulations_published_document_id FOREIGN KEY (published_document_id) REFERENCES "__HCCA_SCHEMA__".documents(id) ON DELETE SET NULL;


--
-- Name: regulations fk_regulations_source_regulation_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulations
    ADD CONSTRAINT fk_regulations_source_regulation_id FOREIGN KEY (source_regulation_id) REFERENCES "__HCCA_SCHEMA__".regulations(id) ON DELETE SET NULL;


--
-- Name: saved_filters fk_saved_filters_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".saved_filters
    ADD CONSTRAINT fk_saved_filters_user_id FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: school_classes fk_school_classes_org_id_orgs; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".school_classes
    ADD CONSTRAINT fk_school_classes_org_id_orgs FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: shop_promotions fk_shop_promotions_activity_id_activities; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotions
    ADD CONSTRAINT fk_shop_promotions_activity_id_activities FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE SET NULL;


--
-- Name: surveys fk_surveys_activity_id_activities; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".surveys
    ADD CONSTRAINT fk_surveys_activity_id_activities FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE SET NULL;


--
-- Name: surveys fk_surveys_announcement_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".surveys
    ADD CONSTRAINT fk_surveys_announcement_id FOREIGN KEY (announcement_id) REFERENCES "__HCCA_SCHEMA__".announcements(id) ON DELETE SET NULL;


--
-- Name: gallery_drive_sync gallery_drive_sync_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".gallery_drive_sync
    ADD CONSTRAINT gallery_drive_sync_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: governance_cases governance_cases_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_cases
    ADD CONSTRAINT governance_cases_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES "__HCCA_SCHEMA__".matters(id) ON DELETE CASCADE;


--
-- Name: governance_cases governance_cases_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_cases
    ADD CONSTRAINT governance_cases_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: governance_cases governance_cases_program_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_cases
    ADD CONSTRAINT governance_cases_program_id_fkey FOREIGN KEY (program_id) REFERENCES "__HCCA_SCHEMA__".programs(id) ON DELETE SET NULL;


--
-- Name: governance_discord_event_routes governance_discord_event_routes_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_discord_event_routes
    ADD CONSTRAINT governance_discord_event_routes_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES "__HCCA_SCHEMA__".governance_discord_workspaces(id) ON DELETE CASCADE;


--
-- Name: governance_discord_workspaces governance_discord_workspaces_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_discord_workspaces
    ADD CONSTRAINT governance_discord_workspaces_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES "__HCCA_SCHEMA__".matters(id) ON DELETE CASCADE;


--
-- Name: governance_workflow_templates governance_workflow_templates_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".governance_workflow_templates
    ADD CONSTRAINT governance_workflow_templates_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: inventory_categories inventory_categories_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_categories
    ADD CONSTRAINT inventory_categories_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: inventory_items inventory_items_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_items
    ADD CONSTRAINT inventory_items_category_id_fkey FOREIGN KEY (category_id) REFERENCES "__HCCA_SCHEMA__".inventory_categories(id) ON DELETE SET NULL;


--
-- Name: inventory_items inventory_items_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_items
    ADD CONSTRAINT inventory_items_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: inventory_procurement_items inventory_procurement_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_procurement_items
    ADD CONSTRAINT inventory_procurement_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES "__HCCA_SCHEMA__".inventory_items(id) ON DELETE SET NULL;


--
-- Name: inventory_procurement_items inventory_procurement_items_procurement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_procurement_items
    ADD CONSTRAINT inventory_procurement_items_procurement_id_fkey FOREIGN KEY (procurement_id) REFERENCES "__HCCA_SCHEMA__".inventory_procurements(id) ON DELETE CASCADE;


--
-- Name: inventory_procurements inventory_procurements_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_procurements
    ADD CONSTRAINT inventory_procurements_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: inventory_procurements inventory_procurements_requester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_procurements
    ADD CONSTRAINT inventory_procurements_requester_id_fkey FOREIGN KEY (requester_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: inventory_procurements inventory_procurements_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_procurements
    ADD CONSTRAINT inventory_procurements_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: inventory_transactions inventory_transactions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_transactions
    ADD CONSTRAINT inventory_transactions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: inventory_transactions inventory_transactions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".inventory_transactions
    ADD CONSTRAINT inventory_transactions_item_id_fkey FOREIGN KEY (item_id) REFERENCES "__HCCA_SCHEMA__".inventory_items(id) ON DELETE CASCADE;


--
-- Name: judicial_petitions judicial_petitions_submitter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".judicial_petitions
    ADD CONSTRAINT judicial_petitions_submitter_id_fkey FOREIGN KEY (submitter_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: line_account_links line_account_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".line_account_links
    ADD CONSTRAINT line_account_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: matter_resources matter_resources_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matter_resources
    ADD CONSTRAINT matter_resources_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: matter_resources matter_resources_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matter_resources
    ADD CONSTRAINT matter_resources_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES "__HCCA_SCHEMA__".matters(id) ON DELETE CASCADE;


--
-- Name: matter_role_assignments matter_role_assignments_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matter_role_assignments
    ADD CONSTRAINT matter_role_assignments_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES "__HCCA_SCHEMA__".matters(id) ON DELETE CASCADE;


--
-- Name: matter_role_assignments matter_role_assignments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matter_role_assignments
    ADD CONSTRAINT matter_role_assignments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES "__HCCA_SCHEMA__".matter_role_assignments(id) ON DELETE SET NULL;


--
-- Name: matter_role_assignments matter_role_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matter_role_assignments
    ADD CONSTRAINT matter_role_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: matters matters_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matters
    ADD CONSTRAINT matters_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: matters matters_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matters
    ADD CONSTRAINT matters_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: matters matters_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".matters
    ADD CONSTRAINT matters_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: merchandise_submission_files merchandise_submission_files_submission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submission_files
    ADD CONSTRAINT merchandise_submission_files_submission_id_fkey FOREIGN KEY (submission_id) REFERENCES "__HCCA_SCHEMA__".merchandise_submissions(id) ON DELETE CASCADE;


--
-- Name: merchandise_submission_items merchandise_submission_items_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submission_items
    ADD CONSTRAINT merchandise_submission_items_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: merchandise_submission_settings merchandise_submission_settings_announcement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submission_settings
    ADD CONSTRAINT merchandise_submission_settings_announcement_id_fkey FOREIGN KEY (announcement_id) REFERENCES "__HCCA_SCHEMA__".announcements(id) ON DELETE SET NULL;


--
-- Name: merchandise_submission_settings merchandise_submission_settings_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submission_settings
    ADD CONSTRAINT merchandise_submission_settings_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: merchandise_submissions merchandise_submissions_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submissions
    ADD CONSTRAINT merchandise_submissions_item_id_fkey FOREIGN KEY (item_id) REFERENCES "__HCCA_SCHEMA__".merchandise_submission_items(id) ON DELETE RESTRICT;


--
-- Name: merchandise_submissions merchandise_submissions_reviewer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submissions
    ADD CONSTRAINT merchandise_submissions_reviewer_id_fkey FOREIGN KEY (reviewer_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: merchandise_submissions merchandise_submissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".merchandise_submissions
    ADD CONSTRAINT merchandise_submissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: navigation_profile_positions navigation_profile_positions_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".navigation_profile_positions
    ADD CONSTRAINT navigation_profile_positions_position_id_fkey FOREIGN KEY (position_id) REFERENCES "__HCCA_SCHEMA__".positions(id) ON DELETE CASCADE;


--
-- Name: navigation_profile_positions navigation_profile_positions_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".navigation_profile_positions
    ADD CONSTRAINT navigation_profile_positions_profile_id_fkey FOREIGN KEY (profile_id) REFERENCES "__HCCA_SCHEMA__".navigation_profiles(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES "__HCCA_SCHEMA__".orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".order_items
    ADD CONSTRAINT order_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES "__HCCA_SCHEMA__".products(id) ON DELETE RESTRICT;


--
-- Name: orders orders_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orders
    ADD CONSTRAINT orders_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: orgs orgs_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".orgs
    ADD CONSTRAINT orgs_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: pagespeed_audits pagespeed_audits_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".pagespeed_audits
    ADD CONSTRAINT pagespeed_audits_run_id_fkey FOREIGN KEY (run_id) REFERENCES "__HCCA_SCHEMA__".pagespeed_runs(id) ON DELETE CASCADE;


--
-- Name: pagespeed_runs pagespeed_runs_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".pagespeed_runs
    ADD CONSTRAINT pagespeed_runs_release_id_fkey FOREIGN KEY (release_id) REFERENCES "__HCCA_SCHEMA__".observability_releases(id) ON DELETE SET NULL;


--
-- Name: partner_application_fields partner_application_fields_settings_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_application_fields
    ADD CONSTRAINT partner_application_fields_settings_id_fkey FOREIGN KEY (settings_id) REFERENCES "__HCCA_SCHEMA__".partner_application_settings(id) ON DELETE CASCADE;


--
-- Name: partner_application_settings partner_application_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_application_settings
    ADD CONSTRAINT partner_application_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: partner_business_accounts partner_business_accounts_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_accounts
    ADD CONSTRAINT partner_business_accounts_business_id_fkey FOREIGN KEY (business_id) REFERENCES "__HCCA_SCHEMA__".partner_businesses(id) ON DELETE CASCADE;


--
-- Name: partner_business_accounts partner_business_accounts_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_accounts
    ADD CONSTRAINT partner_business_accounts_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: partner_business_accounts partner_business_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_accounts
    ADD CONSTRAINT partner_business_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: partner_business_applications partner_business_applications_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_applications
    ADD CONSTRAINT partner_business_applications_business_id_fkey FOREIGN KEY (business_id) REFERENCES "__HCCA_SCHEMA__".partner_businesses(id) ON DELETE SET NULL;


--
-- Name: partner_business_applications partner_business_applications_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_applications
    ADD CONSTRAINT partner_business_applications_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: partner_business_applications partner_business_applications_submitted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_applications
    ADD CONSTRAINT partner_business_applications_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: partner_business_images partner_business_images_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_images
    ADD CONSTRAINT partner_business_images_business_id_fkey FOREIGN KEY (business_id) REFERENCES "__HCCA_SCHEMA__".partner_businesses(id) ON DELETE CASCADE;


--
-- Name: partner_business_tags partner_business_tags_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_tags
    ADD CONSTRAINT partner_business_tags_business_id_fkey FOREIGN KEY (business_id) REFERENCES "__HCCA_SCHEMA__".partner_businesses(id) ON DELETE CASCADE;


--
-- Name: partner_business_tags partner_business_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_business_tags
    ADD CONSTRAINT partner_business_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES "__HCCA_SCHEMA__".partner_tags(id) ON DELETE CASCADE;


--
-- Name: partner_businesses partner_businesses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_businesses
    ADD CONSTRAINT partner_businesses_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: partner_locations partner_locations_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_locations
    ADD CONSTRAINT partner_locations_business_id_fkey FOREIGN KEY (business_id) REFERENCES "__HCCA_SCHEMA__".partner_businesses(id) ON DELETE CASCADE;


--
-- Name: partner_offers partner_offers_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_offers
    ADD CONSTRAINT partner_offers_business_id_fkey FOREIGN KEY (business_id) REFERENCES "__HCCA_SCHEMA__".partner_businesses(id) ON DELETE CASCADE;


--
-- Name: partner_submissions partner_submissions_business_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_submissions
    ADD CONSTRAINT partner_submissions_business_id_fkey FOREIGN KEY (business_id) REFERENCES "__HCCA_SCHEMA__".partner_businesses(id) ON DELETE SET NULL;


--
-- Name: partner_submissions partner_submissions_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_submissions
    ADD CONSTRAINT partner_submissions_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: partner_submissions partner_submissions_submitted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".partner_submissions
    ADD CONSTRAINT partner_submissions_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: passkey_credentials passkey_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".passkey_credentials
    ADD CONSTRAINT passkey_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: people people_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".people
    ADD CONSTRAINT people_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: permissions permissions_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".permissions
    ADD CONSTRAINT permissions_position_id_fkey FOREIGN KEY (position_id) REFERENCES "__HCCA_SCHEMA__".positions(id) ON DELETE CASCADE;


--
-- Name: person_affiliations person_affiliations_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".person_affiliations
    ADD CONSTRAINT person_affiliations_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE SET NULL;


--
-- Name: person_affiliations person_affiliations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".person_affiliations
    ADD CONSTRAINT person_affiliations_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: person_affiliations person_affiliations_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".person_affiliations
    ADD CONSTRAINT person_affiliations_person_id_fkey FOREIGN KEY (person_id) REFERENCES "__HCCA_SCHEMA__".people(id) ON DELETE CASCADE;


--
-- Name: person_affiliations person_affiliations_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".person_affiliations
    ADD CONSTRAINT person_affiliations_position_id_fkey FOREIGN KEY (position_id) REFERENCES "__HCCA_SCHEMA__".positions(id) ON DELETE SET NULL;


--
-- Name: person_affiliations person_affiliations_synced_user_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".person_affiliations
    ADD CONSTRAINT person_affiliations_synced_user_position_id_fkey FOREIGN KEY (synced_user_position_id) REFERENCES "__HCCA_SCHEMA__".user_positions(id) ON DELETE SET NULL;


--
-- Name: petition_attachments petition_attachments_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_attachments
    ADD CONSTRAINT petition_attachments_case_id_fkey FOREIGN KEY (case_id) REFERENCES "__HCCA_SCHEMA__".petition_cases(id) ON DELETE CASCADE;


--
-- Name: petition_attachments petition_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_attachments
    ADD CONSTRAINT petition_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: petition_case_events petition_case_events_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_case_events
    ADD CONSTRAINT petition_case_events_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: petition_case_events petition_case_events_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_case_events
    ADD CONSTRAINT petition_case_events_case_id_fkey FOREIGN KEY (case_id) REFERENCES "__HCCA_SCHEMA__".petition_cases(id) ON DELETE CASCADE;


--
-- Name: petition_case_events petition_case_events_from_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_case_events
    ADD CONSTRAINT petition_case_events_from_org_id_fkey FOREIGN KEY (from_org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: petition_case_events petition_case_events_to_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_case_events
    ADD CONSTRAINT petition_case_events_to_org_id_fkey FOREIGN KEY (to_org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: petition_cases petition_cases_assigned_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_cases
    ADD CONSTRAINT petition_cases_assigned_to_id_fkey FOREIGN KEY (assigned_to_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: petition_cases petition_cases_current_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_cases
    ADD CONSTRAINT petition_cases_current_org_id_fkey FOREIGN KEY (current_org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE RESTRICT;


--
-- Name: petition_cases petition_cases_submitter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_cases
    ADD CONSTRAINT petition_cases_submitter_id_fkey FOREIGN KEY (submitter_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: petition_cases petition_cases_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_cases
    ADD CONSTRAINT petition_cases_type_id_fkey FOREIGN KEY (type_id) REFERENCES "__HCCA_SCHEMA__".petition_types(id) ON DELETE RESTRICT;


--
-- Name: petition_notification_rules petition_notification_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_notification_rules
    ADD CONSTRAINT petition_notification_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: petition_notification_rules petition_notification_rules_petition_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_notification_rules
    ADD CONSTRAINT petition_notification_rules_petition_type_id_fkey FOREIGN KEY (petition_type_id) REFERENCES "__HCCA_SCHEMA__".petition_types(id) ON DELETE CASCADE;


--
-- Name: petition_notification_rules petition_notification_rules_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_notification_rules
    ADD CONSTRAINT petition_notification_rules_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: petition_notification_settings petition_notification_settings_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_notification_settings
    ADD CONSTRAINT petition_notification_settings_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: petition_types petition_types_responsible_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".petition_types
    ADD CONSTRAINT petition_types_responsible_org_id_fkey FOREIGN KEY (responsible_org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE RESTRICT;


--
-- Name: planning_document_attachments planning_document_attachments_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_document_attachments
    ADD CONSTRAINT planning_document_attachments_document_id_fkey FOREIGN KEY (document_id) REFERENCES "__HCCA_SCHEMA__".planning_documents(id) ON DELETE CASCADE;


--
-- Name: planning_document_attachments planning_document_attachments_uploaded_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_document_attachments
    ADD CONSTRAINT planning_document_attachments_uploaded_by_id_fkey FOREIGN KEY (uploaded_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: planning_document_revision_attachments planning_document_revision_attachments_attachment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_document_revision_attachments
    ADD CONSTRAINT planning_document_revision_attachments_attachment_id_fkey FOREIGN KEY (attachment_id) REFERENCES "__HCCA_SCHEMA__".planning_document_attachments(id) ON DELETE RESTRICT;


--
-- Name: planning_document_revision_attachments planning_document_revision_attachments_revision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_document_revision_attachments
    ADD CONSTRAINT planning_document_revision_attachments_revision_id_fkey FOREIGN KEY (revision_id) REFERENCES "__HCCA_SCHEMA__".planning_document_revisions(id) ON DELETE CASCADE;


--
-- Name: planning_document_revisions planning_document_revisions_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_document_revisions
    ADD CONSTRAINT planning_document_revisions_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: planning_document_revisions planning_document_revisions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_document_revisions
    ADD CONSTRAINT planning_document_revisions_document_id_fkey FOREIGN KEY (document_id) REFERENCES "__HCCA_SCHEMA__".planning_documents(id) ON DELETE CASCADE;


--
-- Name: planning_documents planning_documents_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_documents
    ADD CONSTRAINT planning_documents_case_id_fkey FOREIGN KEY (case_id) REFERENCES "__HCCA_SCHEMA__".governance_cases(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_documents
    ADD CONSTRAINT planning_documents_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: planning_documents planning_documents_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".planning_documents
    ADD CONSTRAINT planning_documents_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES "__HCCA_SCHEMA__".matters(id) ON DELETE CASCADE;


--
-- Name: policy_consents policy_consents_policy_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".policy_consents
    ADD CONSTRAINT policy_consents_policy_document_id_fkey FOREIGN KEY (policy_document_id) REFERENCES "__HCCA_SCHEMA__".policy_documents(id) ON DELETE RESTRICT;


--
-- Name: policy_consents policy_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".policy_consents
    ADD CONSTRAINT policy_consents_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: policy_documents policy_documents_published_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".policy_documents
    ADD CONSTRAINT policy_documents_published_by_fkey FOREIGN KEY (published_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: positions positions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".positions
    ADD CONSTRAINT positions_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: privacy_requests privacy_requests_handled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".privacy_requests
    ADD CONSTRAINT privacy_requests_handled_by_fkey FOREIGN KEY (handled_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: privacy_requests privacy_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".privacy_requests
    ADD CONSTRAINT privacy_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: product_categories product_categories_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_categories
    ADD CONSTRAINT product_categories_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: product_media product_media_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_media
    ADD CONSTRAINT product_media_product_id_fkey FOREIGN KEY (product_id) REFERENCES "__HCCA_SCHEMA__".products(id) ON DELETE RESTRICT;


--
-- Name: product_series product_series_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_series
    ADD CONSTRAINT product_series_category_id_fkey FOREIGN KEY (category_id) REFERENCES "__HCCA_SCHEMA__".product_categories(id) ON DELETE CASCADE;


--
-- Name: product_variant_groups product_variant_groups_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_variant_groups
    ADD CONSTRAINT product_variant_groups_product_id_fkey FOREIGN KEY (product_id) REFERENCES "__HCCA_SCHEMA__".products(id) ON DELETE CASCADE;


--
-- Name: product_variant_options product_variant_options_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".product_variant_options
    ADD CONSTRAINT product_variant_options_group_id_fkey FOREIGN KEY (group_id) REFERENCES "__HCCA_SCHEMA__".product_variant_groups(id) ON DELETE CASCADE;


--
-- Name: products products_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".products
    ADD CONSTRAINT products_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: programs programs_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".programs
    ADD CONSTRAINT programs_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES "__HCCA_SCHEMA__".matters(id) ON DELETE CASCADE;


--
-- Name: programs programs_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".programs
    ADD CONSTRAINT programs_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: public_links public_links_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_links
    ADD CONSTRAINT public_links_category_id_fkey FOREIGN KEY (category_id) REFERENCES "__HCCA_SCHEMA__".public_link_categories(id) ON DELETE SET NULL;


--
-- Name: public_officer_profiles public_officer_profiles_user_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_officer_profiles
    ADD CONSTRAINT public_officer_profiles_user_position_id_fkey FOREIGN KEY (user_position_id) REFERENCES "__HCCA_SCHEMA__".user_positions(id) ON DELETE CASCADE;


--
-- Name: public_site_page_views public_site_page_views_page_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".public_site_page_views
    ADD CONSTRAINT public_site_page_views_page_id_fkey FOREIGN KEY (page_id) REFERENCES "__HCCA_SCHEMA__".public_site_pages(id) ON DELETE CASCADE;


--
-- Name: publication_campaigns publication_campaigns_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".publication_campaigns
    ADD CONSTRAINT publication_campaigns_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE SET NULL;


--
-- Name: publication_campaigns publication_campaigns_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".publication_campaigns
    ADD CONSTRAINT publication_campaigns_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: publication_campaigns publication_campaigns_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".publication_campaigns
    ADD CONSTRAINT publication_campaigns_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: publication_deliveries publication_deliveries_campaign_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".publication_deliveries
    ADD CONSTRAINT publication_deliveries_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES "__HCCA_SCHEMA__".publication_campaigns(id) ON DELETE CASCADE;


--
-- Name: publication_deliveries publication_deliveries_recipient_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".publication_deliveries
    ADD CONSTRAINT publication_deliveries_recipient_user_id_fkey FOREIGN KEY (recipient_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: raffle_draws raffle_draws_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_draws
    ADD CONSTRAINT raffle_draws_event_id_fkey FOREIGN KEY (event_id) REFERENCES "__HCCA_SCHEMA__".raffle_events(id) ON DELETE CASCADE;


--
-- Name: raffle_draws raffle_draws_prize_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_draws
    ADD CONSTRAINT raffle_draws_prize_id_fkey FOREIGN KEY (prize_id) REFERENCES "__HCCA_SCHEMA__".raffle_prizes(id) ON DELETE RESTRICT;


--
-- Name: raffle_draws raffle_draws_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_draws
    ADD CONSTRAINT raffle_draws_session_id_fkey FOREIGN KEY (session_id) REFERENCES "__HCCA_SCHEMA__".raffle_sessions(id) ON DELETE CASCADE;


--
-- Name: raffle_events raffle_events_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_events
    ADD CONSTRAINT raffle_events_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: raffle_prizes raffle_prizes_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_prizes
    ADD CONSTRAINT raffle_prizes_event_id_fkey FOREIGN KEY (event_id) REFERENCES "__HCCA_SCHEMA__".raffle_events(id) ON DELETE CASCADE;


--
-- Name: raffle_sessions raffle_sessions_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".raffle_sessions
    ADD CONSTRAINT raffle_sessions_event_id_fkey FOREIGN KEY (event_id) REFERENCES "__HCCA_SCHEMA__".raffle_events(id) ON DELETE CASCADE;


--
-- Name: receivables receivables_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".receivables
    ADD CONSTRAINT receivables_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE SET NULL;


--
-- Name: receivables receivables_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".receivables
    ADD CONSTRAINT receivables_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE SET NULL;


--
-- Name: receivables receivables_collected_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".receivables
    ADD CONSTRAINT receivables_collected_by_id_fkey FOREIGN KEY (collected_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: receivables receivables_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".receivables
    ADD CONSTRAINT receivables_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: receivables receivables_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".receivables
    ADD CONSTRAINT receivables_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: recommended_vendor_menus recommended_vendor_menus_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".recommended_vendor_menus
    ADD CONSTRAINT recommended_vendor_menus_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES "__HCCA_SCHEMA__".recommended_vendors(id) ON DELETE CASCADE;


--
-- Name: recommended_vendor_products recommended_vendor_products_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".recommended_vendor_products
    ADD CONSTRAINT recommended_vendor_products_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES "__HCCA_SCHEMA__".recommended_vendors(id) ON DELETE CASCADE;


--
-- Name: recommended_vendors recommended_vendors_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".recommended_vendors
    ADD CONSTRAINT recommended_vendors_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: regulation_articles regulation_articles_regulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_articles
    ADD CONSTRAINT regulation_articles_regulation_id_fkey FOREIGN KEY (regulation_id) REFERENCES "__HCCA_SCHEMA__".regulations(id) ON DELETE CASCADE;


--
-- Name: regulation_revisions regulation_revisions_amended_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_revisions
    ADD CONSTRAINT regulation_revisions_amended_by_fkey FOREIGN KEY (amended_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: regulation_revisions regulation_revisions_regulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_revisions
    ADD CONSTRAINT regulation_revisions_regulation_id_fkey FOREIGN KEY (regulation_id) REFERENCES "__HCCA_SCHEMA__".regulations(id) ON DELETE CASCADE;


--
-- Name: regulation_sync_sources regulation_sync_sources_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_sync_sources
    ADD CONSTRAINT regulation_sync_sources_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: regulation_sync_sources regulation_sync_sources_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_sync_sources
    ADD CONSTRAINT regulation_sync_sources_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE CASCADE;


--
-- Name: regulation_workflow_logs regulation_workflow_logs_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_workflow_logs
    ADD CONSTRAINT regulation_workflow_logs_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: regulation_workflow_logs regulation_workflow_logs_regulation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulation_workflow_logs
    ADD CONSTRAINT regulation_workflow_logs_regulation_id_fkey FOREIGN KEY (regulation_id) REFERENCES "__HCCA_SCHEMA__".regulations(id) ON DELETE CASCADE;


--
-- Name: regulations regulations_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulations
    ADD CONSTRAINT regulations_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: regulations regulations_freeze_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulations
    ADD CONSTRAINT regulations_freeze_document_id_fkey FOREIGN KEY (freeze_document_id) REFERENCES "__HCCA_SCHEMA__".documents(id) ON DELETE SET NULL;


--
-- Name: regulations regulations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulations
    ADD CONSTRAINT regulations_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE RESTRICT;


--
-- Name: regulations regulations_repeal_replacement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".regulations
    ADD CONSTRAINT regulations_repeal_replacement_id_fkey FOREIGN KEY (repeal_replacement_id) REFERENCES "__HCCA_SCHEMA__".regulations(id) ON DELETE SET NULL;


--
-- Name: school_classes school_classes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".school_classes
    ADD CONSTRAINT school_classes_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: seat_assignments seat_assignments_assigned_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_assignments
    ADD CONSTRAINT seat_assignments_assigned_by_id_fkey FOREIGN KEY (assigned_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: seat_assignments seat_assignments_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_assignments
    ADD CONSTRAINT seat_assignments_order_id_fkey FOREIGN KEY (order_id) REFERENCES "__HCCA_SCHEMA__".orders(id) ON DELETE CASCADE;


--
-- Name: seat_assignments seat_assignments_order_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_assignments
    ADD CONSTRAINT seat_assignments_order_item_id_fkey FOREIGN KEY (order_item_id) REFERENCES "__HCCA_SCHEMA__".order_items(id) ON DELETE SET NULL;


--
-- Name: seat_assignments seat_assignments_seat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_assignments
    ADD CONSTRAINT seat_assignments_seat_id_fkey FOREIGN KEY (seat_id) REFERENCES "__HCCA_SCHEMA__".seats(id) ON DELETE RESTRICT;


--
-- Name: seat_assignments seat_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_assignments
    ADD CONSTRAINT seat_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: seat_assignments seat_assignments_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_assignments
    ADD CONSTRAINT seat_assignments_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES "__HCCA_SCHEMA__".seating_zones(id) ON DELETE CASCADE;


--
-- Name: seat_holds seat_holds_seat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_holds
    ADD CONSTRAINT seat_holds_seat_id_fkey FOREIGN KEY (seat_id) REFERENCES "__HCCA_SCHEMA__".seats(id) ON DELETE CASCADE;


--
-- Name: seat_holds seat_holds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_holds
    ADD CONSTRAINT seat_holds_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: seat_holds seat_holds_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seat_holds
    ADD CONSTRAINT seat_holds_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES "__HCCA_SCHEMA__".seating_zones(id) ON DELETE CASCADE;


--
-- Name: seating_waves seating_waves_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seating_waves
    ADD CONSTRAINT seating_waves_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES "__HCCA_SCHEMA__".seating_zones(id) ON DELETE CASCADE;


--
-- Name: seating_zones seating_zones_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seating_zones
    ADD CONSTRAINT seating_zones_product_id_fkey FOREIGN KEY (product_id) REFERENCES "__HCCA_SCHEMA__".products(id) ON DELETE CASCADE;


--
-- Name: seats seats_zone_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".seats
    ADD CONSTRAINT seats_zone_id_fkey FOREIGN KEY (zone_id) REFERENCES "__HCCA_SCHEMA__".seating_zones(id) ON DELETE CASCADE;


--
-- Name: shop_class_collections shop_class_collections_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_class_collections
    ADD CONSTRAINT shop_class_collections_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: shop_class_collections shop_class_collections_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_class_collections
    ADD CONSTRAINT shop_class_collections_order_id_fkey FOREIGN KEY (order_id) REFERENCES "__HCCA_SCHEMA__".orders(id) ON DELETE CASCADE;


--
-- Name: shop_class_payments shop_class_payments_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_class_payments
    ADD CONSTRAINT shop_class_payments_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE CASCADE;


--
-- Name: shop_class_payments shop_class_payments_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_class_payments
    ADD CONSTRAINT shop_class_payments_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE CASCADE;


--
-- Name: shop_class_payments shop_class_payments_confirmed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_class_payments
    ADD CONSTRAINT shop_class_payments_confirmed_by_id_fkey FOREIGN KEY (confirmed_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: shop_delegation_links shop_delegation_links_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_delegation_links
    ADD CONSTRAINT shop_delegation_links_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE RESTRICT;


--
-- Name: shop_delegation_links shop_delegation_links_bound_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_delegation_links
    ADD CONSTRAINT shop_delegation_links_bound_user_id_fkey FOREIGN KEY (bound_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: shop_delegation_links shop_delegation_links_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_delegation_links
    ADD CONSTRAINT shop_delegation_links_category_id_fkey FOREIGN KEY (category_id) REFERENCES "__HCCA_SCHEMA__".product_categories(id) ON DELETE RESTRICT;


--
-- Name: shop_delegation_links shop_delegation_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_delegation_links
    ADD CONSTRAINT shop_delegation_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: shop_order_closes shop_order_closes_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_order_closes
    ADD CONSTRAINT shop_order_closes_category_id_fkey FOREIGN KEY (category_id) REFERENCES "__HCCA_SCHEMA__".product_categories(id) ON DELETE CASCADE;


--
-- Name: shop_order_closes shop_order_closes_class_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_order_closes
    ADD CONSTRAINT shop_order_closes_class_id_fkey FOREIGN KEY (class_id) REFERENCES "__HCCA_SCHEMA__".school_classes(id) ON DELETE SET NULL;


--
-- Name: shop_order_closes shop_order_closes_closed_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_order_closes
    ADD CONSTRAINT shop_order_closes_closed_by_id_fkey FOREIGN KEY (closed_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: shop_order_closes shop_order_closes_reopened_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_order_closes
    ADD CONSTRAINT shop_order_closes_reopened_by_id_fkey FOREIGN KEY (reopened_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: shop_order_promotions shop_order_promotions_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_order_promotions
    ADD CONSTRAINT shop_order_promotions_order_id_fkey FOREIGN KEY (order_id) REFERENCES "__HCCA_SCHEMA__".orders(id) ON DELETE CASCADE;


--
-- Name: shop_order_promotions shop_order_promotions_promotion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_order_promotions
    ADD CONSTRAINT shop_order_promotions_promotion_id_fkey FOREIGN KEY (promotion_id) REFERENCES "__HCCA_SCHEMA__".shop_promotions(id) ON DELETE RESTRICT;


--
-- Name: shop_order_receipt_prints shop_order_receipt_prints_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_order_receipt_prints
    ADD CONSTRAINT shop_order_receipt_prints_order_id_fkey FOREIGN KEY (order_id) REFERENCES "__HCCA_SCHEMA__".orders(id) ON DELETE CASCADE;


--
-- Name: shop_promotion_product_prices shop_promotion_product_prices_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_product_prices
    ADD CONSTRAINT shop_promotion_product_prices_product_id_fkey FOREIGN KEY (product_id) REFERENCES "__HCCA_SCHEMA__".products(id) ON DELETE RESTRICT;


--
-- Name: shop_promotion_product_prices shop_promotion_product_prices_promotion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_product_prices
    ADD CONSTRAINT shop_promotion_product_prices_promotion_id_fkey FOREIGN KEY (promotion_id) REFERENCES "__HCCA_SCHEMA__".shop_promotions(id) ON DELETE CASCADE;


--
-- Name: shop_promotion_products shop_promotion_products_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_products
    ADD CONSTRAINT shop_promotion_products_product_id_fkey FOREIGN KEY (product_id) REFERENCES "__HCCA_SCHEMA__".products(id) ON DELETE RESTRICT;


--
-- Name: shop_promotion_products shop_promotion_products_promotion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_products
    ADD CONSTRAINT shop_promotion_products_promotion_id_fkey FOREIGN KEY (promotion_id) REFERENCES "__HCCA_SCHEMA__".shop_promotions(id) ON DELETE CASCADE;


--
-- Name: shop_promotion_student_targets shop_promotion_student_targets_promotion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_student_targets
    ADD CONSTRAINT shop_promotion_student_targets_promotion_id_fkey FOREIGN KEY (promotion_id) REFERENCES "__HCCA_SCHEMA__".shop_promotions(id) ON DELETE CASCADE;


--
-- Name: shop_promotion_users shop_promotion_users_promotion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_users
    ADD CONSTRAINT shop_promotion_users_promotion_id_fkey FOREIGN KEY (promotion_id) REFERENCES "__HCCA_SCHEMA__".shop_promotions(id) ON DELETE CASCADE;


--
-- Name: shop_promotion_users shop_promotion_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotion_users
    ADD CONSTRAINT shop_promotion_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: shop_promotions shop_promotions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotions
    ADD CONSTRAINT shop_promotions_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: shop_promotions shop_promotions_target_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_promotions
    ADD CONSTRAINT shop_promotions_target_user_id_fkey FOREIGN KEY (target_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: shop_sheet_rows shop_sheet_rows_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_sheet_rows
    ADD CONSTRAINT shop_sheet_rows_source_id_fkey FOREIGN KEY (source_id) REFERENCES "__HCCA_SCHEMA__".shop_sheet_sources(id) ON DELETE CASCADE;


--
-- Name: shop_sheet_sources shop_sheet_sources_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_sheet_sources
    ADD CONSTRAINT shop_sheet_sources_category_id_fkey FOREIGN KEY (category_id) REFERENCES "__HCCA_SCHEMA__".product_categories(id) ON DELETE RESTRICT;


--
-- Name: shop_teacher_profiles shop_teacher_profiles_office_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_teacher_profiles
    ADD CONSTRAINT shop_teacher_profiles_office_id_fkey FOREIGN KEY (office_id) REFERENCES "__HCCA_SCHEMA__".shop_offices(id) ON DELETE RESTRICT;


--
-- Name: shop_teacher_profiles shop_teacher_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".shop_teacher_profiles
    ADD CONSTRAINT shop_teacher_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: support_approvals support_approvals_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_approvals
    ADD CONSTRAINT support_approvals_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: support_approvals support_approvals_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_approvals
    ADD CONSTRAINT support_approvals_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: support_approvals support_approvals_target_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_approvals
    ADD CONSTRAINT support_approvals_target_user_id_fkey FOREIGN KEY (target_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: support_approvals support_approvals_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_approvals
    ADD CONSTRAINT support_approvals_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES "__HCCA_SCHEMA__".support_tickets(id) ON DELETE SET NULL;


--
-- Name: support_assistance_sessions support_assistance_sessions_support_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_assistance_sessions
    ADD CONSTRAINT support_assistance_sessions_support_user_id_fkey FOREIGN KEY (support_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: support_assistance_sessions support_assistance_sessions_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_assistance_sessions
    ADD CONSTRAINT support_assistance_sessions_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES "__HCCA_SCHEMA__".support_tickets(id) ON DELETE RESTRICT;


--
-- Name: support_assistance_sessions support_assistance_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_assistance_sessions
    ADD CONSTRAINT support_assistance_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: support_audit_logs support_audit_logs_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_audit_logs
    ADD CONSTRAINT support_audit_logs_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: support_audit_logs support_audit_logs_target_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_audit_logs
    ADD CONSTRAINT support_audit_logs_target_user_id_fkey FOREIGN KEY (target_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: support_audit_logs support_audit_logs_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_audit_logs
    ADD CONSTRAINT support_audit_logs_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES "__HCCA_SCHEMA__".support_tickets(id) ON DELETE SET NULL;


--
-- Name: support_guide_entries support_guide_entries_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_guide_entries
    ADD CONSTRAINT support_guide_entries_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: support_guide_entries support_guide_entries_updated_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_guide_entries
    ADD CONSTRAINT support_guide_entries_updated_by_id_fkey FOREIGN KEY (updated_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: support_impersonation_sessions support_impersonation_sessions_impersonated_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_impersonation_sessions
    ADD CONSTRAINT support_impersonation_sessions_impersonated_user_id_fkey FOREIGN KEY (impersonated_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: support_impersonation_sessions support_impersonation_sessions_real_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_impersonation_sessions
    ADD CONSTRAINT support_impersonation_sessions_real_user_id_fkey FOREIGN KEY (real_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: support_impersonation_sessions support_impersonation_sessions_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_impersonation_sessions
    ADD CONSTRAINT support_impersonation_sessions_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES "__HCCA_SCHEMA__".support_tickets(id) ON DELETE RESTRICT;


--
-- Name: support_ticket_events support_ticket_events_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_ticket_events
    ADD CONSTRAINT support_ticket_events_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: support_ticket_events support_ticket_events_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_ticket_events
    ADD CONSTRAINT support_ticket_events_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES "__HCCA_SCHEMA__".support_tickets(id) ON DELETE CASCADE;


--
-- Name: support_tickets support_tickets_assigned_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_tickets
    ADD CONSTRAINT support_tickets_assigned_to_id_fkey FOREIGN KEY (assigned_to_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: support_tickets support_tickets_reported_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_tickets
    ADD CONSTRAINT support_tickets_reported_by_user_id_fkey FOREIGN KEY (reported_by_user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: support_tickets support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".support_tickets
    ADD CONSTRAINT support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: survey_answers survey_answers_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".survey_answers
    ADD CONSTRAINT survey_answers_question_id_fkey FOREIGN KEY (question_id) REFERENCES "__HCCA_SCHEMA__".survey_questions(id) ON DELETE CASCADE;


--
-- Name: survey_answers survey_answers_response_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".survey_answers
    ADD CONSTRAINT survey_answers_response_id_fkey FOREIGN KEY (response_id) REFERENCES "__HCCA_SCHEMA__".survey_responses(id) ON DELETE CASCADE;


--
-- Name: survey_questions survey_questions_survey_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".survey_questions
    ADD CONSTRAINT survey_questions_survey_id_fkey FOREIGN KEY (survey_id) REFERENCES "__HCCA_SCHEMA__".surveys(id) ON DELETE CASCADE;


--
-- Name: survey_responses survey_responses_respondent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".survey_responses
    ADD CONSTRAINT survey_responses_respondent_id_fkey FOREIGN KEY (respondent_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: survey_responses survey_responses_survey_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".survey_responses
    ADD CONSTRAINT survey_responses_survey_id_fkey FOREIGN KEY (survey_id) REFERENCES "__HCCA_SCHEMA__".surveys(id) ON DELETE CASCADE;


--
-- Name: surveys surveys_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".surveys
    ADD CONSTRAINT surveys_created_by_fkey FOREIGN KEY (created_by) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: surveys surveys_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".surveys
    ADD CONSTRAINT surveys_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE RESTRICT;


--
-- Name: system_incident_events system_incident_events_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".system_incident_events
    ADD CONSTRAINT system_incident_events_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES "__HCCA_SCHEMA__".system_incidents(id) ON DELETE CASCADE;


--
-- Name: system_incidents system_incidents_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".system_incidents
    ADD CONSTRAINT system_incidents_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: timeline_events timeline_events_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".timeline_events
    ADD CONSTRAINT timeline_events_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: timeline_events timeline_events_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".timeline_events
    ADD CONSTRAINT timeline_events_case_id_fkey FOREIGN KEY (case_id) REFERENCES "__HCCA_SCHEMA__".governance_cases(id) ON DELETE CASCADE;


--
-- Name: timeline_events timeline_events_matter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".timeline_events
    ADD CONSTRAINT timeline_events_matter_id_fkey FOREIGN KEY (matter_id) REFERENCES "__HCCA_SCHEMA__".matters(id) ON DELETE CASCADE;


--
-- Name: user_google_tasks_configs user_google_tasks_configs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_google_tasks_configs
    ADD CONSTRAINT user_google_tasks_configs_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: user_identities user_identities_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_identities
    ADD CONSTRAINT user_identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: user_positions user_positions_position_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_positions
    ADD CONSTRAINT user_positions_position_id_fkey FOREIGN KEY (position_id) REFERENCES "__HCCA_SCHEMA__".positions(id) ON DELETE CASCADE;


--
-- Name: user_positions user_positions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_positions
    ADD CONSTRAINT user_positions_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: vote_events vote_events_ballot_box_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".vote_events
    ADD CONSTRAINT vote_events_ballot_box_id_fkey FOREIGN KEY (ballot_box_id) REFERENCES "__HCCA_SCHEMA__".election_ballot_boxes(id) ON DELETE RESTRICT;


--
-- Name: vote_events vote_events_candidate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".vote_events
    ADD CONSTRAINT vote_events_candidate_id_fkey FOREIGN KEY (candidate_id) REFERENCES "__HCCA_SCHEMA__".election_candidates(id) ON DELETE RESTRICT;


--
-- Name: vote_events vote_events_election_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".vote_events
    ADD CONSTRAINT vote_events_election_id_fkey FOREIGN KEY (election_id) REFERENCES "__HCCA_SCHEMA__".elections(id) ON DELETE CASCADE;


--
-- Name: vote_events vote_events_operator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".vote_events
    ADD CONSTRAINT vote_events_operator_id_fkey FOREIGN KEY (operator_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE RESTRICT;


--
-- Name: vote_events vote_events_reverses_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".vote_events
    ADD CONSTRAINT vote_events_reverses_event_id_fkey FOREIGN KEY (reverses_event_id) REFERENCES "__HCCA_SCHEMA__".vote_events(id) ON DELETE RESTRICT;


--
-- Name: web_push_subscriptions web_push_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".web_push_subscriptions
    ADD CONSTRAINT web_push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE CASCADE;


--
-- Name: webhook_deliveries webhook_deliveries_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES "__HCCA_SCHEMA__".webhook_subscriptions(id) ON DELETE CASCADE;


--
-- Name: webhook_subscriptions webhook_subscriptions_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".webhook_subscriptions
    ADD CONSTRAINT webhook_subscriptions_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES "__HCCA_SCHEMA__".users(id);


--
-- Name: work_items work_items_assigned_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".work_items
    ADD CONSTRAINT work_items_assigned_to_id_fkey FOREIGN KEY (assigned_to_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: work_items work_items_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".work_items
    ADD CONSTRAINT work_items_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: workflow_events workflow_events_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_events
    ADD CONSTRAINT workflow_events_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: workflow_events workflow_events_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_events
    ADD CONSTRAINT workflow_events_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES "__HCCA_SCHEMA__".workflow_instances(id) ON DELETE CASCADE;


--
-- Name: workflow_instances workflow_instances_activity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_instances
    ADD CONSTRAINT workflow_instances_activity_id_fkey FOREIGN KEY (activity_id) REFERENCES "__HCCA_SCHEMA__".activities(id) ON DELETE SET NULL;


--
-- Name: workflow_instances workflow_instances_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_instances
    ADD CONSTRAINT workflow_instances_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: workflow_instances workflow_instances_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_instances
    ADD CONSTRAINT workflow_instances_org_id_fkey FOREIGN KEY (org_id) REFERENCES "__HCCA_SCHEMA__".orgs(id) ON DELETE SET NULL;


--
-- Name: workflow_links workflow_links_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_links
    ADD CONSTRAINT workflow_links_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES "__HCCA_SCHEMA__".users(id) ON DELETE SET NULL;


--
-- Name: workflow_links workflow_links_instance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "__HCCA_SCHEMA__".workflow_links
    ADD CONSTRAINT workflow_links_instance_id_fkey FOREIGN KEY (instance_id) REFERENCES "__HCCA_SCHEMA__".workflow_instances(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


